#!/usr/bin/env python3
"""
项目初始化脚本
自动创建项目所需的目录结构
"""
import os
import sys
import json
from pathlib import Path
from project_utils import get_project_path, save_file_to_project

def create_project_structure():
    """创建标准项目目录结构"""

    # 定义要创建的目录
    directories = [
        'ref',
        'output',
        'data',
        'scripts'
    ]

    created_count = 0

    for dir_name in directories:
        path = get_project_path(dir_name)  # ✅ 使用项目目录
        try:
            if not path.exists():
                path.mkdir(parents=True, exist_ok=True)
                print(f"✓ 创建目录: {dir_name}")
                created_count += 1
            else:
                print(f"- 目录已存在: {dir_name}")
        except Exception as e:
            print(f"✗ 创建目录失败 {dir_name}: {e}")
            return False

    # 创建状态文件模板
    initial_status = {
        "project_name": "",
        "current_step": "init",
        "completed_steps": [],
        "total_words": 0,
        "target_words": 90000,
        "scenes_completed": 0,
        "target_scenes": 95,
        "last_updated": ""
    }
    if save_file_to_project('data/status.json', json.dumps(initial_status, ensure_ascii=False, indent=2)):
        print("✓ 创建状态文件: data/status.json")
    else:
        print("✗ 创建状态文件失败")
        return False

    # 创建 README
    readme_content = """# 剧本创作项目

## 项目结构

- `/ref` - 参考剧本和辅助内容
- `/output` - 剧本输出目录
- `/data` - 临时文件和状态数据
- `/scripts` - 工具脚本

## 使用流程

1. 将原剧本放入 `ref/` 目录
2. 运行 `python scripts/analyze_screenplay.py`
3. 运行 `python scripts/generate_plan.py`
4. 运行 `python scripts/expand_act.py` 逐幕扩写
5. 运行 `python scripts/polish_screenplay.py` 润色

## 状态跟踪

检查当前进度：
```bash
python scripts/status_manager.py --status
```
"""
    if save_file_to_project('README.md', readme_content):
        print("✓ 创建 README.md")
    else:
        print("✗ 创建 README.md 失败")
        return False

    print(f"\n✓ 项目初始化完成！共创建 {created_count} 个新目录")
    print("\n下一步：将原剧本文件放入 ref/ 目录，然后运行分析脚本")

    return True

if __name__ == '__main__':
    print("=" * 60)
    print("剧本创作项目 - 初始化工具")
    print("=" * 60)
    print()

    success = create_project_structure()

    if success:
        print("\n✅ 初始化成功！")
        sys.exit(0)
    else:
        print("\n❌ 初始化失败")
        sys.exit(1)
