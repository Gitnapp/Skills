#!/usr/bin/env python3
"""
单场景扩写引擎 - 支持智能上下文压缩
基于场景大纲生成完整场景内容，确保上下文不超限
"""
import argparse
import json
import sys
from pathlib import Path
import yaml
from project_utils import get_project_path, load_file_from_project, save_file_to_project
from status_manager import load_status, update_status

def load_scene_outline(scene_number):
    """加载指定场景的大纲"""
    # 加载所有大纲
    content = load_file_from_project('data/scene_outlines.yaml')
    if not content:
        print(f"错误: 无法加载场景大纲文件")
        return None

    outlines = yaml.safe_load(content)
    scene_id = f"scene_{scene_number:03d}"

    if scene_id not in outlines:
        print(f"错误: 场景 {scene_number} 的大纲不存在")
        print(f"请先运行: python scripts/generate_scene_outline.py --scene {scene_number}")
        return None

    return outlines[scene_id]

def load_previous_scene_content(scene_number, num_prev=2):
    """
    加载前几个场景的内容（用于保持连贯性）
    只读取每个场景的最后一部分内容以压缩上下文

    参数:
        scene_number: 当前场景编号
        num_prev: 需要读取的前几个场景数量

    返回:
        前几个场景的压缩内容
    """
    prev_scenes = []

    for i in range(scene_number - num_prev, scene_number):
        if i < 1:
            continue

        scene_file = get_project_path(f'data/scenes/scene_{i:03d}.md')
        if not scene_file.exists():
            continue

        try:
            with open(scene_file, 'r', encoding='utf-8') as f:
                content = f.read()

            # 只取场景的最后约 300 字（保持连贯性的关键点）
            # 避免携带完整的前文，节省 token
            words = content.split()
            if len(words) > 100:  # 如果超过100字，只取最后100字
                compressed = ' '.join(words[-100:])
                prev_scenes.append(f"<!-- 场景 {i} 结尾 -->
{compressed}")
            else:
                prev_scenes.append(f"<!-- 场景 {i} 全文 -->
{content}")

        except Exception as e:
            print(f"警告: 读取场景 {i} 失败 - {e}")
            continue

    if not prev_scenes:
        return "无前序场景（当前为开场场景）"

    return "\n\n".join(prev_scenes)

def get_compression_guidelines():
    """返回上下文压缩的指引说明"""
    return """
[上下文压缩原则]
- 只参考前1-2个场景的关键结尾（非全文）
- 重点关注：情感连贯性、情节衔接、角色状态
- 保持当前场景的独立完整性
- 不需要重复前文已交代的内容
"""

def simulate_claude_api_call(scene_outline, previous_content, scene_number):
    """
    模拟 Claude API 调用生成场景内容
    （实际使用时需要接入真实的 Claude API）

    输入:
        scene_outline: 场景大纲（约200字）
        previous_content: 前1-2个场景结尾（约500字）
        scene_number: 场景编号

    输出:
        完整场景内容（900-1200字）
    """
    import time

    print(f"{'='*70}")
    print(f"调用 Claude API 生成场景 {scene_number}")
    print(f"{'='*70}")
    print(f"输入 token 估算:")
    print(f"  - 场景大纲: {len(str(scene_outline))} 字符")
    print(f"  - 前序场景: {len(previous_content)} 字符")
    print(f"  - 系统提示: ~500 字符")
    print(f"  - 总计: ~{len(str(scene_outline)) + len(previous_content) + 500} 字符")
    print()

    # 模拟 API 调用耗时
    print("正在生成场景内容...", end="", flush=True)
    time.sleep(2)
    print(" 完成！")
    print()

    # 模拟生成的场景内容
    title = scene_outline.get('title', f'场景 {scene_number}')
    summary = scene_outline.get('summary', '')
    characters = ', '.join(scene_outline.get('characters', ['主角']))
    location = scene_outline.get('location', '待定')
    target_words = scene_outline.get('target_words', 1000)

    simulated_content = f"""# 场景 {scene_number}: {title}

**场景信息**
- 地点: {location}
- 出场角色: {characters}
- 目标字数: {target_words} 字
- 情感基调: {scene_outline.get('emotional_tone', '待定')}

## 场景描述

{summary}

## 正文内容

[这是模拟生成的场景内容，实际使用时将调用 Claude API 生成]

### 情节发展

1. **开端**: [场景开始时的状态和事件]

2. **中段**: [情节推进和冲突发展]

3. **高潮**: [场景的关键转折点]

4. **结尾**: [场景的收尾和过渡到下一个场景]

### 角色互动

- **角色A**: [动作和对话]
- **角色B**: [反应和对话]

### 主题关联

[说明此场景如何推进整体故事主题]

---

**字数统计**: 约 {target_words} 字
**生成时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}
**场景ID**: scene_{scene_number:03d}

"""

    return simulated_content

def expand_single_scene(scene_number):
    """
    扩写单个场景

    流程：
    1. 加载场景大纲
    2. 加载前1-2场景结尾（压缩上下文）
    3. 调用 Claude API 生成内容
    4. 保存到文件
    5. 更新状态
    """
    print(f"\n{'='*70}")
    print(f"开始扩写场景 {scene_number}")
    print(f"{'='*70}\n")

    # 步骤1: 加载大纲
    print("步骤1: 加载场景大纲...")
    outline = load_scene_outline(scene_number)
    if not outline:
        return False
    print(f"✓ 大纲已加载: {outline.get('title', 'N/A')}\n")

    # 步骤2: 加载前序场景（压缩上下文）
    print("步骤2: 加载前序场景内容（压缩上下文）...")
    previous_content = load_previous_scene_content(scene_number, num_prev=2)
    print(f"✓ 前序场景加载完成")
    print(f"  上下文长度: {len(previous_content)} 字符\n")

    # 步骤3: 生成场景内容
    print("步骤3: 生成场景内容...")
    scene_content = simulate_claude_api_call(
        outline,
        previous_content,
        scene_number
    )
    if not scene_content:
        print("✗ 场景生成失败")
        return False
    print(f"✓ 场景内容生成完成\n")

    # 步骤4: 保存到文件
    print("步骤4: 保存场景文件...")
    scene_file = f'data/scenes/scene_{scene_number:03d}.md'
    if save_file_to_project(scene_file, scene_content):
        print(f"✓ 场景已保存: {scene_file}\n")
    else:
        print("✗ 保存失败\n")
        return False

    # 步骤5: 更新状态
    print("步骤5: 更新项目状态...")

    # 统计字数
    word_count = len(scene_content)

    # 更新状态
    success = update_status(
        'scene_expanded',
        last_scene=scene_number,
        scenes_completed=scene_number,
        total_words=load_status().get('total_words', 0) + word_count
    )

    if success:
        print("✓ 状态更新完成\n")
    else:
        print("✗ 状态更新失败\n")

    # 显示完成情况
    print(f"{'='*70}")
    print(f"场景 {scene_number} 扩写完成")
    print(f"{'='*70}")
    print(f"场景标题: {outline.get('title', 'N/A')}")
    print(f"场景字数: {word_count:,} 字")
    print(f"保存位置: {scene_file}")
    print(f"{'='*70}\n")

    return True

def expand_multiple_scenes(start_scene, end_scene=None):
    """
    批量扩写多个场景

    参数:
        start_scene: 起始场景编号
        end_scene: 结束场景编号（可选，如果未指定则只扩写start_scene）
    """
    if end_scene is None:
        end_scene = start_scene

    print(f"\n{'='*70}")
    print(f"批量扩写场景 {start_scene}-{end_scene}")
    print(f"{'='*70}\n")

    success_count = 0
    for scene_num in range(start_scene, end_scene + 1):
        if expand_single_scene(scene_num):
            success_count += 1
        else:
            print(f"\n⚠ 场景 {scene_num} 扩写失败，停止批量处理")
            break

    print(f"\n{'='*70}")
    print(f"批量扩写完成: {success_count}/{end_scene - start_scene + 1} 成功")
    print(f"{'='*70}\n")

    return success_count == (end_scene - start_scene + 1)

def show_scene_status(scene_number):
    """显示场景状态"""
    scene_file = get_project_path(f'data/scenes/scene_{scene_number:03d}.md')

    if not scene_file.exists():
        print(f"场景 {scene_number}: 未生成")
        return False

    try:
        with open(scene_file, 'r', encoding='utf-8') as f:
            content = f.read()

        # 提取标题
        title = f"场景 {scene_number}"
        if content.startswith('# 场景'):
            first_line = content.split('\n')[0]
            title = first_line.replace('# ', '')

        word_count = len(content.split())

        print(f"\n{'='*70}")
        print(f"场景 {scene_number} 状态")
        print(f"{'='*70}")
        print(f"标题: {title}")
        print(f"文件: {scene_file}")
        print(f"字数: {word_count:,} 字")
        print(f"状态: ✓ 已生成")
        print(f"{'='*70}\n")

        return True

    except Exception as e:
        print(f"错误: 读取场景文件失败 - {e}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description='单场景扩写引擎',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python expand_scene.py --scene 1              # 扩写场景1
  python expand_scene.py --scene 1-5            # 批量扩写场景1-5
  python expand_scene.py --scene 3 --status     # 查看场景3状态
        """
    )

    parser.add_argument('--scene', type=str, required=True,
                       help='场景编号（如 1）或范围（如 1-5）')
    parser.add_argument('--status', action='store_true',
                       help='显示场景状态而不扩写')

    args = parser.parse_args()

    # 解析场景参数
    if '-' in args.scene:
        # 范围模式
        try:
            start, end = map(int, args.scene.split('-'))
        except:
            print(f"错误: 无效的场景范围 '{args.scene}'")
            return

        if args.status:
            print("错误: --status 不能与范围模式一起使用")
            return

        expand_multiple_scenes(start, end)

    else:
        # 单个场景
        try:
            scene_num = int(args.scene)
        except:
            print(f"错误: 无效的场景编号 '{args.scene}'")
            return

        if args.status:
            show_scene_status(scene_num)
        else:
            expand_single_scene(scene_num)

if __name__ == '__main__':
    main()
