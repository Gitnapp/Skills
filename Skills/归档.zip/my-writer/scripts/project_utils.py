#!/usr/bin/env python3
"""
项目工具模块
提供统一的项目目录管理和UV检测功能
"""
import os
import sys
import subprocess
from pathlib import Path

# 全局变量
PROJECT_DIR = None


def get_project_dir():
    """获取项目目录"""
    global PROJECT_DIR
    if PROJECT_DIR is not None:
        return PROJECT_DIR
    return Path.cwd()


def set_project_dir(project_dir):
    """设置项目目录"""
    global PROJECT_DIR
    if project_dir:
        PROJECT_DIR = Path(project_dir)
    else:
        PROJECT_DIR = Path.cwd()


def is_uv_available():
    """检查uv是否可用"""
    try:
        subprocess.run(['uv', '--version'],
                       capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def run_python_command(script_path, *args, project_dir=None):
    """
    运行Python命令，优先使用uv

    参数:
        script_path: 脚本路径（相对于skill脚本目录）
        *args: 脚本参数
        project_dir: 项目目录（工作目录，如果不提供则使用当前目录）

    返回:
        成功返回True，失败返回False
    """
    # 确定skill脚本所在目录（即包含本文件的目录）
    # 这是skill自带的脚本所在位置
    script_dir = Path(__file__).parent

    # 确定工作目录（即项目目录）
    if project_dir:
        working_dir = Path(project_dir).resolve()
    else:
        working_dir = Path.cwd()

    # 确定脚本完整路径（相对于脚本所在目录）
    script = script_dir / script_path

    # 确保脚本存在
    if not script.exists():
        print(f"错误: 脚本文件不存在 - {script}")
        return False

    # 构建命令
    cmd_list = []
    if is_uv_available():
        cmd_list.extend(['uv', 'run', 'python', str(script)])
        print(f"检测: 使用 uv run 执行脚本")
    else:
        cmd_list.extend([sys.executable, str(script)])
        print(f"检测: 直接运行 python 脚本")

    # 添加脚本参数
    if args:
        cmd_list.extend([str(arg) for arg in args])

    # 打印命令（调试用）
    print(f"脚本目录: {script_dir}")
    print(f"工作目录: {working_dir}")
    print(f"执行命令: {' '.join(cmd_list[-4:])}")  # 只显示最后部分

    try:
        # 使用working_dir作为cwd来执行命令
        result = subprocess.run(cmd_list, cwd=working_dir)
        return result.returncode == 0
    except Exception as e:
        print(f"错误: 执行命令失败 - {e}")
        return False


def get_relative_path(base_path, target_path):
    """
    转换相对路径

    参数:
        base_path: 基础路径
        target_path: 目标路径

    返回:
        相对路径
    """
    try:
        return Path(target_path).relative_to(Path(base_path))
    except ValueError:
        return Path(target_path)


def ensure_dir_exists(dir_path):
    """确保目录存在"""
    path = Path(dir_path)
    if not path.exists():
        path.mkdir(parents=True, exist_ok=True)
        return True
    return False


def get_project_path(relative_path):
    """
    获取相对于项目目录的绝对路径

    参数:
        relative_path: 相对路径（如 'data/status.json'）

    返回:
        Path: 项目目录下的绝对路径
    """
    return Path.cwd() / relative_path


def load_file_from_project(file_path):
    """
    从项目目录加载文件

    参数:
        file_path: 相对路径

    返回:
        文件内容或 None
    """
    full_path = get_project_path(file_path)
    if not full_path.exists():
        return None

    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        return None


def save_file_to_project(file_path, content):
    """
    保存文件到项目目录

    参数:
        file_path: 相对路径
        content: 文件内容

    返回:
        bool: 是否成功
    """
    full_path = get_project_path(file_path)
    full_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"错误: 保存文件失败 - {e}")
        return False

