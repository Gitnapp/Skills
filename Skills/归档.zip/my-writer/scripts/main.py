#!/usr/bin/env python3
"""
my-writer 主脚本
提供简单的命令行界面来管理整个剧本创作流程
"""
import sys
import os
from pathlib import Path
from project_utils import run_python_command, set_project_dir
import argparse

def show_help():
    """显示帮助信息"""
    print("=" * 70)
    print("my-writer - 专业中文剧本创作工具")
    print("=" * 70)
    print()
    print("使用方法:")
    print("  python main.py init              - 初始化项目")
    print("  python main.py analyze <文件>     - 分析原剧本")
    print("  python main.py plan              - 生成扩写计划")
    print("  python main.py expand            - 扩写剧本（交互式）")
    print("  python main.py status            - 查看状态")
    print("  python main.py polish            - 最终润色")
    print()
    print("高级用法:")
    print("  python status_manager.py --status          - 详细状态")
    print("  python word_counter.py <文件> --target N  - 统计字数")
    print()
    print("工作流示例:")
    print("  1. python main.py init")
    print("  2. python main.py analyze ref/original.md")
    print("  3. python main.py plan")
    print("  4. python main.py expand")
    print("  5. python main.py polish")
    print()

def run_command(script_path, *args, project_dir=None):
    """运行脚本命令，优先使用uv"""
    # 默认使用当前工作目录
    if project_dir is None:
        project_dir = Path.cwd()
    return run_python_command(script_path, *args, project_dir=project_dir)

def init_project():
    """初始化项目"""
    print("="*70)
    print("初始化剧本创作项目")
    print("="*70)
    print()
    success = run_command("init_project.py")
    if success:
        print()
        print("✅ 初始化完成！")
        print()
        print("下一步:")
        print("  1. 将原剧本文件放入 ref/ 目录")
        print("  2. 运行: python main.py analyze ref/你的剧本.md")
        print()
    return success

def analyze_screenplay(file_path):
    """分析剧本"""
    # 如果文件路径是相对的，转换为相对于当前工作目录的绝对路径
    if not os.path.isabs(file_path):
        file_path = str(Path.cwd() / file_path)

    if not os.path.exists(file_path):
        print(f"错误: 文件不存在 - {file_path}")
        return False

    print("="*70)
    print(f"分析剧本: {Path(file_path).name}")
    print("="*70)
    print()

    # 输出文件相对于当前工作目录
    output_path = str(Path.cwd() / "data" / "storyboard_src.md")

    success = run_command("analyze_screenplay.py",
                         "--input", file_path,
                         "--output", output_path)

    if success:
        print()
        print("✅ 分析完成！")
        print()
        print("下一步:")
        print("  python main.py plan")
        print()

    return success

def generate_plan():
    """生成扩写计划"""
    print("="*70)
    print("生成扩写计划")
    print("="*70)
    print()

    success = run_command("generate_plan.py")

    if success:
        print()
        print("✅ 计划生成完成！")
        print()
        print("查看详细计划:")
        print("  - data/expansion_plan.md")
        print("  - data/chapter_breakdown.md")
        print()
        print("下一步:")
        print("  python main.py expand")
        print()

    return success

def expand_screenplay():
    """交互式扩写剧本"""
    print("="*70)
    print("剧本扩写向导")
    print("="*70)
    print()
    print("扩写将按照以下顺序进行:")
    print("  1. 第一幕 (场景 1-16)")
    print("  2. 第二幕 (场景 17-64)")
    print("  3. 第三幕 (场景 65-95)")
    print()

    # 检查状态
    status_result = run_command("status_manager.py", "--status")
    if not status_result:
        return False

    print()
    print("开始扩写吗? (按 Enter 继续, Ctrl+C 中断)")
    try:
        input()
    except KeyboardInterrupt:
        print("\n中断操作")
        return False

    # 扩写第一幕
    print()
    print("="*70)
    print("扩写第一幕...")
    print("="*70)
    success = run_command("expand_act.py", "--act", "1")

    if success:
        print("\n是否继续扩写第二幕?")
        try:
            input("按 Enter 继续...")
        except KeyboardInterrupt:
            print("\n保存当前进度，可随时恢复")
            return True

        # 扩写第二幕
        print()
        print("="*70)
        print("扩写第二幕...")
        print("="*70)
        success = run_command("expand_act.py", "--act", "2")

    if success:
        print("\n是否继续扩写第三幕?")
        try:
            input("按 Enter 继续...")
        except KeyboardInterrupt:
            print("\n保存当前进度，可随时恢复")
            return True

        # 扩写第三幕
        print()
        print("="*70)
        print("扩写第三幕...")
        print("="*70)
        success = run_command("expand_act.py", "--act", "3")

    if success:
        print()
        print("✅ 扩写完成！")
        print()
        print("下一步:")
        print("  python main.py polish")
        print()

    return success

def polish_screenplay():
    """剧本润色"""
    print("="*70)
    print("最终润色")
    print("="*70)
    print()

    success = run_command("polish_screenplay.py")

    if success:
        print()
        print("✅ 项目完成！")
        print()
        print("最终输出:")
        print("  - output/polished.md (最终剧本)")
        print("  - output/final_report.md (项目报告)")
        print()

    return success

def show_status():
    """显示状态"""
    print("="*70)
    print("项目状态")
    print("="*70)
    print()
    run_command("status_manager.py", "--status")
    return True

def quick_start():
    """快速启动所有步骤"""
    print("="*70)
    print("快速启动 - 完整工作流")
    print("="*70)
    print()
    print("此模式将自动执行所有步骤:")
    print("  1. 初始化项目")
    print("  2. 生成扩写计划")
    print("  3. 自动分步扩写")
    print()
    print("注意: 快速模式不会执行剧本分析，")
    print("如需分析原剧本，请使用 analyze 命令单独执行。")
    print()

    answer = input("是否继续? (yes/no): ")
    if answer.lower() != 'yes':
        print("取消操作")
        return False

# 步骤1: 初始化
    print("\n[1/4] 初始化项目...")
    if not run_command("init_project.py"):
        return False

    # 步骤2: 检查是否有剧本需要分析
    ref_dir = Path('ref')
    if ref_dir.exists():
        files = list(ref_dir.glob('*.md')) + list(ref_dir.glob('*.txt'))
        if files:
            print(f"\n发现参考文件: {files[0].name}")
            ans = input("是否分析该文件? (yes/no): ")
            if ans.lower() == 'yes':
                print("\n[2/4] 分析剧本...")
                input_path = files[0]
                output_path = project_dir / "data" / "storyboard_src.md"
                if not run_command("analyze_screenplay.py",
                                  "--input", str(input_path),
                                  "--output", str(output_path)):
                    return False

    # 步骤3: 生成计划
    print("\n[3/4] 生成扩写计划...")
    if not run_command("generate_plan.py"):
        return False

    # 步骤4: 用户选择是否开始扩写
    print("\n[4/4] 是否开始剧本扩写?")
    print("可以选择现在开始，或稍后手动执行 expand 命令")
    ans = input("现在开始扩写? (yes/no): ")
    if ans.lower() == 'yes':
        return expand_screenplay()
    else:
        print("\n快速启动完成！")
        print("稍后可以使用: python main.py expand 进行扩写")
        return True

def main():
    if len(sys.argv) < 2:
        show_help()
        return

    command = sys.argv[1]

    if command == 'help':
        show_help()

    elif command == 'init':
        init_project()

    elif command == 'analyze':
        if len(sys.argv) < 3:
            print("错误: 请指定剧本文件路径")
            print("用法: python main.py analyze <文件路径>")
            return
        analyze_screenplay(sys.argv[2])

    elif command == 'plan':
        generate_plan()

    elif command == 'expand':
        expand_screenplay()

    elif command == 'polish':
        polish_screenplay()

    elif command == 'status':
        show_status()

    elif command == 'quick-start':
        quick_start()

    else:
        print(f"未知命令: {command}")
        print("运行 'python main.py help' 查看帮助")

if __name__ == '__main__':
    main()

