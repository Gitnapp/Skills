#!/usr/bin/env python3
"""
状态管理器
保存和恢复任务状态，支持断点续作
"""
import json
import sys
import time
from datetime import datetime
from pathlib import Path

# 添加命令行参数支持
import argparse
from project_utils import get_project_path, load_file_from_project, save_file_to_project

STATUS_FILE_NAME = 'data/status.json'
status_file_path = None

def get_status_file_path():
    """获取状态文件路径（相对于项目目录）"""
    global status_file_path
    if status_file_path is None:
        return get_project_path(STATUS_FILE_NAME)
    return status_file_path

def load_status():
    """加载当前状态"""
    status_file = get_status_file_path()
    if not status_file.exists():
        print(f"错误: 状态文件不存在 - {status_file}")
        print("请先运行 init_project.py")
        return None

    content = load_file_from_project(STATUS_FILE_NAME)
    if content is None:
        return None

    return json.loads(content)

def save_status(status):
    """保存状态"""
    status['last_updated'] = datetime.now().isoformat()
    content = json.dumps(status, ensure_ascii=False, indent=2)
    return save_file_to_project(STATUS_FILE_NAME, content)

def update_status(step_name, **kwargs):
    """更新状态"""
    status = load_status()
    if not status:
        return False

    status['current_step'] = step_name
    if step_name not in status['completed_steps']:
        status['completed_steps'].append(step_name)

    # 更新其他字段
    for key, value in kwargs.items():
        status[key] = value

    save_status(status)
    print(f"✓ 状态已更新: {step_name}")
    return True

def show_status():
    """显示当前状态"""
    status = load_status()
    if not status:
        return

    print("=" * 70)
    print("项目状态报告")
    print("=" * 70)
    print(f"项目名称: {status.get('project_name', '未设置')}")
    print(f"当前步骤: {status.get('current_step', '未知')}")
    print(f"已完成步骤: {', '.join(status.get('completed_steps', []))}")
    print()
    print("字数进度:")
    total = status.get('total_words', 0)
    target = status.get('target_words', 90000)
    progress = (total / target * 100) if target > 0 else 0
    print(f"  当前: {total:,} / 目标: {target:,} 字 ({progress:.1f}%)")
    print()
    print("场次进度:")
    scenes = status.get('scenes_completed', 0)
    target_scenes = status.get('target_scenes', 95)
    scene_progress = (scenes / target_scenes * 100) if target_scenes > 0 else 0
    print(f"  已完成: {scenes} / 目标: {target_scenes} 场 ({scene_progress:.1f}%)")
    print()
    print(f"最后更新: {status.get('last_updated', '未知')}")
    print("=" * 70)
    print()

    # 显示下一步建议
    current_step = status.get('current_step', 'init')
    completed = status.get('completed_steps', [])

    print("建议下一步操作:")
    if current_step == 'init':
        print("  - 分析剧本: python scripts/analyze_screenplay.py")
    elif current_step == 'analysis':
        print("  - 生成扩写计划: python scripts/generate_plan.py")
    elif current_step == 'planning':
        print("  - 扩写第一幕: python scripts/expand_act.py --act 1")
    elif current_step == 'act1_completed':
        print("  - 扩写第二幕: python scripts/expand_act.py --act 2")
    elif current_step == 'act2_completed':
        print("  - 扩写第三幕: python scripts/expand_act.py --act 3")
    elif current_step == 'act3_completed':
        print("  - 剧本润色: python scripts/polish_screenplay.py")
    elif current_step == 'completed':
        print("  - 项目已完成！输出文件在 output/ 目录")
    print()

def set_project_name(name):
    """设置项目名称"""
    status = load_status()
    if not status:
        return False

    status['project_name'] = name
    save_status(status)
    print(f"✓ 项目名称已设置为: {name}")
    return True

def reset_status():
    """重置状态（谨慎使用）"""
    status = load_status()
    if not status:
        return False

    status['current_step'] = 'init'
    status['completed_steps'] = []
    status['total_words'] = 0
    status['scenes_completed'] = 0

    save_status(status)
    print("✓ 状态已重置")
    return True

def main():
    if len(sys.argv) < 2:
        show_status()
        print("用法:")
        print("  python status_manager.py --status         # 显示状态")
        print("  python status_manager.py --set-name NAME  # 设置项目名称")
        print("  python status_manager.py --reset          # 重置状态")
        return

    command = sys.argv[1]

    if command == '--status':
        show_status()
    elif command == '--set-name' and len(sys.argv) > 2:
        set_project_name(sys.argv[2])
    elif command == '--reset':
        confirm = input("确定要重置状态吗？(yes/no): ")
        if confirm.lower() == 'yes':
            reset_status()
        else:
            print("取消重置")
    else:
        print(f"未知命令: {command}")
        show_status()

if __name__ == '__main__':
    main()
