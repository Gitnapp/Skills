#!/usr/bin/env python3
"""
单场景大纲生成器
为指定场景生成详细大纲到 scene_outlines.yaml
"""
import argparse
import json
from pathlib import Path
from status_manager import load_status, update_status
import yaml
from project_utils import get_project_path, load_file_from_project, save_file_to_project


def load_scenes_metadata():
    """加载场景元数据"""
    scenes_file = get_project_path('data/scenes.json')
    if not scenes_file.exists():
        print(f"错误: 场景元数据文件不存在 - {scenes_file}")
        print("请先运行: python scripts/generate_plan.py")
        return None

    content = load_file_from_project('data/scenes.json')
    if content is None:
        return None

    return json.loads(content)


def load_scene_outlines():
    """加载场景大纲"""
    outlines_file = get_project_path('data/scene_outlines.yaml')
    if not outlines_file.exists():
        print(f"错误: 场景大纲文件不存在 - {outlines_file}")
        return None

    content = load_file_from_project('data/scene_outlines.yaml')
    if content is None:
        return None

    return yaml.safe_load(content)


def save_scene_outlines(outlines):
    """保存场景大纲"""
    content = yaml.dump(outlines, allow_unicode=True, default_flow_style=False, sort_keys=False)
    return save_file_to_project('data/scene_outlines.yaml', content)


def simulate_generate_outline(scene_info):
    """模拟生成大纲（实际应调用 Claude API）"""
    scene_num = scene_info['scene_number']
    target_words = scene_info['target_words']
    act = scene_info['act']

    # 基于幕和场景序号生成大纲模板
    if scene_num == 1:
        summary = f"开场场景，建立主角的日常状态。需要引起观众兴趣并设置故事基调。目标字数：{target_words}字。"
        characters = ["主角"]
        location = "主角家中"
        time = "早晨"
        purpose = "建立人物基础状态，展示日常生活"
        conflict = "内心冲突（渴望改变但安于现状）"
        emotional_tone = "平静中带有一丝不安"
        key_moments = ["主角醒来", "展示日常习惯", "暗示内心渴望"]

    elif scene_num == 95:
        summary = f"结局场景，收束所有线索。展示主角的改变和成长。目标字数：{target_words}字。"
        characters = ["主角", "关键配角"]
        location = "最终场景地点"
        time = "故事结束时刻"
        purpose = "解决主要冲突，展示人物弧光完成"
        conflict = "冲突已解决"
        emotional_tone = "希望、满足、或开放式结局"
        key_moments = ["最后的高潮", "情感释放", "回到新世界"]

    elif act == 1 and scene_num <= 8:
        summary = f"第一幕建制部分，展示主角的日常世界。建立人物关系和故事背景。目标字数：{target_words}字。"
        characters = ["主角", "配角"]
        purpose = "建置主角的日常生活和渴望"

    elif act == 1 and scene_num <= 16:
        summary = f"第一幕转折点，引发事件出现。主角必须做出选择。目标字数：{target_words}字。"
        characters = ["主角", "导师/信使"]
        purpose = "引发事件，呼唤冒险"

    elif act == 2 and scene_num <= 40:
        summary = f"第二幕探索部分，主角进入新世界。遇到盟友和敌人。目标字数：{target_words}字。"
        characters = ["主角", "盟友", "对手"]
        purpose = "探索新世界规则，建立新关系"

    elif act == 2 and scene_num <= 71:
        summary = f"第二幕深化部分，冲突升级。至暗时刻即将到来。目标字数：{target_words}字。"
        characters = ["主角", "盟友", "主要对手"]
        purpose = "深化冲突，准备最后的对抗"

    elif act == 3:
        summary = f"第三幕高潮部分，最终对决和结局。解决所有线索。目标字数：{target_words}字。"
        characters = ["主角", "主要对手"]
        purpose = "最终对抗，完成人物弧光"

    else:
        summary = f"场景 {scene_num}，推动剧情发展。目标字数：{target_words}字。"
        characters = ["主角"]
        purpose = "推进情节或深化人物"

    # 填充默认值
    if 'location' not in locals():
        location = f"地点_{scene_num}"
    if 'time' not in locals():
        time = "时间待定"
    if 'conflict' not in locals():
        conflict = f"场景{scene_num}的冲突"
    if 'emotional_tone' not in locals():
        emotional_tone = "情感基调待定"
    if 'purpose' not in locals():
        purpose = f"推进场景{scene_num}的情节"
    if 'key_moments' not in locals():
        key_moments = [f"关键时刻1", f"关键时刻2"]

    outline = {
        'title': scene_info['title'],
        'summary': summary,
        'characters': characters,
        'location': location,
        'time': time,
        'plot_points': [f"情节点{j+1}" for j in range(3)],
        'emotional_tone': emotional_tone,
        'conflict': conflict,
        'purpose': purpose,
        'target_words': target_words,
        'key_moments': key_moments,
        'notes': f'场景{scene_num}的写作注意事项'
    }

    return outline


def generate_scene_outline(scene_number):
    """为单个场景生成大纲"""
    print(f"\n{'='*70}")
    print(f"生成场景 {scene_number} 的大纲")
    print(f"{'='*70}\n")

    # 加载场景元数据
    scenes_data = load_scenes_metadata()
    if not scenes_data:
        return False

    # 查找目标场景
    target_scene = None
    for scene in scenes_data['scenes']:
        if scene['scene_number'] == scene_number:
            target_scene = scene
            break

    if not target_scene:
        print(f"错误: 找不到场景 {scene_number}")
        print(f"有效范围: 1-{scenes_data['total_scenes']}")
        return False

    # 加载现有大纲
    outlines = load_scene_outlines()
    if not outlines:
        outlines = {}

    # 生成大纲（模拟）
    scene_id = target_scene['id']
    print(f"场景ID: {scene_id}")
    print(f"场景标题: {target_scene['title']}")
    print(f"所属幕: 第 {target_scene['act']} 幕")
    print(f"目标字数: {target_scene['target_words']} 字")
    print()

    outline = simulate_generate_outline(target_scene)

    # 保存到 outlines
    outlines[scene_id] = outline

    # 保存回文件
    if save_scene_outlines(outlines):
        print(f"\n✓ 场景 {scene_number} 大纲已生成并保存")
        print(f"  文件: data/scene_outlines.yaml")
        print(f"  标题: {outline['title']}")
        print(f"  摘要: {outline['summary'][:80]}...")

        # 更新状态
        update_status(
            'outline_generated',
            last_scene=scene_number,
            last_scene_id=scene_id
        )

        return True

    return False


def generate_multiple_outlines(scene_range):
    """生成多个场景的大纲"""
    print(f"\n{'='*70}")
    print(f"批量生成场景 {scene_range} 的大纲")
    print(f"{'='*70}\n")

    # 解析范围
    if '-' in scene_range:
        start, end = map(int, scene_range.split('-'))
    else:
        start = int(scene_range)
        end = start

    # 加载场景元数据
    scenes_data = load_scenes_metadata()
    if not scenes_data:
        return False

    # 检查范围
    total_scenes = scenes_data['total_scenes']
    if start < 1 or end > total_scenes or start > end:
        print(f"错误: 无效的场景范围。有效范围: 1-{total_scenes}")
        return False

    # 逐个生成
    success_count = 0
    for scene_num in range(start, end + 1):
        if generate_scene_outline(scene_num):
            success_count += 1

    print(f"\n{'='*70}")
    print(f"批量生成完成：{success_count}/{end - start + 1} 个场景成功")
    print(f"{'='*70}")

    return success_count > 0


def show_outline(scene_number):
    """显示场景大纲"""
    outlines = load_scene_outlines()
    if not outlines:
        print("错误: 场景大纲文件不存在")
        return False

    # 构造场景ID
    scene_id = f"scene_{scene_number:03d}"

    if scene_id not in outlines:
        print(f"错误: 场景 {scene_number} 的大纲不存在")
        print(f"请先运行: python scripts/generate_scene_outline.py --scene {scene_number}")
        return False

    outline = outlines[scene_id]

    print(f"\n{'='*70}")
    print(f"场景 {scene_number} 大纲详情")
    print(f"{'='*70}\n")
    print(f"标题: {outline['title']}")
    print(f"摘要: {outline['summary']}")
    print(f"地点: {outline['location']}")
    print(f"时间: {outline['time']}")
    print(f"出场角色: {', '.join(outline['characters'])}")
    print(f"情感基调: {outline['emotional_tone']}")
    print(f"冲突类型: {outline['conflict']}")
    print(f"场景目的: {outline['purpose']}")
    print(f"目标字数: {outline['target_words']} 字")
    print(f"\n情节点:")
    for point in outline['plot_points']:
        print(f"  - {point}")
    print(f"\n关键瞬间:")
    for moment in outline['key_moments']:
        print(f"  - {moment}")
    print(f"\n备注: {outline['notes']}")
    print(f"{'='*70}\n")

    return True


def main():
    parser = argparse.ArgumentParser(
        description='生成单场景大纲',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python generate_scene_outline.py --scene 1          # 生成场景1的大纲
  python generate_scene_outline.py --scene 1-5        # 批量生成场景1-5的大纲
  python generate_scene_outline.py --scene 5 --show   # 显示场景5的大纲
        """
    )

    parser.add_argument('--scene', type=str, required=True,
                       help='场景编号（如 1）或范围（如 1-5）')
    parser.add_argument('--show', action='store_true',
                       help='显示大纲内容而不生成')

    args = parser.parse_args()

    if args.show:
        # 显示模式
        try:
            scene_num = int(args.scene)
            show_outline(scene_num)
        except ValueError:
            print("错误: --show 模式需要指定单个场景编号（如 --scene 1）")
            return
    else:
        # 生成模式
        if '-' in args.scene:
            # 批量生成
            generate_multiple_outlines(args.scene)
        else:
            # 单个生成
            try:
                scene_num = int(args.scene)
                generate_scene_outline(scene_num)
            except ValueError:
                print(f"错误: 无效的场景编号 '{args.scene}'")
                return


if __name__ == '__main__':
    main()
