#!/usr/bin/env python3
"""
字数统计工具
统计剧本字数并追踪进度
"""
import sys
import re
from pathlib import Path
from status_manager import load_status, update_status

def count_words(text):
    """统计中文字数和英文单词数"""
    # 统计中文字符
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))

    # 统计英文单词
    english_words = len(re.findall(r'[a-zA-Z]+', text))

    return chinese_chars + english_words

def count_scenes(text):
    """统计场次数量"""
    # 匹配中文剧本中的场次标记，如：第1场、第23场、第1幕第1场
    scene_pattern = r'第\d+场|第\d+幕第\d+场|Scene\s+\d+|SCENE\s+\d+'
    scenes = re.findall(scene_pattern, text, re.IGNORECASE)
    return len(scenes)

def analyze_file(file_path):
    """分析文件"""
    path = Path(file_path)
    if not path.exists():
        print(f"错误: 文件不存在 - {file_path}")
        return None

    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()

        words = count_words(content)
        scenes = count_scenes(content)

        print("=" * 70)
        print(f"文件分析: {file_path}")
        print("=" * 70)
        print(f"文件大小: {path.stat().st_size / 1024:.1f} KB")
        print(f"总字数: {words:,} 字")
        print(f"场次数: {scenes} 场")
        if scenes > 0:
            print(f"平均每场: {words // scenes} 字")
        print("=" * 70)

        return {
            'words': words,
            'scenes': scenes,
            'avg_per_scene': words // scenes if scenes > 0 else 0
        }

    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        return None

def check_progress(file_path, target_words=90000):
    """检查进度并更新状态"""
    result = analyze_file(file_path)
    if not result:
        return False

    words = result['words']
    scenes = result['scenes']
    progress = (words / target_words * 100) if target_words > 0 else 0

    # 更新状态
    update_status('progress_check',
                  total_words=words,
                  scenes_completed=scenes)

    print()
    print("目标进度:")
    print(f"  目标: {target_words:,} 字")
    print(f"  当前: {words:,} 字")
    print(f"  进度: {progress:.1f}%")
    print(f"  剩余: {target_words - words:,} 字")
    print()

    # 进度警告
    if progress < 30 and words > 1000:
        print("⚠️  进度偏慢，建议加快扩写速度")
    elif progress > 100:
        print("⚠️  已超过目标字数，建议精简或调整目标")

    print("=" * 70)

    return True

def main():
    if len(sys.argv) < 2:
        print("用法:")
        print("  python word_counter.py <文件路径>")
        print("  python word_counter.py <文件路径> --target <目标字数>")
        print()
        print("示例:")
        print("  python word_counter.py output/final_screenplay.md")
        print("  python word_counter.py output/final_screenplay.md --target 90000")
        return

    file_path = sys.argv[1]
    target = 90000

    if '--target' in sys.argv:
        try:
            target = int(sys.argv[sys.argv.index('--target') + 1])
        except:
            pass

    check_progress(file_path, target)

if __name__ == '__main__':
    main()
