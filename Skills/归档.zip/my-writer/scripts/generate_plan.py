#!/usr/bin/env python3
"""
扩写计划生成器
基于剧本分析生成分步扩写计划，改为场景管理架构
"""
import json
from pathlib import Path
from status_manager import load_status, update_status
import yaml
from project_utils import get_project_path, load_file_from_project, save_file_to_project

def load_storyboard():
    """加载剧本分析文件"""
    storyboard_path = get_project_path('data/storyboard_src.md')
    if not storyboard_path.exists():
        print("错误: 找不到剧本分析文件 'data/storyboard_src.md'")
        print("请先运行: python scripts/analyze_screenplay.py")
        return None

    content = load_file_from_project('data/storyboard_src.md')
    if content is None:
        print(f"错误: 读取文件失败")
        return None

    return content

def generate_scenes_structure(target_words, target_scenes):
    """生成场景数据结构"""
    # 计算每幕的场景数和字数
    act_config = {
        'act_1': {
            'scenes': int(target_scenes * 0.25),
            'words': target_words * 0.25,
            'range': (1, int(target_scenes * 0.25))
        },
        'act_2': {
            'scenes': int(target_scenes * 0.50),
            'words': target_words * 0.50,
            'range': (int(target_scenes * 0.25) + 1, int(target_scenes * 0.75))
        },
        'act_3': {
            'scenes': int(target_scenes * 0.25),
            'words': target_words * 0.25,
            'range': (int(target_scenes * 0.75) + 1, target_scenes)
        }
    }

    # 生成95个场景的结构
    scenes = []
    scene_id = 1

    for act_name, config in act_config.items():
        act_num = int(act_name.split('_')[1])
        scene_count = config['scenes']
        words_per_scene = int(config['words'] / scene_count)
        start_scene, end_scene = config['range']

        for i in range(scene_count):
            # 生成场景标题模板
            if scene_id == 1:
                title = f"第 {scene_id} 场：开场 - 引子"
            elif scene_id == target_scenes:
                title = f"第 {scene_id} 场：结局 - 收尾"
            elif scene_id == start_scene + scene_count - 1:
                title = f"第 {scene_id} 场：第 {act_num} 幕收尾"
            else:
                title = f"第 {scene_id} 场：待生成"

            scene = {
                "id": f"scene_{scene_id:03d}",
                "scene_number": scene_id,
                "title": title,
                "act": act_num,
                "sequence": (i // 8) + 1,  # 每8场为一个序列
                "target_words": words_per_scene,
                "status": "pending",  # pending/outline/completed
                "outline_file": "data/scene_outlines.yaml",
                "content_file": f"data/scenes/scene_{scene_id:03d}.md",
                "content_file_abs": str(Path.cwd() / f"data/scenes/scene_{scene_id:03d}.md"),
                "dependencies": [],
                "characters": [],
                "plot_points": [],
                "location": "",
                "time": "",
                "is_key_scene": False
            }

            scenes.append(scene)
            scene_id += 1

    return scenes

def generate_scene_outlines_template(scenes):
    """生成场景大纲模板"""
    outlines = {}

    for scene in scenes:
        scene_id = scene['id']
        outlines[scene_id] = {
            'title': scene['title'],
            'summary': f'场景 {scene["scene_number"]} 的核心情节（待生成）',
            'characters': [],  # 出场角色
            'location': '',    # 地点
            'time': '',        # 时间
            'plot_points': [], # 情节点
            'emotional_tone': '',  # 情感基调
            'conflict': '',    # 冲突类型
            'purpose': '',     # 场景作用
            'target_words': scene['target_words'],
            'key_moments': [],  # 关键瞬间
            'notes': '写作注意事项'
        }

    return outlines

def generate_relationships_template(scenes):
    """生成场景关系图模板"""
    relationships = {}

    for i, scene in enumerate(scenes):
        scene_id = scene['id']
        scene_num = scene['scene_number']

        # 确定前后关系
        prev_scene = scenes[i-1]['id'] if i > 0 else None
        next_scene = scenes[i+1]['id'] if i < len(scenes) - 1 else None

        relationships[scene_id] = {
            'scene_number': scene_num,
            'prev_scene': prev_scene,
            'next_scene': next_scene,
            'related_scenes': [],  # 关联场景（呼应、对比等）
            'character_arcs': {},   # 角色弧光
            'plot_threads': [],    # 情节线索
            'dependencies': [],     # 依赖前置场景
            'payoff_scenes': []     # 铺垫后续场景
        }

    return relationships

def generate_scenes_metadata():
    """生成场景元数据索引文件"""
    print("正在生成场景元数据索引...")

    # 加载状态
    status = load_status()
    if not status:
        return False

    target_words = status.get('target_words', 90000)
    target_scenes = status.get('target_scenes', 95)

    # 生成场景结构
    scenes = generate_scenes_structure(target_words, target_scenes)

    # 保存 scenes.json
    if not save_file_to_project('data/scenes.json', json.dumps({
        "total_scenes": target_scenes,
        "target_words": target_words,
        "scenes": scenes
    }, ensure_ascii=False, indent=2)):
        print("错误: 保存 scenes.json 失败")
        return False

    print(f"✓ 场景元数据已保存: data/scenes.json")

    # 生成大纲模板
    outlines = generate_scene_outlines_template(scenes)
    if not save_file_to_project('data/scene_outlines.yaml', yaml.dump(outlines, allow_unicode=True, default_flow_style=False, sort_keys=False)):
        print("错误: 保存 scene_outlines.yaml 失败")
        return False

    print(f"✓ 场景大纲模板已保存: data/scene_outlines.yaml")

    # 生成关系图模板
    relationships = generate_relationships_template(scenes)
    if not save_file_to_project('data/scene_relationships.yaml', yaml.dump({
        "relationships": relationships,
        "notes": "编辑此文件来定义场景间关系"
    }, allow_unicode=True, default_flow_style=False, sort_keys=False)):
        print("错误: 保存 scene_relationships.yaml 失败")
        return False

    print(f"✓ 场景关系图已保存: data/scene_relationships.yaml")

    # 保存到状态
    update_status('scenes_metadata_created')

    return True

def generate_human_readable_plan():
    """生成人类可读的扩写计划文档"""
    print("正在生成人类可读的计划文档...")

    content = """# 剧本扩写计划

## 场景管理架构

本项目采用**单场景独立文件**架构，共95个场景，每个场景独立管理。

### 核心文件说明

1. **data/scenes.json** - 场景元数据索引
   - 包含所有95个场景的基本信息
   - 记录每个场景的状态、字数目标、文件路径等

2. **data/scene_outlines.yaml** - 场景大纲缓存
   - 每个场景的详细大纲和写作指导
   - 可手动编辑以调整写作方向

3. **data/scene_relationships.yaml** - 场景关系图
   - 定义场景间的前后台、依赖、呼应关系
   - 用于保持剧本连贯性

4. **data/scenes/scene_XXX.md** - 场景内容文件（生成时创建）
   - 每个场景的完整内容
   - 按需生成，写到哪生成到哪

### 工作流程

```bash
# 1. 生成场景元数据（已完成）
# 2. 生成单场景大纲
python scripts/generate_scene_outline.py --scene 1

# 3. 扩写单个场景（逐个进行）
python scripts/expand_scene.py --scene 1
python scripts/expand_scene.py --scene 2

# 4. 合并剧本
python scripts/compile_screenplay.py
```

### 场景分布

| 幕 | 场景数 | 字数目标 | 场景范围 |
|---|---|---|---|
| 第一幕 | 24场 | ~22,500字 | 场景1-24 |
| 第二幕 | 47场 | ~45,000字 | 场景25-71 |
| 第三幕 | 24场 | ~22,500字 | 场景72-95 |

## 状态跟踪

查看整体进度：
```bash
python scripts/status_manager.py --status
```

查看单个场景详情：
```bash
python scripts/status_manager.py --scene 5
```

---

*本计划基于剧本分析自动生成*
"""

    if not save_file_to_project('data/expansion_plan.md', content):
        print("错误: 保存 expansion_plan.md 失败")
        return False

    print(f"✓ 人类可读计划已保存: data/expansion_plan.md")

    return True

def main():
    """主函数"""
    print("="*70)
    print("场景管理架构 - 扩写计划生成")
    print("="*70)
    print()

    # 确保目录存在
    Path('data').mkdir(parents=True, exist_ok=True)

    # 生成场景元数据
    if not generate_scenes_metadata():
        print("错误: 场景元数据生成失败")
        return

    print()

    # 生成人类可读计划
    if not generate_human_readable_plan():
        print("错误: 计划文档生成失败")
        return

    print()
    print("✅ 场景管理架构创建完成！")
    print()
    print("下一步操作:")
    print("  1. 查看数据文件:")
    print("     - data/scenes.json (场景元数据)")
    print("     - data/scene_outlines.yaml (大纲模板)")
    print("     - data/scene_relationships.yaml (关系图)")
    print()
    print("  2. 生成单场景大纲:")
    print("     python scripts/generate_scene_outline.py --scene 1")
    print()
    print("  3. 开始扩写场景:")
    print("     python scripts/expand_scene.py --scene 1")
    print()

    # 更新状态
    update_status('scenes_planning')

if __name__ == '__main__':
    main()
