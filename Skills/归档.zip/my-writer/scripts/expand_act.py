#!/usr/bin/env python3
"""
分幕扩写脚本
支持断点续作和字数目标追踪，确保完成指定字数
"""
import sys
import json
import re
from pathlib import Path
from status_manager import load_status, update_status
from word_counter import count_words, count_scenes

# 添加项目目录参数支持
import argparse

def load_file_safe(file_path):
    """安全加载文件，如果不存在则创建空文件"""
    path = Path(file_path)

    # 如果文件不存在，创建空的
    if not path.exists():
        print(f"文件不存在，将创建: {file_path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write("")
        return ""

    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        return None

def save_file(file_path, content):
    """保存文件"""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ 文件已保存: {path.name}")
        return True
    except Exception as e:
        print(f"错误: 保存文件失败 - {e}")
        return False

def load_expansion_plan():
    """加载扩写计划"""
    plan_path = Path('data/expansion_plan.md')
    if not plan_path.exists():
        print("错误: 找不到扩写计划文件 'data/expansion_plan.md'")
        print("请先运行: python scripts/generate_plan.py")
        return None

    try:
        with open(plan_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        return None

def determine_scene_range(act_number, status):
    """确定当前需要扩写的场景范围"""
    act_field = f'act{act_number}_completed_scenes'
    completed = status.get(act_field, 0)

    # 每幕的场景范围（基于三幕式）
    act_ranges = {
        1: (1, 16),
        2: (17, 64),
        3: (65, 95)
    }

    if act_number not in act_ranges:
        print(f"错误: 无效的幕号 {act_number}")
        return None, None

    start_scene, end_scene = act_ranges[act_number]

    # 如果已完成所有场景，返回 None
    if completed >= (end_scene - start_scene + 1):
        print(f"✓ 第 {act_number} 幕所有场景已完成 ({completed} 场)")
        return None, None

    # 确定起始场景
    current_start = start_scene + completed

    # 计算批次大小（每次处理 10 场，避免任务中断）
    batch_size = 10
    current_end = min(current_start + batch_size - 1, end_scene)

    return current_start, current_end

def simulate_expansion(previous_content, act_number, start_scene, end_scene):
    """模拟剧本扩写（实际应调用 Claude API）"""
    print(f"\n{'='*70}")
    print(f"开始扩写第 {act_number} 幕: 场景 {start_scene}-{end_scene}")
    print(f"{'='*70}\n")

    # 加载扩写计划
    plan = load_expansion_plan()
    if not plan:
        return None

    # 这里实际应该调用 Claude API
    # 模拟输出

    expanded_content = f"""

<!-- 第 {act_number} 幕扩写, 场景 {start_scene}-{end_scene} -->
<!-- 目标字数: {(end_scene - start_scene + 1) * 1000} 字 -->

## 第 {start_scene} 场 <场景标题>

场景描述: [此场景需要详细描写]

**角色**: [列出出场角色]

**情节**: [描述场景中的动作和对白]

**主题关联**: [说明场景如何推进主题]

[在此展开详细内容, 目标字数 800-1200 字]

---

## 第 {start_scene + 1} 场 <场景标题>

[继续下一场...]

[在此展开详细内容]

---

## 第 {start_scene + 2} 场 <场景标题>

[继续生成更多场景...]

[注: 此处应继续生成到第 {end_scene} 场]

<!-- 第 {act_number} 幕扩写片段完成 -->
<!-- 完成场景数: {end_scene - start_scene + 1} -->
<!-- 注: 实际使用时，Claude 会为每一场生成完整内容 -->

**续写说明**: 在下一步中，将继续生成剩余场景。请运行:
```bash
python scripts/expand_act.py --act {act_number}
```
"""

    # 将新内容与之前的内容合并
    full_content = previous_content + expanded_content

    print(f"✓ 完成场景 {start_scene}-{end_scene} 的扩写")
    print(f"  - 起始场景: {start_scene}")
    print(f"  - 结束场景: {end_scene}")
    print(f"  - 本次完成: {end_scene - start_scene + 1} 场")

    return full_content

def expand_act(act_number):
    """扩写指定幕"""
    print(f"\n{'='*70}")
    print(f"扩写第 {act_number} 幕")
    print(f"{'='*70}\n")

    # 加载状态
    status = load_status()
    if not status:
        print("错误: 无法加载状态文件")
        return False

    # 确定输入输出文件
    if act_number == 1:
        input_file = 'data/storyboard_src.md'
        output_file = 'output/act1.md'
    elif act_number == 2:
        input_file = 'output/act1.md'
        output_file = 'output/act2.md'
    elif act_number == 3:
        input_file = 'output/act2.md'
        output_file = 'output/final_screenplay.md'
    else:
        print("错误: 幕号必须是 1、2 或 3")
        return False

    # 加载现有内容（如果不存在则创建）
    previous_content = load_file_safe(input_file)
    if previous_content is None:
        return False

    print(f"加载已存在内容: {input_file}")

    # 确定当前需要扩写的场景范围
    start_scene, end_scene = determine_scene_range(act_number, status)
    if not start_scene:
        # 当前幕已完成，更新状态
        next_step = f'act{act_number}_completed'
        if act_number < 3:
            next_start = act_number + 1
            print(f"\n✓ 第 {act_number} 幕完成！")
            print(f"下一步: 扩写第 {next_start} 幕")
            print(f"  python scripts/expand_act.py --act {next_start}")
        else:
            next_step = 'all_acts_completed'
            print(f"\n✓ 第 3 幕完成！所有幕已完成！")
            print("下一步: 剧本润色")
            print("  python scripts/polish_screenplay.py")

        update_status(next_step)
        return True

    # 执行扩写
    expanded_content = simulate_expansion(
        previous_content, act_number,
        start_scene, end_scene
    )

    if not expanded_content:
        print("错误: 扩写失败")
        return False

    # 保存输出
    if not save_file(output_file, expanded_content):
        print("错误: 保存文件失败")
        return False

    # 统计字数
    words = count_words(expanded_content)
    scenes = count_scenes(expanded_content)

    # 更新状态
    completed_field = f'act{act_number}_completed_scenes'
    previously_completed = status.get(completed_field, 0)
    now_completed = previously_completed + (end_scene - start_scene + 1)

    # 更新状态
    update_status(
        f'expanding_act{act_number}',
        **{
            completed_field: now_completed,
            'current_act': act_number,
            'last_batch_start': start_scene,
            'last_batch_end': end_scene,
            'total_words': status.get('total_words', 0) + words
        }
    )

    # 显示进度
    print(f"\n{'='*70}")
    print("扩写进度报告")
    print(f"{'='*70}")
    print(f"当前幕: 第 {act_number} 幕")
    print(f"完成范围: 场景 {start_scene}-{end_scene}")
    print(f"本批次完成: {end_scene - start_scene + 1} 场")
    print(f"本批次字数: {words:,} 字")
    print(f"第 {act_number} 幕累计完成: {now_completed} 场")
    print()
    print(f"输出文件: {output_file}")
    print(f"{'='*70}")
    print()

    # 提示下一步
    next_start, next_end = determine_scene_range(act_number, load_status())
    if next_start:
        print(f"继续扩写第 {act_number} 幕剩余场景...")
        print(f"  下次将完成: 场景 {next_start}-{next_end}")
        print()
        print(f"运行命令继续:")
        print(f"  python scripts/expand_act.py --act {act_number}")
    else:
        print(f"✓ 第 {act_number} 幕全部完成！")
        if act_number < 3:
            next_act = act_number + 1
            print(f"\n开始扩写第 {next_act} 幕:")
            print(f"  python scripts/expand_act.py --act {next_act}")
        else:
            print("\n🎉 所有幕已完成！")
            print("下一步: 剧本润色和优化")
            print("  python scripts/polish_screenplay.py")

    return True

def main():
    if len(sys.argv) < 2 or '--act' not in sys.argv:
        print("用法:")
        print("  python expand_act.py --act <幕号>")
        print()
        print("示例:")
        print("  python expand_act.py --act 1    # 扩写第一幕")
        print("  python expand_act.py --act 2    # 扩写第二幕")
        print("  python expand_act.py --act 3    # 扩写第三幕")
        print()
        print("功能说明:")
        print("  - 支持断点续作（会自动加载已完成内容）")
        print("  - 自动管理场景批次（每次处理 10 场）")
        print("  - 实时更新进度状态")
        print("  - 自动追踪目标字数")
        return

    try:
        act_idx = sys.argv.index('--act')
        act_number = int(sys.argv[act_idx + 1])
    except:
        print("错误: 幕号参数不正确")
        return

    if act_number not in [1, 2, 3]:
        print("错误: 幕号必须是 1、2 或 3")
        return

    print("="*70)
    print(f"剧本扩写工具 - 第 {act_number} 幕")
    print("="*70)
    print()

    success = expand_act(act_number)

    if success:
        print("\n✅ 扩写任务执行完成！")
    else:
        print("\n❌ 扩写任务失败，请检查错误信息")
        sys.exit(1)

if __name__ == '__main__':
    main()
