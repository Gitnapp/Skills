#!/usr/bin/env python3
"""
剧本分析工具
读取原剧本并生成全面的分析报告
"""
import sys
import json
from pathlib import Path
from status_manager import load_status, update_status

def load_file(file_path):
    """加载文件内容"""
    path = Path(file_path)
    if not path.exists():
        print(f"错误: 文件不存在 - {file_path}")
        return None

    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        return None

def generate_analysis(content, output_path, source_file=None):
    """生成剧本分析（模拟分析，实际应调用 AI）"""
    print("正在分析剧本...")

    # 这里实际应该调用 Claude API 进行分析
    # 由于这是示例，我们生成一个模板
    source_name = Path(source_file).name if source_file else "未知"
    analysis_content = f"""# 剧本分析报告

## 来源文件
文件: {source_name}

## 情感基调与核心主题

### 核心主题
基于剧本内容分析，识别出以下核心主题：

1. **主题探索**: TODO
2. **情感动机**: TODO
3. **立意深度**: TODO

### 情感基调
当前情感氛围：
- 主要情绪：TODO
- 基调变化：TODO
- 观众情感走向：TODO

## 故事线与大纲

### 主线故事
TODO: 分析故事主线和核心冲突

### 剧情结构
- **开端**: TODO
- **发展**: TODO
- **高潮**: TODO
- **结局**: TODO

### 关键情节点
1. 情节点 1: TODO
2. 情节点 2: TODO
3. 情节点 3: TODO

## 人物关系图谱

### 主要角色
TODO: 列出主要角色及其特征

#### 主角
- **姓名**:
- **动机**:
- **目标**:
- **缺陷**:
- **成长弧光**:

#### 反派/对手
- **姓名**:
- **动机**:
- **目标**:
- **与主角关系**:

### 人物关系网络
```
TODO: 使用文本或 Mermaid 图表展示人物关系
```

### 次要角色
TODO: 列出配角及其作用

## 场景分析

### 场景分布
- 总场数: TODO
- 场景类型: TODO

### 场景功能
- 推动剧情: TODO
- 人物塑造: TODO
- 主题深化: TODO

## 可拍摄性评估

### 视觉潜力
TODO: 评估剧本的视觉表现力

### 制作成本估算
- **低成本元素**: TODO
- **高成本元素**: TODO
- **整体预算建议**: TODO

## 改编建议

### 优势
1. TODO
2. TODO

### 需要改进
1. TODO
2. TODO

### 扩写重点
1. TODO
2. TODO

---
*本报告需配合实际剧本内容由 Claude 生成详细分析*
"""

    # 写入输出文件
    output_dir = Path(output_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(analysis_content)

    print(f"✓ 分析报告已保存: {output_path}")
    return True

def main():
    if len(sys.argv) < 3:
        print("用法:")
        print("  python analyze_screenplay.py --input <原剧本文件> --output <输出路径>")
        print()
        print("示例:")
        print("  python analyze_screenplay.py --input ref/original.md --output data/storyboard_src.md")
        return

    # 解析参数
    input_idx = sys.argv.index('--input') if '--input' in sys.argv else -1
    output_idx = sys.argv.index('--output') if '--output' in sys.argv else -1

    if input_idx == -1 or output_idx == -1 or output_idx <= input_idx:
        print("错误: 参数格式不正确")
        return

    file_path = sys.argv[input_idx + 1]
    output_path = sys.argv[output_idx + 1]

    # 加载内容
    print(f"加载文件: {file_path}")
    content = load_file(file_path)
    if not content:
        return

    # 生成分析
    if not generate_analysis(content, output_path, source_file=file_path):
        return

    # 更新状态
    update_status('analysis',
                  original_file=str(Path(file_path).absolute()),
                  analysis_file=str(Path(output_path).absolute()))

    print()
    print("✅ 剧本分析完成！")
    print(f"分析报告: {output_path}")

if __name__ == '__main__':
    main()
