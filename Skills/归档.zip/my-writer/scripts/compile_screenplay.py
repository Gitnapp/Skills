#!/usr/bin/env python3
"""
剧本合并工具
读取所有场景文件并合并为完整剧本，生成多种格式
"""
import argparse
import json
from pathlib import Path
import yaml
from project_utils import get_project_path, save_file_to_project, load_file_from_project
from status_manager import load_status, update_status

def load_scenes_metadata():
    """加载场景元数据"""
    scenes_file = get_project_path('data/scenes.json')
    if not scenes_file.exists():
        print(f"错误: 场景元数据文件不存在 - {scenes_file}")
        print("请先运行: python scripts/generate_plan.py")
        return None

    try:
        with open(scenes_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"错误: 读取场景元数据失败 - {e}")
        return None

def load_scene_outlines():
    """加载场景大纲（用于生成剧本标题）"""
    outlines_file = get_project_path('data/scene_outlines.yaml')
    if not outlines_file.exists():
        print("警告: 场景大纲文件不存在，将使用默认标题")
        return None

    try:
        content = load_file_from_project('data/scene_outlines.yaml')
        if not content:
            return None
        return yaml.safe_load(content)
    except Exception as e:
        print(f"警告: 读取场景大纲失败 - {e}")
        return None

def load_scene_content(scene_number):
    """加载单个场景文件"""
    scene_file = get_project_path(f'data/scenes/scene_{scene_number:03d}.md')

    if not scene_file.exists():
        print(f"错误: 场景文件不存在: {scene_file}")
        return None

    try:
        with open(scene_file, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"错误: 读取场景文件失败 - {e}")
        return None

def compile_screenplay(scenes_per_act=None):
    """
    编译剧本：读取所有场景文件并合并

    参数:
        scenes_per_act: 每幕包含的场景数，如 [16, 48, 31] 对应三幕式
                     如果为 None，则不做幕的划分

    生成:
        - output/final_screenplay.md (完整剧本)
        - data/scenes_index.json (场景索引)
    """
    print(f"\n{'='*70}")
    print("剧本合并工具")
    print(f"{'='*70}\n")

    # 步骤1: 加载元数据
    print("步骤1: 加载场景元数据...")
    metadata = load_scenes_metadata()
    if not metadata:
        return False

    total_scenes = metadata['total_scenes']
    print(f"✓ 检测到 {total_scenes} 个场景\n")

    # 步骤2: 加载大纲
    print("步骤2: 加载场景大纲...")
    outlines = load_scene_outlines()
    if outlines:
        print("✓ 场景大纲已加载\n")
    else:
        print("✓ 使用默认标题\n")

    # 步骤3: 逐个读取场景文件
    print("步骤3: 读取场景文件...")
    scenes_content = []
    missing_scenes = []

    for i in range(1, total_scenes + 1):
        content = load_scene_content(i)
        if content:
            scenes_content.append((i, content))
        else:
            missing_scenes.append(i)

    completed_scenes = len(scenes_content)
    print(f"✓ 成功读取 {completed_scenes}/{total_scenes} 个场景\n")

    if missing_scenes:
        print(f"⚠ 缺失场景: {missing_scenes}")
        print(f"  请运行: python scripts/expand_scene.py --scene {'-'.join(map(str, [missing_scenes[0], missing_scenes[-1]]))}\n")

    # 步骤4: 生成剧本内容
    print("步骤4: 生成剧本内容...")

    # 剧本标题
    status = load_status()
    project_name = status.get('project_name', '电影剧本') if status else '电影剧本'

    screenplay_content = f"""# {project_name}

**剧本信息**
- 总场景数: {total_scenes} 场
- 完成场景数: {completed_scenes} 场
- 生成时间: {Path().cwd().as_posix()}

"""

    # 如果指定了幕结构，添加幕标题
    if scenes_per_act:
        current_act = 1
        current_scene_in_act = 0
        screenplay_content += f"## 第 {current_act} 幕\n\n"
    else:
        scenes_per_act = [total_scenes]

    # 逐个添加场景
    act_index = 0
    scenes_in_current_act = 0

    for scene_num, content in scenes_content:
        # 检查是否需要切换到下一幕
        if scenes_per_act and act_index < len(scenes_per_act):
            if scenes_in_current_act >= scenes_per_act[act_index]:
                act_index += 1
                scenes_in_current_act = 0
                if act_index < len(scenes_per_act):
                    screenplay_content += f"\n## 第 {act_index + 1} 幕\n\n"

        # 提取场景标题（从内容中获取）
        scene_title = f"场景 {scene_num}"
        if content.startswith('# 场景'):
            first_line = content.split('\n')[0]
            scene_title = first_line.replace('# ', '').strip()

        # 添加场景到剧本
        screenplay_content += f"<!-- ==================== {scene_title} ==================== -->\n\n"
        screenplay_content += content
        screenplay_content += "\n\n"

        scenes_in_current_act += 1

    print(f"✓ 剧本内容生成完成\n")

    # 步骤5: 统计字数
    print("步骤5: 统计字数...")
    total_words = sum(len(content.split()) for _, content in scenes_content)
    print(f"✓ 总字数: {total_words:,} 字\n")

    # 步骤6: 保存剧本文件
    print("步骤6: 保存剧本文件...")
    output_file = 'output/final_screenplay.md'
    if save_file_to_project(output_file, screenplay_content):
        print(f"✓ 剧本已保存: {output_file}\n")
    else:
        print(f"✗ 保存失败\n")
        return False

    # 步骤7: 生成场景索引
    print("步骤7: 生成场景索引...")
    scenes_index = []
    for scene_num, content in scenes_content:
        # 提取字数
        word_count = len(content.split())

        # 提取标题
        scene_title = f"场景 {scene_num}"
        if content.startswith('# 场景'):
            first_line = content.split('\n')[0]
            scene_title = first_line.replace('# ', '').strip()

        scenes_index.append({
            'scene_number': scene_num,
            'title': scene_title,
            'word_count': word_count,
            'file': f'data/scenes/scene_{scene_num:03d}.md',
            'status': 'completed'
        })

    # 添加缺失的场景
    for scene_num in missing_scenes:
        scenes_index.append({
            'scene_number': scene_num,
            'title': f'场景 {scene_num}',
            'word_count': 0,
            'file': f'data/scenes/scene_{scene_num:03d}.md',
            'status': 'missing'
        })

    # 按场景编号排序
    scenes_index.sort(key=lambda x: x['scene_number'])

    # 保存索引
    import json
    if save_file_to_project('data/scenes_index.json', json.dumps(scenes_index, ensure_ascii=False, indent=2)):
        print(f"✓ 场景索引已保存: data/scenes_index.json\n")
    else:
        print(f"⚠ 场景索引保存失败\n")

    # 步骤8: 更新状态
    print("步骤8: 更新项目状态...")
    update_status(
        'compilation_complete',
        total_scenes=total_scenes,
        completed_scenes=completed_scenes,
        output_file=output_file
    )
    print("✓ 状态更新完成\n")

    # 完成报告
    print(f"{'='*70}")
    print("剧本合并完成")
    print(f"{'='*70}")
    print(f"总场景数: {total_scenes}")
    print(f"已完成: {completed_scenes}")
    print(f"缺失: {len(missing_scenes)}")
    print(f"总字数: {total_words:,} 字")
    print(f"输出文件: {output_file}")
    print(f"{'='*70}\n")

    return True

def show_scenes_index():
    """显示场景索引"""
    index_file = get_project_path('data/scenes_index.json')
    if not index_file.exists():
        print("错误: 场景索引文件不存在，请先运行编译")
        return False

    try:
        with open(index_file, 'r', encoding='utf-8') as f:
            index = json.load(f)

        print(f"\n{'='*70}")
        print("场景索引")
        print(f"{'='*70}\n")

        total_scenes = len(index)
        completed_scenes = sum(1 for scene in index if scene['status'] == 'completed')
        total_words = sum(scene['word_count'] for scene in index)

        print(f"总场景: {total_scenes}")
        print(f"已完成: {completed_scenes}")
        print(f"总字数: {total_words:,} 字")
        print()
        print(f"{'='*70}")
        print(f"{'场景':<8} {'标题':<40} {'字数':<10} {'状态'}")
        print(f"{'='*70}")

        for scene in index:
            scene_num = str(scene['scene_number']).rjust(3)
            title = scene['title'][:38]
            word_count = f"{scene['word_count']:,}" if scene['word_count'] > 0 else "-"
            status = "✓" if scene['status'] == 'completed' else "✗"

            print(f"{scene_num:<8} {title:<40} {word_count:<10} {status}")

        print(f"{'='*70}\n")

        return True

    except Exception as e:
        print(f"错误: 读取索引失败 - {e}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description='剧本合并工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python compile_screenplay.py                           # 编译所有场景
  python compile_screenplay.py --index                   # 显示场景索引
  python compile_screenplay.py --act 16,48,31           # 按三幕式结构编译
        """
    )

    parser.add_argument('--index', action='store_true',
                       help='显示场景索引而不编译')
    parser.add_argument('--act', type=str,
                       help='按幕结构编译，格式: scene1,scene2,scene3（如：16,48,31）')

    args = parser.parse_args()

    if args.index:
        show_scenes_index()
        return

    # 解析幕结构
    scenes_per_act = None
    if args.act:
        try:
            scenes_per_act = list(map(int, args.act.split(',')))
            print(f"使用幕结构: {scenes_per_act}\n")
        except:
            print(f"错误: 无效的幕结构 '{args.act}'")
            return

    print(f"{'='*70}")
    print("剧本合并工具")
    print(f"{'='*70}")
    print()

    success = compile_screenplay(scenes_per_act)

    if success:
        print("\n✅ 剧本编译成功！")
        print("\n下一步建议:")
        print("  - 检查输出文件: cat output/final_screenplay.md")
        print("  - 查看场景索引: python scripts/compile_screenplay.py --index")
    else:
        print("\n❌ 编译失败，请检查错误信息")
        sys.exit(1)

if __name__ == '__main__':
    main()
