# 工作目录修复测试

## 测试步骤

### 准备工作

```bash
# 创建测试项目目录
mkdir -p ~/test_screenplay_project
cd ~/test_screenplay_project

# 确保 skill 脚本存在
ls ~/.claude/skills/my-writer/scripts/
```

### 测试 1: init_project.py

```bash
cd ~/test_screenplay_project
python ~/.claude/skills/my-writer/scripts/init_project.py
```

**预期结果**：
- ✅ 输出显示工作目录：`工作目录: /Users/admin/test_screenplay_project`
- ✅ 目录创建在测试项目目录：
  - `~/test_screenplay_project/ref/` ✅
  - `~/test_screenplay_project/output/` ✅
  - `~/test_screenplay_project/data/` ✅
- ✅ 配置文件创建在测试项目目录：
  - `~/test_screenplay_project/data/status.json` ✅
  - `~/test_screenplay_project/README.md` ✅
- ❌ 不应该在 skill 目录：`~/.claude/skills/my-writer/data/` ❌

**验证**：
```bash
ls -la ~/test_screenplay_project/
# 应该看到：ref/, output/, data/, README.md

ls ~/.claude/skills/my-writer/data/ 2>/dev/null
# 应该不存在或为空
```

### 测试 2: generate_plan.py

**准备工作**：
```bash
cd ~/test_screenplay_project
# 创建模拟的剧本分析文件
mkdir -p data
echo "# 剧本分析" > data/storyboard_src.md
```

**运行**：
```bash
python ~/.claude/skills/my-writer/scripts/generate_plan.py
```

**预期结果**：
- ✅ 文件创建在测试项目目录：
  - `~/test_screenplay_project/data/scenes.json` ✅
  - `~/test_screenplay_project/data/scene_outlines.yaml` ✅
  - `~/test_screenplay_project/data/scene_relationships.yaml` ✅
  - `~/test_screenplay_project/data/expansion_plan.md` ✅

**验证**：
```bash
ls ~/test_screenplay_project/data/
# 应该看到：scenes.json, scene_outlines.yaml, scene_relationships.yaml, expansion_plan.md

cat ~/test_screenplay_project/data/scenes.json | head -20
# 应该包含场景元数据
```

### 测试 3: generate_scene_outline.py

**运行**：
```bash
python ~/.claude/skills/my-writer/scripts/generate_scene_outline.py --scene 1
```

**预期结果**：
- ✅ 读取测试项目目录的 scenes.json
- ✅ 更新测试项目目录的 scene_outlines.yaml
- ❌ 不应该读取 skill 目录的 scenes.json

**验证**：
```bash
cat ~/test_screenplay_project/data/scene_outlines.yaml | grep "scene_001"
# 应该看到场景1的大纲
```

### 测试 4: status_manager.py

**运行**：
```bash
python ~/.claude/skills/my-writer/scripts/status_manager.py --status
```

**预期结果**：
- ✅ 读取测试项目目录的 data/status.json
- ✅ 显示正确的项目状态

**验证**：
```bash
cat ~/test_screenplay_project/data/status.json
# 应该显示状态信息

python ~/.claude/skills/my-writer/scripts/status_manager.py --set-name "测试项目"
# 应该更新 status.json

cat ~/test_screenplay_project/data/status.json | grep "project_name"
# 应该看到："project_name": "测试项目"
```

## 清理测试

```bash
# 删除测试目录
rm -rf ~/test_screenplay_project

# 确认 skill 目录未被污染
ls ~/.claude/skills/my-writer/
# 应该只有：SKILL.md, scripts/, references/
# 不应该有：data/, output/, ref/ 等运行时目录
```

## 自动化测试脚本

创建自动化测试脚本 `test_working_dir.sh`：

```bash
#!/bin/bash

set -e

TEST_DIR="$HOME/test_screenplay_project_$(date +%s)"
SKILL_DIR="$HOME/.claude/skills/my-writer"

echo "=========================================="
echo "测试工作目录修复"
echo "=========================================="
echo "测试目录: $TEST_DIR"
echo "Skill目录: $SKILL_DIR"
echo ""

# 创建测试目录
echo "1. 创建测试目录..."
mkdir -p "$TEST_DIR"
cd "$TEST_DIR"

# 测试1: init_project.py
echo "2. 测试 init_project.py..."
python "$SKILL_DIR/scripts/init_project.py"

if [ -d "$TEST_DIR/data" ] && [ -f "$TEST_DIR/data/status.json" ]; then
    echo "   ✅ 目录和文件创建在测试目录"
else
    echo "   ❌ 失败：文件未创建在测试目录"
    exit 1
fi

# 测试2: generate_plan.py (需要 storyboard_src.md)
echo "3. 准备 generate_plan.py 测试..."
echo "# 剧本分析" > "$TEST_DIR/data/storyboard_src.md"

echo "4. 测试 generate_plan.py..."
python "$SKILL_DIR/scripts/generate_plan.py"

if [ -f "$TEST_DIR/data/scenes.json" ]; then
    echo "   ✅ scenes.json 创建在测试目录"
else
    echo "   ❌ 失败：scenes.json 未创建"
    exit 1
fi

# 测试3: generate_scene_outline.py
echo "5. 测试 generate_scene_outline.py..."
python "$SKILL_DIR/scripts/generate_scene_outline.py" --scene 1

if grep -q "scene_001" "$TEST_DIR/data/scene_outlines.yaml" 2>/dev/null; then
    echo "   ✅ 大纲生成成功"
else
    echo "   ❌ 失败：大纲未生成"
    exit 1
fi

# 测试4: status_manager.py
echo "6. 测试 status_manager.py..."
python "$SKILL_DIR/scripts/status_manager.py" --set-name "测试项目"

if grep -q "测试项目" "$TEST_DIR/data/status.json" 2>/dev/null; then
    echo "   ✅ 状态更新成功"
else
    echo "   ❌ 失败：状态未更新"
    exit 1
fi

# 清理
echo "7. 清理测试目录..."
cd "$HOME"
rm -rf "$TEST_DIR"

echo ""
echo "=========================================="
echo "✅ 所有测试通过！"
echo "=========================================="
```

运行测试：
```bash
chmod +x test_working_dir.sh
./test_working_dir.sh
```

## 预期问题及解决方案

### 问题1: 模块导入错误

**症状**：
```
ModuleNotFoundError: No module named 'project_utils'
```

**原因**：脚本运行时找不到 project_utils.py

**解决方案**：
在测试时使用完整路径或设置 PYTHONPATH：
```bash
export PYTHONPATH="~/.claude/skills/my-writer/scripts:$PYTHONPATH"
python ~/.claude/skills/my-writer/scripts/init_project.py
```

### 问题2: 文件权限错误

**症状**：
```
PermissionError: [Errno 13] Permission denied: '/data/status.json'
```

**原因**：当前用户没有权限创建文件

**解决方案**：确保测试目录有写权限
```bash
chmod 755 ~/test_screenplay_project
```

### 问题3: YAML 模块未安装

**症状**：
```
ModuleNotFoundError: No module named 'yaml'
```

**解决方案**：安装 PyYAML
```bash
pip install PyYAML
# 或
uv add PyYAML
```

## 成功标准

✅ **全部满足表示修复成功**：

1. 所有脚本在用户项目目录生成文件
2. 不在 skill 安装目录生成文件
3. 状态管理正确读写用户项目目录的 status.json
4. generate_plan.py 生成的文件在用户项目目录的 data/ 下
5. generate_scene_outline.py 正确读写用户项目目录的 YAML 文件
6. 所有路径显示为用户的项目目录路径

## 测试完成后的清理

```bash
# 删除测试目录
rm -rf ~/test_screenplay_project

# 确认 skill 目录干净
ls ~/.claude/skills/my-writer/
# 应该只有：
# - SKILL.md
# - scripts/
# - references/

# 不应该有运行时目录：
ls ~/.claude/skills/my-writer/data/ 2>/dev/null || echo "✅ 干净，无 data 目录"
ls ~/.claude/skills/my-writer/output/ 2>/dev/null || echo "✅ 干净，无 output 目录"
ls ~/.claude/skills/my-writer/ref/ 2>/dev/null || echo "✅ 干净，无 ref 目录"
```
