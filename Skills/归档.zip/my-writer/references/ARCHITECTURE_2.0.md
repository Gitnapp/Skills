# My-Writer Skill 架构 2.0 升级说明

## 升级背景

My-Writer Skill 1.0 存在以下问题：

1. **上下文窗口限制**：一次性生成多个场景导致 Claude API token 超限
2. **输出文件庞大**：单个幕文件过大，难以编辑和修改
3. **无法精细控制**：无法单独修改某个场景，必须重新生成整个幕
4. **输入上下文累积**：随着剧本增长，输入前文越来越多，最终导致生成失败

## 架构 2.0 核心改进

### 1. 单场景独立文件管理

**问题**：10个场景同时生成导致 token 超限（10 × 1000字 = 10000字 + 20000字前文 = 30000字节）

**解决方案**：
- 每个场景独立为单独文件（scene_001.md, scene_002.md, ..., scene_095.md）
- 每次只生成1个场景，输入控制在 2000 字以内
- 总字数 90000 字的项目，每个场景 900-1200 字，独立处理

### 2. 分两阶段生成

**阶段一：大纲生成**
- 先生成场景大纲（约200字）
- 输入：场景编号 + 剧本分析 + 关系图局部
- 调用 API 生成大纲并保存到 `scene_outlines.yaml`
- 人工可读，可编辑调整

**阶段二：正文扩写**
- 基于大纲生成完整场景（约900字）
- 输入：大纲 + 前1-2个场景结尾（连贯性）
- 输出：单个场景文件 `scene_NNN.md`
- 每次调用控制在 2000字输入 + 1000字输出 = 3000 字以内

### 3. 智能上下文控制

**输入内容精简**：
```
1. 当前场景大纲（200字）
2. 前1-2个场景结尾（500字）
3. 关键关系节点（100字）
总计：800字输入 + 大纲推理 = 2000字以内
```

**避免上下文累积**：
- 不携带全部前文（只带1-2场景）
- 通过大纲和关系图保持连贯性
- 场景间关系记录在 `scene_relationships.yaml`

### 4. 数据文件架构

```
data/
├── scenes.json                  # 场景元数据索引（8KB）
├── scene_outlines.yaml          # 大纲缓存（30KB）
├── scene_relationships.yaml     # 关系图
├── scenes/                      # 场景内容（按需生成）
│   ├── scene_001.md            # 场景1：900-1200字
│   ├── scene_002.md            # 场景2：900-1200字
│   └── ...                     # 共95个文件（约90KB/场景）
└── status.json                  # 进度状态
```

**体积对比**：
- 传统方式：output/act1.md = 22500 字节（单个文件过大）
- 新架构：95个文件，每个约 1-2 KB，合并时流式读取

### 5. 断点续写和增量更新

**状态跟踪**：
```json
{
  "current_step": "scene_45_generated",
  "last_scene": 45,
  "scenes_completed": 45,
  "scenes": [
    {"id": "scene_001", "status": "completed", "words": 950},
    {"id": "scene_002", "status": "completed", "words": 1020},
    ...
  ]
}
```

**优点**：
- 中断后从 `last_scene + 1` 继续
- 单个场景可重新生成：`regenerate_scene.py --scene 5`
- 支持并行生成（多个 Claude 实例）
- 版本控制和 diff 友好

## 工作流程对比

### 旧流程（1.0）
```bash
# 生成10个场景 at once（高风险）
python scripts/expand_act.py --act 1
# 输出：output/act1.md (22500字)
```

**问题**：
- Token 超限风险
- 无法单独修改场景3
- 中断后重新开始

### 新流程（2.0）
```bash
# 步骤3：生成场景元数据（95个场景的框架）
python scripts/generate_plan.py
# 输出：data/scenes.json

# 步骤4.1：生成大纲（逐个）
python scripts/generate_scene_outline.py --scene 1
# 输出：大纲保存到 scene_outlines.yaml

# 步骤4.2：扩写场景（逐个）
python scripts/expand_scene.py --scene 1
# 输入：大纲 + 前文结尾(2场景)
# 输出：data/scenes/scene_001.md

# 步骤5：合并剧本
python scripts/compile_screenplay.py
# 读取95个场景文件，合并到 output/final_screenplay.md
```

**改进**：
- 每次 API 调用控制在 2000 字输入以内
- 可单独修改/重写任一场景
- 写到哪生成到哪（lazy generation）
- 支持断点续写

## 性能指标

### Token 使用
| 操作 | Token 输入 | Token 输出 | 总计 | 风险 |
|------|-----------|-----------|------|------|
| 旧架构：生成10场景 | 20000 | 10000 | 30000 | 高风险 |
| 新架构：单场景 | 2000 | 1000 | 3000 | 安全 |
| 新架构：单大纲 | 1500 | 300 | 1800 | 安全 |

### 时间成本
- 单次生成：10秒/场景 × 95场景 = 950秒 ≈ 16分钟
- 实际使用：边写边生成，分散在多时段完成
- 重新生成：只需重新生成特定场景（1分钟）

## 使用示例

### 场景1：项目初始化
```bash
# 创建项目结构和生成元数据
python scripts/main.py init
python scripts/main.py plan

# 检查生成的数据文件
ls -lh data/scenes.json
ls -lh data/scene_outlines.yaml
ls -lh data/scene_relationships.yaml
```

### 场景2：生成场景大纲
```bash
# 生成场景1-5的大纲
python scripts/generate_scene_outline.py --scene 1-5

# 查看大纲
python scripts/generate_scene_outline.py --scene 3 --show

# 手动编辑大纲（可选）
vim data/scene_outlines.yaml
```

### 场景3：逐个扩写
```bash
# 扩写场景1
python scripts/expand_scene.py --scene 1
# 检查输出
cat data/scenes/scene_001.md

# 继续场景2（自动加载场景1的结尾）
python scripts/expand_scene.py --scene 2

# 中断后恢复（从场景3继续）
python scripts/expand_scene.py --scene 3
```

### 场景4：修改和重新生成
```bash
# 发现场景5需要重写
python scripts/regenerate_scene.py --scene 5

# 或者手动编辑场景文件
vim data/scenes/scene_005.md

# 重新合并
python scripts/compile_screenplay.py
# 输出：output/final_screenplay.md (90000字)
```

## 迁移指南

从 1.0 迁移到 2.0：

1. **备份旧数据**（可选）：
   ```bash
   mv output output_v1
   mv data data_v1
   ```

2. **重新生成项目结构**：
   ```bash
   python scripts/main.py init
   ```

3. **生成新架构**：
   ```bash
   python scripts/generate_plan.py
   ```

4. **开始按新流程写作**：
   ```bash
   python scripts/generate_scene_outline.py --scene 1
   python scripts/expand_scene.py --scene 1
   ```

## 总结

架构 2.0 通过以下方式解决上下文窗口限制：

1. ✅ **单场景处理**：每次只生成1个场景，token 使用量降低 70%
2. ✅ **分阶段生成**：大纲 + 正文，降低单次复杂度
3. ✅ **智能上下文**：只带必要前文，避免累积
4. ✅ **增量更新**：可单独修改任一场景，灵活可控
5. ✅ **断点续写**：抗中断，写到哪算哪

**核心价值**：让 90000 字的长剧本写作不再受 API token 限制，实现精细化控制和高质量输出。
