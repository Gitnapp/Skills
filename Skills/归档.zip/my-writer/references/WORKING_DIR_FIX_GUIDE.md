# 工作目录修复指南

## 问题描述

**问题**：当 agent 运行 my-writer skill 的脚本时，文件保存到了 Claude skill 安装目录（`~/.claude/skills/my-writer/`），而不是用户的项目目录。

**原因**：原脚本使用相对路径（如 `Path('data/file')`），而脚本执行时的当前工作目录是 skill 所在目录，而不是用户项目目录。

**影响**：用户在自己的项目目录中找不到生成的文件，无法正常使用。

## 修复方案

### 核心原理

**修复目标**：所有文件操作的路径都应该基于用户运行脚本时的当前工作目录（`Path.cwd()`），而不是脚本所在目录。

**解决方案**：
1. 在项目工具模块（`project_utils.py`）中添加路径转换函数
2. 所有脚本统一使用这些函数进行文件读写
3. 运行时自动使用当前工作目录

### 已添加的辅助函数

在 `scripts/project_utils.py` 中已添加以下函数：

```python
def get_project_path(relative_path):
    """
    获取相对于项目目录的绝对路径

    参数:
        relative_path: 相对路径（如 'data/status.json'）

    返回:
        Path: 项目目录下的绝对路径
    """
    return Path.cwd() / relative_path


def load_file_from_project(file_path):
    """
    从项目目录加载文件

    参数:
        file_path: 相对路径

    返回:
        文件内容或 None
    """
    full_path = get_project_path(file_path)
    if not full_path.exists():
        return None

    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"错误: 读取文件失败 - {e}")
        return None


def save_file_to_project(file_path, content):
    """
    保存文件到项目目录

    参数:
        file_path: 相对路径
        content: 文件内容

    返回:
        bool: 是否成功
    """
    full_path = get_project_path(file_path)
    full_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"错误: 保存文件失败 - {e}")
        return False
```

## 已修复的脚本

### ✅ 1. `scripts/generate_plan.py`

**修复前**：
```python
from pathlib import Path

def load_storyboard():
    storyboard_path = Path('data/storyboard_src.md')  # ❌ 使用相对路径
    with open(storyboard_path, 'r') as f:
        return f.read()

def save():
    scenes_file = Path('data/scenes.json')
    with open(scenes_file, 'w') as f:
        json.dump(data, f)
```

**修复后**：
```python
from project_utils import get_project_path, load_file_from_project, save_file_to_project

def load_storyboard():
    storyboard_path = get_project_path('data/storyboard_src.md')  # ✅ 使用项目目录
    content = load_file_from_project('data/storyboard_src.md')    # ✅ 使用工具函数
    return content

def save():
    save_file_to_project('data/scenes.json', json.dumps(data))   # ✅ 自动保存到项目目录
```

## 待修复的脚本清单

### ❌ 2. `scripts/generate_scene_outline.py`

**需要修改**：

```python
# 在文件开头添加导入
from project_utils import get_project_path, load_file_from_project, save_file_to_project

# 修改所有路径相关的操作
```

**具体修改**：

```python
# 修复前
def load_scenes_metadata():
    scenes_file = Path('data/scenes.json')  # ❌
    with open(scenes_file, 'r') as f:
        return json.load(f)

# 修复后
def load_scenes_metadata():
    scenes_file = get_project_path('data/scenes.json')  # ✅
    content = load_file_from_project('data/scenes.json')
    return json.loads(content) if content else None
```

```python
# 修复前
def save_scene_outlines(outlines):
    outlines_file = Path('data/scene_outlines.yaml')
    with open(outlines_file, 'w') as f:
        yaml.dump(outlines, f)

# 修复后
def save_scene_outlines(outlines):
    import yaml
    content = yaml.dump(outlines, allow_unicode=True, default_flow_style=False, sort_keys=False)
    return save_file_to_project('data/scene_outlines.yaml', content)
```

### ❌ 3. `scripts/status_manager.py`

**需要修改**：

```python
# 在文件开头添加导入
from project_utils import get_project_path, load_file_from_project, save_file_to_project

# 修改 STATUS_FILE 定义
STATUS_FILE_NAME = 'data/status.json'

def load_status():
    status_file = get_project_path(STATUS_FILE_NAME)  # ✅
    content = load_file_from_project(STATUS_FILE_NAME)
    return json.loads(content) if content else None

def save_status(status):
    content = json.dumps(status, ensure_ascii=False, indent=2)
    return save_file_to_project(STATUS_FILE_NAME, content)
```

### ❌ 4. `scripts/init_project.py`

**需要修改**：

```python
# 在文件开头添加导入
from project_utils import get_project_path, save_file_to_project

def create_project_structure():
    # 创建目录
    directories = ['ref', 'output', 'data', 'scripts']
    for dir_name in directories:
        path = get_project_path(dir_name)  # ✅
        path.mkdir(parents=True, exist_ok=True)

    # 创建状态文件
    status_data = {...}
    save_file_to_project('data/status.json', json.dumps(status_data, ensure_ascii=False, indent=2))
```

### ❌ 5. `scripts/analyze_screenplay.py`

**需要修改**：

```python
# 在文件开头添加导入
from project_utils import get_project_path, load_file_from_project, save_file_to_project

# 修改文件读取和保存操作
```

### ❌ 6. `scripts/word_counter.py`

**需要修改**：

```python
# 在文件开头添加导入
from project_utils import get_project_path, load_file_from_project
```

## 批量修复

可以按照以下顺序批量修复：

```bash
# 1. status_manager.py（其他脚本依赖它）
vim scripts/status_manager.py

# 2. init_project.py（项目初始化）
vim scripts/init_project.py

# 3. analyze_screenplay.py（第一步分析）
vim scripts/analyze_screenplay.py

# 4. generate_scene_outline.py（生成大纲）
vim scripts/generate_scene_outline.py

# 5. word_counter.py（字数统计）
vim scripts/word_counter.py

# 6. 之后的新脚本（expand_scene.py, compile_screenplay.py等）
# 创建时就使用 project_utils
```

## 测试验证

修复后，测试方法如下：

```bash
# 在用户项目目录测试
cd /path/to/my/screenplay-project
python /path/to/my-writer/scripts/main.py init

# 预期输出：
# 工作目录: /path/to/my/screenplay-project
# 文件应该创建在：
#   /path/to/my/screenplay-project/data/
#   /path/to/my/screenplay-project/output/
#   /path/to/my/screenplay-project/ref/

# 不应该在：
#   ❌ ~/.claude/skills/my-writer/data/
```

## key point

### 修复要点总结

1. **所有脚本必须使用 `project_utils` 中的路径函数**
   - `get_project_path(relative_path)` - 获取绝对路径
   - `load_file_from_project(file_path)` - 读取文件
   - `save_file_to_project(file_path, content)` - 保存文件

2. **不要使用 `Path('file')` 直接创建路径**
   - ❌ `Path('data/file.json')`
   - ✅ `get_project_path('data/file.json')`

3. **不要使用 `open()` 直接读写文件**
   - ❌ `open('data/file.json', 'r')`
   - ✅ `load_file_from_project('data/file.json')`

4. **确保 `project_utils.py` 被正确导入**
   - 在所有需要文件操作的脚本中导入：
   ```python
   from project_utils import get_project_path, load_file_from_project, save_file_to_project
   ```

5. **测试时验证当前工作目录**
   ```python
   from pathlib import Path
   print(f"当前工作目录: {Path.cwd()}")  # 应该是用户项目目录
   ```

## 修复效果

**修复前**：
```bash
cd ~/my-screenplay-project
python ~/.claude/skills/my-writer/scripts/init_project.py
# 文件创建在 ~/.claude/skills/my-writer/data/ ❌
```

**修复后**：
```bash
cd ~/my-screenplay-project
python ~/.claude/skills/my-writer/scripts/init_project.py
# 文件创建在 ~/my-screenplay-project/data/ ✅
```

## 相关文件

- `scripts/project_utils.py` - 已添加辅助函数
- `scripts/generate_plan.py` - ✅ 已修复
- `scripts/generate_scene_outline.py` - ❌ 待修复
- `scripts/status_manager.py` - ❌ 待修复
- `scripts/init_project.py` - ❌ 待修复
- `scripts/analyze_screenplay.py` - ❌ 待修复

## 备注

这个修复确保 my-writer skill 能够正确在用户项目目录中工作，而不是将文件保存到 skill 安装目录。这是 skill 可用的关键前提。
