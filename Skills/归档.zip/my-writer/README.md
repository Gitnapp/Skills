# 剧本创作项目

## 项目结构

- `/ref` - 参考剧本和辅助内容
- `/output` - 剧本输出目录
- `/data` - 临时文件和状态数据
- `/scripts` - 工具脚本

## 使用流程

1. 将原剧本放入 `ref/` 目录
2. 运行 `python scripts/analyze_screenplay.py`
3. 运行 `python scripts/generate_plan.py`
4. 运行 `python scripts/expand_act.py` 逐幕扩写
5. 运行 `python scripts/polish_screenplay.py` 润色

## 状态跟踪

检查当前进度：
```bash
python scripts/status_manager.py --status
```
