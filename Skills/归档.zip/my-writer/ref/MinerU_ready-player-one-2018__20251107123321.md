# READY PLAYER ONE

Current Revisions by

Zak Penn

Previous Drafts by Eric Eason and Ernest Cline Based on the novel READY PLAYER ONE by Ernest Cline

EXT. CENTRAL PARK - NIGHT - THE OASIS

We open on BETHESDA FOUNTAIN in the heart of New York's Central Park, then we pull up and away, hurtling backwards over the city until we come to rest in TIMES SQUARE, which has been blocked off for an EPIC STREET RACE.

EXT. TIMES SQUARE - NIGHT

Huge crowds line the street, cheering on TWENTY EXOTIC VEHICLES waiting at the starting line.

A MOTORBIKE straight from Road Warrior idles on the outside lane. Most of the other racers are in STOCK CARS, every driver wearing the same helmet.

These are SIXERS, we'll get back to them later.

Interspersed with the Sixers are vehicles of every variety. And when I say every variety I mean that some of them are cars, and some of them are hover craft, and one of them is a BLIMP with a jet engine on it.

Their drivers are every size, shape and color, too. They are called GUNTERS. That too will be on the quiz.

The closer we get to the West Side of 7th Avenue, the more Gunters there are. The second to last car is probably the most bad-ass of the lot, a replica of DECKARD'S SPINNER from BLADE RUNNER.

AECH, a handsome guy with the shoulders of a linebacker, checks the OVERSIZED ENGINE strapped to the roof.

PARZIVAL (O.S.)

Lemme guess - Mario Kart?

He turns to see PARZIVAL, standing beside his vintage DELOREAN, literally the car from BACK TO THE FUTURE. He's nineteen years old, good-looking and fit.

AECH

No. Designed it myself, actually.

Bad ass, right?

PARZIVAL

It's very Nintendo.

Their friendly rivalry requires busting on each other constantly.

# AECH

Better than your p.o.s. level 4 skin over a level 1 frame.

# PARZIVAL

Weird that I'm still gonna outrace you. What does that say?

# AECH

It says you're delusional, Z. I'm in the two spot. No way you get farther.

# PARZIVAL

Let's see who makes it past 57th.

A SIREN signals the drivers to get in their cars. Parzival makes a fist, Aech returns the salute.

# PARZIVAL (CONT'D)

First to the key.

# AECH

First to the egg.

And they get in their cars.

# EXT. SEVENTH AVENUE

A GUNSHOT starts the race and the cars roar onto Seventh Avenue. Almost immediately, an Eighteen Wheeler runs a red light and A THIRD OF THE CARS RAM RIGHT INTO IT.

And they literally explode. Just like that. Boom, half the cars are incinerated. Nobody bats an eye or stops cheering.

# IN THE DELOREAN

Parzival stomps on the accelerator, chasing Aech's dust. Cars bump and jockey for position, but Parzival is careful to avoid all of them, steering with tremendous precision.

# ON 44TH STREET

Metal walls suddenly pop up from the street, incongruously and with pretty much no logic to their placement. More of the Sixer vehicles CRASH or SPIN OUT.

Aech has already passed them, and Parzival simply veers through the debris.

# PARZIVAL

Dumbasses. You don't start from the outside lanes.

He catches up with Aech, and, as they HANG a LEFT on 45th street, he cuts past him on the inside.

Parzival's winning. For now.

EXT. CITY STREETS - CONTINUOUS

Parzival hangs a RIGHT on 8th Avenue and puts the pedal to the floor. On every block, a different obstacle emerges, and each time another driver is taken out. SINKHOLES open at 47th street, a MANIAC WITH A FLAMETHROWER sprays the intersection at 50th street, and at 54th street...

A T-REX stomps out into the street and Parzival nimbly swerves between its legs, just as its massive jaws POP THE BLIMP.

It's not your typical street race.

EXT. 57TH STREET - CONTINUOUS

Parzival turns right at 57th to get back over to Seventh Avenue, and now AECH suddenly BOMBS OUT OF NOWHERE and PASSES HIM.

He flips Parzival the bird as he makes a left back onto seventh. Parzival settles in behind him. Up ahead, a few blocks away, is CENTRAL PARK.

But before that is 58th street. The whole block is in an exaggerated state of construction, like an obstacle course, leading up to A COLLAPSING CRANE.

It's all a matter of timing and angle to get past the collapsing crane, and Aech tries to take it AS SHARP AND AS FAST as he can.

He clears the falling CRANE, but he's going too fast. He SKIDS OUT, and his car FLIPS OVER.

A MOMENT LATER, Parzival DRIFTS PAST HIM, going just a bit slower. His DeLorean SKIDS, but he makes the turn.

# PARZIVAL

Yes!

HALFA MILE AHEAD--

A CEMENT TRUCK is backing up, narrowing the space Parzival can drive through. He GUNS THE ENGINE, trying to get over fast enough to get past the TRUCK before it seals him off...

But he's too late. The DeLorean SLAMS into the truck, which EXPLODES WITH WET CEMENT.

AECH APPROACHES the smoking, cement-covered DeLorean, as Parzival climbs out through its dented gull-wing doors.

PARZIVAL (CONT'D)

Really thought I was gonna make it.

AECH

I'm telling you, it's rigged.

PARZIVAL

Dude, don't go there.

AECH

No other explanation.

Their conversation is interrupted by the ROAR OF AN ENGINE. They turn to see the ROAD WARRIOR MOTORBIKE ZOOM PAST THEM, seemingly headed straight for the truck, which now has the street completely blocked off.

AECH (CONT'D)

This should be ugly.

The MOTORBIKE suddenly veers off the street and INTO THE CONSTRUCTION ZONE. It plows over cones, then hits a stretch of BROKEN SIDEWALK, one piece angled UP, and RAMPS OFF IT...

JUMPING THE TRUCK!

Aech and Parzival exchange a glance, then chase after the motorbike.

EXT. CENTRAL PARK - DAY

THE ROAD WARRIOR BIKE speeds towards camera, fifty yards away from the park entrance. The driver is stoic, completely focused, absolutely determined to make it, and that's when...

A METEOR (yes, I'm serious, a meteor) plunges from the sky and slams into the street. The RIDER has to BAIL OUT as the BIKE slams into the smoking rock and EXPLODES.

EXT. CENTRAL PARK - CONTINUOUS

Parzival and Aech run up to the wreckage. The RIDER emerges from the smoke, whipping off her helmet, revealing...

# ARTEMIS

A meteor?! Seriously?

Aech and Parzival gape at a woman in her early twenties; raven hair, big hazel eyes, rounded cheekbones and a perpetual smirk.

She HURLS HER HELMET at the Meteor. It too explodes.

# AECH

You almost made the park, you realize how huge that is?

# ARTEMIS

Do I have the key? No. Not huge.

# PARZIVAL

(star struck)

Hey. You're Artemis!

# ARTEMIS

Yeah, I know.

She walks past them. Parzival, staring, has lost whatever sense of cool he seemed to possess.

# PARZIVAL

I love you. I mean... we love you.

# AECH

(interrupting)

What he means is, we're big fans. We've read your stuff, seen your channel...

# PARZIVAL

You should come with us!

# ARTEMIS

(to Aech)

He always like this?

# AECH

No.

(to Z, under his breath)

Dude, act like you've met a girl before.

# PARZIVAL

I just mean... to talk about Halliday, and the Egg. And the race.

# ARTEMIS

You guys are gunters? I mean, serious, not just jerking off on the weekend...?

# PARZIVAL

Not jerking off on weekends at all.

# AECH

My socially inept friend here was the first to 49th, first to 55th...

# ARTEMIS

Wait a minute... you're Parzival.

# PARZIVAL

Yeah, I know.

Artemis smiles, touche. She turns to Aech.

# ARTEMIS

So where is your place anyway?

# INT. AECH'S BASEMENT - OASIS

A suburban rec room, circa the early 1980's. Movie and comic book posters cover the wood-paneled walls. A vintage RCA television is hooked up to a Betamax, a LaserDisc player, and several vintage videogame consoles, most prominently an ATARI 2600.

# ARTEMIS

Wow.

Aech leads Artemis in, Parzival right behind.

# PARZIVAL

Show her the workshop.

Aech, ahead of him, kicks open the door to what should be a closet...

# ARTEMIS'S POV -- AN ENORMOUS WORKSHOP/GARAGE

Completely out of proportion to the room, Aech's garage is an enormous space filled with exotic vehicles, including replicas of the BATMOBILE, PEE WEE'S BICYCLE, and most impressively...

An unfinished replica of a familiar GIANT ROBOT.

# ARTEMIS

Is that...

# AECH

The Iron Giant? Yeah, just got the commission for it. No big deal.

Artemis checks out the surface of the enormous, stylized robot. The unfinished parts of it are still a 3D grid.

# PARZIVAL

Aech's work is top rated on the modboards.

# AECH

(shrugging)

It's mostly about getting the right skins, what you can license, you know? Like Matrix, Matrix kids, forget it, but Star Wars, Marvel, Dark Knight, the classic Ridley Scotts...

# ARTEMIS

Golden Age Spielberg?

# AECH

Pre-Jurassic is a bitch.

# ARTEMIS

Always wanted the Mothership from Close Encounters.

# AECH

Yeah, tough to find.

# PARZIVAL

Tough to park.

Artemis laughs. Parzival lights up.

# ARTEMIS

Never thought of that.

# AECH

Oh, yeah, handling is an issue. I mean you can't build a Giant Robot and have it ride like a Buick Regal.

# ARTEMIS

Buick...?

# PARZIVAL

A shitty car from Halliday's time.

# ARTEMIS

Right.

Aech pulls the door shut. Music comes up... TEMPTATION, by NEW ORDER, the original Factus 8 version, not the remix...

# INT. AECH'S BASEMENT

Artemis bops around the room checking the place out. She comes to THE HALLIDAY WALL, which is loaded with memorabilia. (And no, we don't know who he is yet, but we're getting there.)

# ARTEMIS

Whoa, great collection here.

Most prominently, the classic magazine cover from JANUARY 7, 2040, the day Halliday died. It's the photo of him in faded jeans and a vintage Space Invaders T-shirt, the headline RIP JAMES HALLIDAY, 1972-2040.

# AECH

So you're checking my private Gunter stash - where's the quid pro quo? (off her look) The jump.

Artemis debates whether or not to tell them.

# ARTEMIS

The sidewalk is cracked. Had to be a reason, there always is with Halliday.

# AECH

Exactly. That's what I've been saying.

# PARZIVAL

Please, not the "theory" again...

# ARTEMIS

"Theory"?

# AECH

The challenge is unwinnable. It's designed to drive us nuts.

# PARZIVAL

Halliday wouldn't do that.

# ARTEMIS

Maybe he just made a mistake? I mean, there was no one to bug test it.

# AECH

No way, he never made mistakes.

# PARZIVAL

Well... not totally true.

They both turn to look at him.

# PARZIVAL (CONT'D)

He once screwed up a level of

Flunkie Sprat Three.

# ARTEMIS

Wow, that is some seriously deep cut triv, Z. I gotta admit, you are as hardcore a Halliday nerd as anyone I've ever met.

Parzival blushes a bit. Aech notices this.

# AECH

We're gunters. "First to the

key...

# PARZIVAL

"... first to the egg."

She looks from Parzival to Aech, sizing them up.

# ARTEMIS

So how come you guys aren't in a

clan?

Parzival shakes his head.

# AECH

Thank you, I've told him a million

times we'd be better off working

together. But Z thinks the only way

someone wins is solo.

# ARTEMIS

Tell that to IOI and the Sixers.

# PARZIVAL

(quickly)

They won't win. Halliday won't let

them.

# ARTEMIS

He's dead, dude.

# PARZIVAL

The Oasis was his baby. He wouldn't

set it up for some corporate borg-

spawn.

# AECH

(aside, to Artemis)

He gets a little touchy about the

whole Halliday thing, thinks they

have some sort of bond.

# PARZIVAL

No, that's not... I just think I

understand the guy, maybe

because...

# ALICE (O.S.)

WADE!

Parzival is interrupted by a disembodied voice that echoes

out over the room, though only he seems to hear it.

# ARTEMIS

Because why?

# ALICE (O.S.)

Wade! Have you seen my gloves?

# PARZIVAL

Oh, crap.

Artemis looks at him quizzically.

# PARZIVAL (CONT'D)

Sorry, it was awesome meeting you.

Gotta split.

And with that, PARZIVAL SUDDENLY DISAPPEARS...

CUT TO:

INT. CARGO VAN - THE REAL WORLD

And now we see WADE WATTS, the "real" Parzival, in the real world.

He's inside an 80's vintage van with fogged over windows, wearing a HAPTIC VISOR, which he quickly pulls off.

"Parzival" is an idealized version of Wade, in reality he is shy and gangly, sporting worn corduroys and a baggy sweater. And a pair of IOI-branded HAPTIC GLOVES.

ALICE (O.S.)

They're not on my desk. Where they should be.

The conversation with his Aunt switches from the visor to a mobile headset the size of a dime on his earlobe.

Wade tucks the gloves into a backpack and scrambles out of the van, pushing past boxes of busted laptops, computer parts and old car batteries.

EXT. CARGO VAN - NIGHT

The VAN is buried under other junked vehicles, arranged perfectly so it's hidden from the outside world. Wade locks the door behind him, keeping the conversation going.

WADE

Why would I take your gloves?

ALICE (O.S.)

Because you spend every waking moment in the Oasis and you don't have your own.

EXT. JUNKPILE - NIGHT

Wade emerges from the mound of old cars into an empty playground. He checks to make sure no one saw him come out of his secret hideout, then keeps moving.

ALICE (O.S.)

Where are you, anyway?

WADE

I'm out with some friends.

ALICE (O.S.)

You don't have any friends.

EXT. PORTLAND AVENUE STACKS - NIGHT

Wade has now arrived at his destination: THE STACKS.

Dozens of MOBILE HOMES stacked on top of each other, connected by a makeshift network of recycled pipes, girders, and support beams. There are a dozen Stacks in all, the future's version of suburban tract housing.

# WADE

I actually just met someone I really like.

# ALICE (O.S.)

A real person?

# WADE

Funny.

The lower trailers -- and other empty wall spaces -- are punctuated with the occasional bit of political graffiti. Most of the references are to "IOI", an organization that seems particularly unpopular with people who like writing slogans on walls.

As he runs through the streets, he passes two kids wearing "REB" t-shirts; a picture of a leader called "JC3" in the same vein as Che Guevara. They take potshots at overhead IOI DELIVERY DRONES with air rifles.

They wing one of the drones which sputters and falls, almost hitting a stray dog.

Wade MUTES his headset for a moment as he hustles past them.

# WADE (CONT'D)

What the hell, guys?

# REB

IOI, brah. Gotta stop 'em.

# WADE

By shooting someone's tube socks out of the sky?

# REB

Stuff it in your suckchute, loser.

# WADE

(to himself)

Suckchute, that's new.

# ALICE (O.S.)

Still need my gloves, Wade.

Wade jumps up and grabs on to the skeletal metal structure that keeps the whole stack in place. He starts CLIMBING.

EXT. WADE'S STACK - NIGHT

We follow Wade as he scrambles up the outside of the stack. The climb grows increasingly perilous as he goes. Physically, Wade's no specimen, but this is one thing in the real world that he is actually good at.

# WADE

Just remembered where they are.

He finally reaches his unit. He peers through the BATHROOM WINDOW, then climbs through it.

INT . WADE'S HOME - BATHROOM - NIGHT

In the pitch dark bathroom, Wade cracks the door and can now see his AUNT ALICE, 30's and haggard in a meth-y kind of way, standing in the living room.

# WADE

They're in the kitchen. On top of the fridge.

Alice turns to look at the kitchen, AWAY from Wade. When she starts to walk in that direction, Wade makes his move.

INT . WADE'S HOME - LIVING ROOM - NIGHT

Wade dashes into the messy, cramped living room. He quickly stashes the gloves under the COUCH CUSHIONS, then walks as quietly as he can to the front door.

Alice, annoyed, paces back into the living room...

# ALICE (INTO HEADSET)

I can't be late again.

... just as Wade walks IN through the front door.

# WADE

They're right there, Alice.

He points to the gloves, sticking out from under the couch cushions.

# WADE (CONT'D)

See? I didn't have em.

Alice, slightly chastened, takes the gloves from him, then settles into a recliner.

RICK (O.S.)

That is bull pucky, amigo.

A FLUSH from the bathroom as RICK, Alice's white trash boyfriend, walks into the living room.

Wade grimaces, realizing...

WADE

You were in there when...

RICK

Fell asleep, it was a long one.

(to Alice)

This lying bastard had the gloves.

Rick continues past them and into the kitchen. Alice glares at Wade.

ALICE

Damnit Wade, bad enough you don't

have a job without screwing up

mine. Now you can't use 'em at all.

WADE

What? But I...

Alice waves him away, slipping on her IOI gear. She speaks into her official IOI headset and waves her hands awkwardly.

ALICE (INTO HEADSET)

(monotone)

This way, please...

Wade glares at Rick, now tugging on a beer. Rick shrugs.

# INT. WADE'S BEDROOM - NIGHT

Wade enters the tiny slice of the unit he calls his room. Outside his window, like a cruel taunt, is a giant billboard advertising a SHAPTIC® BRAND HAPTIC BOOTSUIT, a totally badass immersion rig for logging in to the Oasis.

The BILLBOARD advertisement reads "Log In!" and features a muscular guy modeling a suit that promises "Total Interface" and "Real-time Neuromuscular Response!"

Hold on Wade, staring up at that ad.

INT. WADE'S HOUSE - THE NEXT DAY (REAL WORLD)

Wade wakes up, wipes the sleep from his eyes. It might be from spending too much time in the Oasis, but there's a moment of hopefulness, like maybe he's someplace awesome...

But nope, same crappy apartment, same billboard taunting him.

INT. WADE'S HOUSE - MORNING

Wade pours himself a bowl of cereal and milk water (milk-flavored water). From the kitchen table, through an open door, Wade can see into his aunt's bedroom.

Alice is passed out from a long night of work, Rick lies asleep on top of her, drooling. Wade cringes.

CLOSE ON -- the HAPTIC GLOVES and VISOR sitting on Alice's desk. They're YANKED out of frame --

INT. CARGO VAN - DAY (REAL WORLD)

Back in his hideout, Wade slips his VISOR on, then logs in.

He sees the last three words anyone sees before leaving the real world for the Oasis:

READY PLAYER ONE

EXT. CITY STREET -- THE OASIS

INCPIIO, the MAIN PLANET of the Oasis, is a giant city filled with every building or structure, real or fictional, you can possibly imagine.

WADE (V.O.)

When Halliday first built the Oasis, it was an open-world, massively-multiplayer online game. Over time it grew into way more than that.

Parzival suddenly appears, mid stride. He passes the Eiffel Tower next to the Taj Mahal, with EXXON/WHOLEFOODS corporate headquarters jammed between them.

WADE (V.O.)

One of his biggest ideas was tying your avatar into your DNA, using their proprietary software. One account per person, no exceptions. (MORE)

WADE (V.O.) (CONT'D)

Everyone started equal in the

Oasis. And it was free.

Parzival opens his HUD, his "heads up display" which appears as a seamless interface with the world around him. He has gamer attributes -- SPEED, STRENGTH, MAGIC, AIM -- and an INVENTORY for weapons, spells, and vehicles.

WADE (V.O.)

Your avatar was fully upgradeable,

but that took experience. And

money.

The DELOREAN is in there, currently marked "damaged". The price to fix it is 5,000 gold coins. His account has a balance of 4,560.

PARZIVAL

(using a voice command)

Locate Aech.

An image of AECH comes up; like the graphics over any sports broadcast, his avatar moves and poses and winks.

"LOCATING..." appears.

Wade continues on his way, passing through what looks like the heart of the city. Off to his right is the main GREGARIOUS GAMES headquarters, a gleaming, castle-like tower.

WADE (V.O.)

Once the Oasis took off, Halliday's

partner Ogden Morrow got pushed

out. Since Halliday died, no one

I knew exactly who ran the Oasis.

anymore. But a good guess?

Just down the block from Gregarious is IOI HEADQUARTERS, a massive, corporate monstrosity.

WADE (V.O.)

IOI, Innovative Online Industries.

They build the haptic gear. The

gloves, the visors...

INT. WADE'S Hideout - THE REAL WORLD

Wade lies in his haptic rig, a series of quick cuts of THE IOI LOGO, on Wade's gloves, visor, the boots... IOI has their name on everything.

EXT. INCIPIO (OASIS)

Back in Incipio...

WADE (V.O.)

Which means they control most

people's access to the Oasis.

Parzival checks his HUD, Aech is still being "located".

WADE (V.O.)

Halliday kept IOI in line. But now?

Well if you asked the rebels, IOI's

plan was to turn the Oasis into a

hellish place where rules were

numerous and always followed.

AECH (O.S.)

s'up, Z?

AECH now appears in a window in a close-up, clearly real time footage. Wherever he is it's loud and dusty, and bursts of smoke and gunfire make it difficult to see and hear.

PARZIVAL

What the hell are you doing?

AECH

I'm trying to win the musket of

infinite velocity.

WADE (V.O.)

But people loved the Oasis 'cause

it was free. At least in spirit,

you could do anything.

The camera suddenly TAKES OFF, shooting away from Parzival...

EXT. OUTER SPACE --

And into OUTER SPACE.

WADE (V.O.)

Halliday built an entire universe,

something for everyone...

We SHOOT ACROSS THE GALAXY, passing countless planets...

One of them seems to be a huge SPACECRAFT, IMPOSSIBLY LARGE. But as we pass it we see that it is the LETTER "S", floating in space. The rest of the word is so big we can't make it out from this perspective.

# WADE (V.O.)

Which is how you end up with a place like Planet Doom.

We approach a planet that seems to have beautiful and elaborate weather systems swirling around it. As we get closer, we realize that the "weather" is actually EXPLOSIONS, from a never-ending war.

# WADE (V.O.)

The first gamers in the Oasis walked around blowing each other away right in front of everyone else. Halliday realized he needed to draw some boundaries. He divided the Oasis into combat zones, or PVP, and non-combat zones.

As we descend from the atmosphere, we pass over "The Dark Side" of Planet Doom, which is sealed off from the war zones by a giant wall known as Anorak's Fence.

# WADE (V.O.)

He migrated all the most violent first person shooters to one planet. One giant PVP zone.

# EXT. APPOMATTOX (OASIS)

We swoop in from the atmosphere to reveal a perfectly rendered vision of the battle of Appomattox, with some small changes.

# PARZIVAL (O.S.)

Who you up against?

Mixed in with the soldiers are a bunch of avatars that are way out of context.

# AECH

The South. But also Aliens. And the Roman Legion, I think.

Aech is on the Union side, a musket with one hand, and a futuristic BLASTER in the other.

# PARZIVAL

Think I might've figured something out. Wanna swing by the journals and take another run at the key?

# AECH

Wish I could.

As he moves across the field, Aech shoots an Alien with his musket, then a Confederate soldier with his blaster. As they explode, their COINS shower to the ground. A VACUUM TUBE on Aech's shoulder sucks them right into his inventory.

# AECH (CONT'D)

This sesh has got another five

hours, minimum. DAMNIT!

Aech just got winged in the ribs by an enchanted ARROW.

# WADE (V.O.)

Aech was my best friend in the

Oasis, probably my best friend

period, even though I'd never met

him.

Aech launches himself into the fray, racking up kills.

# WADE (V.O.)

He also had a lot of stuff,

including a dope spaceship. So I

was always hitting him up for

rides.

EXT. INCIPIO STREETS - THE OASIS

Aech's window disappears, so Parzival toggles his HUD to navigation.

# PARZIVAL

(voice command)

Memoir-opolis.

A pathway suddenly lights up in front of him, showing him the path to take.

# WADE (V.O.)

The Oasis was like the real world

in that respect; the more money you

had, the more stuff you got, and

the more stuff, the easier it was

to get around, and thus get even

more stuff.

Wade heads towards a train station. The train tracks head UP AND OFF THE PLANET.

# WADE (V.O.)

I think that's why Halliday's

challenge was such a big deal. It

wasn't just the money.

(MORE)

WADE (V.O.) (CONT'D)

For someone like me, it was the chance to go from peasant to king in a heartbeat.

Wade takes a seat on a bench at the train station, waiting for his ride.

WADE (V.O.)

Like everyone else, I remember exactly where I was the day the contest was announced... the day James Halliday died.

FLASHBACK TO --

INT. LUDUS -- OASIS

A giant, virtual classroom. PARZIVAL is one of a thousand avatars sitting and listening to a virtual ALBERT EINSTEIN teach them rudimentary science.

Suddenly, everyone in the room gets an alert...

JAMES HALLIDAY, DEAD AT 62.

INT. APARTMENT - DAY -- THE REAL WORLD

WADE, 13 years old, rips his early-iteration headset off. His eyes fill with tears.

He is in his cozy childhood home. There are boxes everywhere, the family has just moved in. In the background, his FATHER paints the living room wall while his MOTHER cooks dinner.

When she sees her boy crying, she runs over to comfort him. Despite the tragedy, clearly these were happier times for Wade.

EXT. FUNERAL PARLOR (OASIS)

At a funeral parlor, people dressed in black mourn before an open casket...

The body inside is JAMES HALLIDAY, shiny quarters cover each of his eyelids.

WADE (V.O.)

But it wasn't his death that changed everything. It was his will.

IN THE CASKET -- Halliday's avatar suddenly SITS UPRIGHT and begins talking to camera.

# HALLIDAY

Hello. I'm James Halliday. If you're watching this, I'm dead.

He snaps his fingers and a SCROLL appears in his hand. He unfurls it to the floor and begins reading aloud...

# HALLIDAY (CONT'D)

I, James Donovan Halliday, do hereby declare this to be my last will and testament...

A CAPTION at the bottom of the screen reads:

"Halliday's Announcement" (archival footage property of GGS)

INT. ANORAK'S CASTLE (OASIS)

Now Halliday appears inside a castle as ANORAK, his avatar, a tall, robed wizard with a slightly more handsome version of Halliday's face.

# ANORAK

Before I died, I created my own Easter egg, and hid it somewhere inside the OASIS. The first person to find the egg will inherit my entire fortune and earn complete control of the Oasis.

A simple RHYME appears as a subtitle in front of Halliday as he speaks.

# HALLIDAY

Three hidden keys open three secret gates/ Wherein the errant will be tested for worthy traits/ And those with the skill to survive these straits/ Will reach the end where the prize awaits. Now here is the clue for the first key...

EXT. TRAIN (OASIS)

Parzival boards a high-speed train. His HUD IMAGE OF CREDITS appears and is lightened by 10 coins. Everything in the Oasis costs something.

He takes a seat next to two ridiculously proportioned WOMEN who chat loudly. Parzival MUTES them.

# WADE (V.O.)

The corporate overlords at IOI weren't as excited about the contest.

EXT. COLUMBUS, THE REAL WORLD --

Push in on three sleek skyscrapers in gleaming downtown Columbus, Ohio in the shape of the letters IOI.

# WADE (V.O.)

The thought of new ownership terrified them.

# INT. IOI HEADQUARTERS

Inside the building, a sea of workers in rows of Haptic Decks. A buzzing hive of activity; like a trading firm, all working to solve Anorak's challenge.

# WADE (V.O.)

They started their own division of egg hunters.

We see all of the IOI EMPLOYEES AVATARS have the same default outfits and instead of names, NUMBERS. All of them start with a "six".

# WADE (V.O.)

We call em "Sixers" 'cause that's the rule, no name, just numbers. They put this Kardashian named Nolan Sorrento in charge.

AN INTERVIEW -- with a slick, ambitious guy in his forties who is clearly trying to burnish his image.

A chyron reads NOLAN SORRENTO, EXECUTIVE VP, IOI.

# WADE (V.O.)

Sorrento was the lead sixer. The face of IOI's team.

The program CUTS TO Sorrento giving a tour of his lavish home, trying to show a more human side.

# SORRENTO

I love games. I love being inside the Oasis.

Despite the fact that his whole house is luxurious, his rig is particularly ostentatious: a rotating full body 3D Immersive Haptic Interface, like a hamster ball.

# SORRENTO (CONT'D)

The one luxury I spoil myself with is the best haptic immersion rig money can buy.

We see B-Roll of his enormous house, his attractive FAMILY. His admittedly cute dog.

# WADE (V.O.)

Despite the charm offensive,  
Sorrento was a scary dude. He made his bones in IOI's security and adjustment division.

# EXT. COLUMBUS SUBURBS -- FLASHBACK

A younger Nolan Sorrento leads a team of jack-booted IOI thugs as they break down someone's door. A TEN YEAR OLD GIRL with a DISTINCTIVE BIRTHMARK watches as Sorrento reads off a list of debts to her FATHER, then has him dragged out of the house.

The girl runs after her father, Sorrento sticks out his foot and TRIPS HER.

# WADE (V.O.)

Now he was in charge of IOI's egg hunt, but you could tell his heart wasn't in it.

# INT. SORRENTO'S HOME

Sorrento's interview continues...

# SORRENTO

At IOI, we love hunting for the egg, it's part of what makes the Oasis so fun.

It's the least convincing expression of enthusiasm ever.

# EXT. INCIPIO (OASIS)

The TRAIN rockets up and out of the city, impossibly fast.

# WADE (V.O.)

The first clue was easy, some long-forgotten gunter cracked it in a week. But the challenge -- the race through Times Square -- was incredibly hard.

The train arrives at his stop, one of the many moons of Incipio. A sign at the station reads: MEMOIR-OPOLIS.

# WADE

Five years went by and no one came close to beating it. Most people gave up. The sixers couldn't, they had no choice. The rest of us, the Gunters, as in "egg hunters"... well, we didn't have an excuse. We just had a dream.

# EXT. OASIS -- MEMOIR-OPOLIS

Parzival strolls down a street lined with what look like homes, but are actually a row of "memory palaces", basically auto-biographies represented in tangible form.

# WADE (V.O.)

At this point, you're probably wondering why a nobody, me, is telling you his life story.

The "titles" of these "books" float in front of the memory palaces in various fonts. As this is prime real estate, they are mostly people anyone from 2044 would know.

MOGUL -- THE MADDOX JOLIE PITT STORY

THE UNABRIDGED LETTERS OF SKRILLEX

JaRICHARD CHENEY IV, MY LIFE AS A REBEL -- yes, Dick Cheney's grandson is the dreadlocked, blunt-smoking leader of the Rebs, known as JRC. That was him on the kid's t-shirt earlier.

# WADE (V.O.)

Point is this; I tell my story cause that's what Halliday did. He knew our lives would be memorialized in the Oasis, and people like me would want to know.

Parzival passes "OGDEN MORROW, MY LIFE SO FAR".

Finally he comes to the building he's looking for; HALLIDAY'S JOURNALS.

# WADE (V.O.)

And if that seems grandiose on my part, if this seems like some random day in the life of some random nobody, it's not. This is the day I stopped being a nobody.

# INT. HALLIDAY'S JOURNALS - OASIS

Parzival enters a large lobby with many doors, each of them heading into a different part of Halliday's life.

THE HISTORIAN, a doddering NPC with an attitude, suddenly appears before him. (An NPC is a bot, an AI).

# HISTORIAN

Parzival. How shocking to see you here.

# PARZIVAL

What's up, not-real but sarcastic program?

# HISTORIAN

So, Halliday's childhood again? Comb through his VHS library? Chew up my valuable search time?

# PARZIVAL

Nah, today I need to check out something pretty obscure. Halliday's one mistake.

The Historian raises an eyebrow, intrigued.

# HISTORIAN

His mistake. Flunkie Sprat Three?

# PARZIVAL

(nods)

Yeah. This girl said something to me, I've been thinking about it all day.

# HISTORIAN

I'm feigning interest.

# PARZIVAL

(ignoring that)

I mean, maybe it's cause she's hot.

(MORE)

PARZIVAL (CONT'D)

If she had said "I love pork rinds," would I be thinking about pork rinds? Possibly...

HISTORIAN

Please, go on, I'm fascinated.

He isn't.

PARZIVAL

Damn, now I am thinking about pork rinds.

HISTORIAN

Is that the end? Great story, Parzival.

PARZIVAL

My point is, what if he made a mistake?

INT. HALLIDAY'S JOURNALS - HALLWAY

The Historian leads Parzival to a door. Parzival opens it and steps inside.

PARZIVAL

With the contest, I mean. What if he made a mistake on purpose?

INT. GREGARIOUS GAMES -- 1993 (THE REAL WORLD)

But for the presence of Parzival and the Historian, the recreation is absolutely flawless. We ARE in 1993, in the offices of Gregarious Games, where a much younger James Halliday, hung over, can't stop talking about his night.

HALLIDAY

She's incredible, Ogden. I mean... I never met anyone like her. I drank too much, like an idiot, I'm a total lightweight.

A frustrated OGDEN MORROW, rotund, with an unruly beard and wire-rimmed spectacles, is Halliday's partner. He inspects the code Halliday has written for PD3.

MORROW

(re: the code)

What did you do here?

# HALLIDAY

She told me to call her. Do I do that tomorrow? When? I'm terrible at this stuff.

# MORROW

Data is leaking all over the place.

# HALLIDAY

I really do wonder why people bother with relationships, it's incredibly messy and confusing.

# MORROW

Yeah, partnerships are that way too.

Morrow pushes back from the desk.

# MORROW (CONT'D)

You blew it this time, Hal.

# HALLIDAY

I got the level finished.

# MORROW

Oh, it's finished. With one minor bug. You did it backwards. Flunkie starts at the end and sprats his way backwards to the beginning.

# HALLIDAY

Can't we just reverse the...

# PARZIVAL (O.S.)

STOP!

The scene suddenly freezes. Parzival turns to the Historian.

# PARZIVAL (CONT'D)

Play again from minor bug.

# MORROW

... minor bug. You did it backwards.

Hold on Parzival, wide eyed.

INT. CARGO VAN - THE REAL WORLD

Wade suddenly yanks the haptic visor off, breathing heavily. He's got it.

EXT. ANORAK'S RACE - OASIS

A new crowd of RACERS wait at the starting line with their cars.

Aside from the usual, indistinguishable sixers, we see SHOTO and DAITO. Both are Japanese, in their twenties, bearing a striking resemblance to one another. They each wear matching suits of traditional samurai armor, a short wakizashi and longer katana strapped to their belts. They also drive matching Speed Racer cars.

Parzival walks towards his DeLorean, in the center lane.

SHOTO

Hey Parzival, what's up?

They speak in Japanese, which we hear faintly, because it is instantly translated to English.

PARZIVAL

Shoto, Daito.

SHOTO

Dude, you're in the newb lane.

PARZIVAL

Just testing out a new engine Aech threw in.

Daito nods. Shoto seems unconvinced. Parzival gives the gunter salute.

PARZIVAL (CONT'D)

First to the key.

SHOTO

DAI TO

First to the egg.

First to the egg.

AT THE STARTING LINE --

The race begins with a gunshot and instantly Shoto, Daito and the Sixers speed off.

Parzival's DeLorean doesn't move.

As the rest of the racers disappear around a curve, Parzival puts his car in REVERSE and drives backward, and then...

EXT. SEWER SYSTEM - OASIS

The ground gives way and the DeLorean lands with a thump in the sewer system. Parzival stomps on the accelerator and the car AUTOMATICALLY GOES BACKWARDS.

Parzival laughs as he shoots through a winding tunnel.

Then the sewer ramps UP and the DeLorean shoots out back into the race.

EXT. RACE TRACK - OASIS

As he emerges, and because he is driving backwards, Parzival can instantly see that he is way ahead of the pack and EVERY OBSTACLE in the game is FALLING BEHIND HIM.

He can see the T-REX licking its claws and waiting on 54th street, the CRANE not yet toppled, the CEMENT TRUCK not yet moving. He can even see the TRAIL OF THE METEOR on a trajectory towards the park.

It doesn't matter, it's all behind him. He sees Shoto and Daito crash, then glances in his rearview. He's just entered Central Park.

EXT. CENTRAL PARK - OASIS

The DeLorean SPINS OUT and ends up facing forward RIGHT AT BETHESDA FOUNTAIN.

Parzival gets out. As he walks towards the fountain, he calls AECH up in a video-chat window.

AECH

What's up Z?

PARZIVAL

Aech, my good friend.

AECH

Where are you?

PARZIVAL

Great question. Do you recognize this?

PARZIVAL flips AECH to HIS POV...

AECH

WAIT. Bethesda Fountain? No. Oh my god. Dude! You made it!

As Parzival walks around the fountain, interference causes his HUD to disappear, hanging up on Aech. Probably because he's so close to...

# THE COPPER KEY

Parzival snatches it out of the air. He stares at the key for a long moment, then can't resist: HE HOLDS IT UP LIKE EXCALIBUR.

# PARZIVAL

I... am... PARZIVAL!

His bellow echoes out over the park. He feels a bit stupid for a second. Then a DOOR APPEARS.

Parzival sticks the key in, and the door opens. As he does, we WHIP AROUND THE OASIS in what some might call...

A MONTAGE!

# EXT. OASIS

Aech is standing on a distant planet, impatiently waiting for a TRANSPORT SPOT to open up.

A BRILLIANT LIGHT IN THE SKY draws his attention.

It's the scoreboard! There's a name at the top now... Parzival. If Aech had programmed his avatar to cry, it would.

# INT. PLANET DOOM

Artemis is in a private chat room -- unlike Aech's, it is austere and functional -- with her GUNTER LAN. Conversation is hushed, secretive. Then a KNOCK at the door startles them, everyone pulls their weapons (various guns and blasters and knives).

Artemis checks the peephole. It's one of her clan members, excitedly knocking on the door.

# GUNTER

Arty! Ya gotta come check this out!

# EXT. PLANET DOOM

Artemis steps outside and appears next to her clan mate. Planet Doom is experiencing a rare, momentary peace.

Artemis looks up, to see why. It's the Scoreboard.

# ARTEMIS

Ho... lee...

She smiles, ear to ear. As we zoom to our next location...

CUT TO:

# INT. IOI HEADQUARTERS - BOARD ROOM

A massive VIRTUAL BOARD MEETING is taking place, NOLAN SORRENTO's avatar is making a presentation about "The Loyalty Initiative", a program that involves the construction of multiple LOYALTY CENTERS around the world.

On an interactive MAP, we see there's one in Columbus, one in Oklahoma City, and many more planned. Then...

Something catches Sorrento's eye. Out the window. His voice drifts off...

# EXT. IOI CORPORATE SKY DECK - NIGHT

SORRENTO walks out onto an outdoor executive deck. He can see that THOUSANDS OF SIXERS have filed out into the courtyard below, all gazing and pointing at the sky like extras in a Spielberg film. He looks up to see....

FULL REVEAL -- THE SCOREBOARD, shining brightly in the night sky above.

There are ten spaces that for five years have been empty. But now...

1ST PLACE: PARZIVAL -- 100,000 POINTS

Just to hear it said, Sorrento repeats the single name that has suddenly jeopardized everything he believes in.

# SORRENTO

Parzival.

CUT TO:

# EXT.INCIPIO-DAY

Parzival suddenly appears on a street on Incipio, the key hanging around his neck.

It takes him a moment to notice, then he realizes that everyone is staring up in the sky, pointing. He looks up to see his name up there, as big as the sun.

Parzival is absorbing the magnitude of this when his HUD suddenly comes up and his COIN COUNTER shoots from 827 to 100,000. Instantly.

# PARZIVAL

Sweet Mama Cass!

Then his message queue pops up. He has over fifty thousand messages waiting for him, the number jumps by another thousand every second.

# PARZIVAL (CONT'D)

Hello, World.

Then he hears voices...

# VOICES

Parzival! Look, Parzival! It's him!

He's been spotted.

Parzival laughs as he is surrounded by AVATARS, all looking for a word or a chance to look at the key, or even just a moment next to the most famous man in the Oasis.

FADE OUT:

INT. WADE'S HOME - SOMETIME LATER (REAL WORLD)

In stark contrast to the Oasis, in real life Wade sits in his Aunt's apartment in the Stacks, drumming his fingers.

Waiting.

HIS POV -- Aunt Alice, wearing their only haptic deck, is "working", pointing left and right.

CUT TO:

EXT. STACKS - DAY (REAL WORLD)

Wade, burning off nervous energy, walks around the Stacks checking the time and occasionally glancing at the sky.

INT. WADE'S APARTMENT -- LATER (REAL WORLD)

RICK is now wearing the haptic deck, playing some sort of lame first person shooter. He contorts his body and complains as he keeps getting shot.

# RICK

That's bullshit! You didn't hit me.

You're cheating! This game is

friggin' rigged.

WADE watches mutely from the kitchen. No way he can get back online. It's like a nightmare.

EXT. WADE'S STACK (REAL WORLD)

Wade is now standing outside the stacks, checking the time and watching the skies. The REB KIDS are spray-painting the side of a stack.

# REB

Hey look, it's the loser!

# REB 2

Eat a dickbagel, loser!

Wade looks over at the kids and double takes.

Their t-shirts? A PICTURE OF PARZIVAL holding up the JADE KEY! Someone's screengrab that they printed up and sold. It causes Wade to burst out laughing.

# WADE

Nice shirts.

# REB 2

They are nice, butt-chee.

# REB

What's so funny?

# WADE

You, mostly.

Wade notices a DRONE dropping from the sky, heading towards them. One of the reb kids grabs his air rifle...

Wade snatches it out of his hands.

# WADE (CONT'D)

Don't even think about it.

The kids are taken aback by Wade's sudden confidence.

The drone lands beside Wade and a signature screen pops up.

Wade signs it and the package releases.

# REB

Those aren't socks.

# WADE

You're a pair of socks. Get out of here.

Wade tosses them the air gun. The kids run away. Amazing what a little confidence will do.

INT. WADE'S Hideout (REAL WORLD)

Like a kid on Christmas Day, Wade tears open the package...

It's the SHAPTIC@ BRAND HAPTIC BOOTSUIT, the same one he's been looking at every day out his window.

# WADE

Oh yes, my sweet, sweet love.

He hugs the suit to his chest, the happiest kid in the world.

EXT. WHITE SANDS - OASIS

Nolan Torrento's avatar stands in the middle of an enormous, white sand desert. He waits impatiently, when suddenly...

A SPACESHIP DROPS DOWN in front of him, kicking up a cloud of sand. It looks similar to SLAVE 1, Boba Fett's ship from Star Wars, but not so similar that a lawsuit could be filed.

A MASSIVE WARRIER emerges from the ship, A SPACE KNIGHT, all in black, weapons bristling across his body. Imagine the Hound from Game of Thrones crossed with a goth Master Chief from Halo.

# SORRENTO

Six, old friend, how are you?

This is NUMBER SIX, an Oasis Bounty Hunter, and he is scary as shit, except for his voice. It's incongruously nasal and unintimidating.

# NUMBER SIX

I'm okay, I've got a neck thing, some sort of carpal tunnel deal but in your neck? So if you could stay on this side of me...

He motions for Sorrento to step to his left.

# SORRENTO

Yeah, sure.

# NUMBER SIX

Thanks, just the repetitive stress, you know...

# SORRENTO

I get it. I have a job for you, Six.

# NUMBER SIX

Yeah, kinda figured that when you sent me the message about having a job for me. Who's the target?

Sorrento flings a "DATA PACKET" at Six. It instantly unfolds into a HUD filled with info.

# NUMBER SIX (CONT'D)

Duh. Should've seen that coming.

IN THE HUD -- All known information about PARZIVAL. Not just the obvious stuff, like his status as leader of the challenge, this has his entire Oasis history, all his achievements, every XP hunt, power-up purchase, porn planet visit... it's all there. Everything except his real world identity.

# NUMBER SIX (CONT'D)

Not gonna be easy. Guy's got a lot of eyes on him.

# SORRENTO

That's why I came to you. You're the best.

# NUMBER SIX

Riight.

Six pushes the data aside.

# NUMBER SIX (CONT'D)

Before I bust my ass, how many other haxorz have you put on this?

# SORRENTO

Six, why would I hire anyone else? You're my guy.

# NUMBER SIX

Yeah, okay, well I'm gonna need a higher daily budget than usual. And I'm gonna need help, as in manpower.

# SORRENTO

The Sixer Army is at your disposal.

# NUMBER SIX

I said "help" not a bunch of deadbeat level-one shart-squarters to trip over.

# SORRENTO

If you think it's too difficult...

# NUMBER SIX

Yeah, yeah. You can skip the mind games, Nolan. You know I'm in.

The giant warrior turns and heads back to his ship...

# SIX

Oww.

He moans and grabs his neck as he boards.

EXT. DEEP SPACE -- NIGHT

Aech's Spaceship rockets through the Oasis, away from the galaxy's center towards the less populated rim.

# AECH (O.S.)

I like your facial expressions. Much more detailed.

INT. AECH'S SPACESHIP

Aech and Parzival are hanging in the cockpit of Aech's sweet ride, talking about Wade's new Shaptic Brand Bootsuit.

# PARZIVAL

Think so?

# AECH

Yeah, but was it worth it? Those rigs are pricey.

# PARZIVAL

I can feel the Corinthian leather under my ass, that's how sensitive this thing is.

# AECH

Worth it! Changed my mind.

Aech gives Parzival a triple-slap high-five, which in the 2040's is the cool way to do it.

EXT. VENDOR'S MOON --

Aech's spaceship descends towards a MOON that looks like it is made entirely from WOOD.

INT . VENDOR'S WORKSHOP - DAY

In the center of an enormous space that makes the warehouse at the end of Raiders look like a closet, a man known only as the VENDOR (played by DAVID CROSS because literally, this is a David Cross branded avatar, with maximum sarcasm enabled) constructs a personalized PLANET, MADONNA'S 100th BIRTHDAY WORLD.

He uses his right hand to shape and mold, his left to add texture and color. Bits of color and pixels of matter fall to the ground like glitter.

He finishes off an ERUPTING VOLCANO and places it in the center of an ocean. Without turning around...

VENDOR Where's my robot, Aech?

Reveal Aech and Parzival approaching from a distance.

AECH Hey man, someone I want you...

VENDOR  
Where is my Giant Robot, Aech?  
From the movie Iron Giant, a heartwarming tale about a friendship between a human boy and a Giant Robot?

AECP I'm working...

VENDOR Where is it? Why don't I have it? Did we not say I would have it this week?

AECH (quickly) This is Parzival!

# VENDOR

You... if... what?

(to Parzival)

The Parzival?

# PARZIVAL

That's me.

# VENDOR

So what are we after, a used planet? Real estate in an undeveloped solar system?

The Vendor grabs a sheaf of paper from off a table and UNFURLS it. It stretches out into an enormous, stunning, ONE HUNDRED FOOT LONG MAP of every planet in the Oasis.

# PARZIVAL

No thanks.

# VENDOR

How about your own signage floating in the rings of Googleworld? I have a signsmith with fonts that will literally make you cry.

# PARZIVAL

I just need a ship. Something fast.

The Vendor smiles, snaps the map closed.

# VENDOR

Spaceships are my jam.

# INT. WORKSHOP

The contents of a SHOEBOX are dumped on a worktable, matchbox size versions of the Starship Enterprise, the Battlestar Galactica, and other iconic spacecraft.

# VENDOR

I just got a wonderful Guild spice ship that folds space like a boss.

Parzival shakes his head.

# VENDOR (CONT'D)

How about this George Melies-inspired stop-motion-esque rocket? Very classy.

# PARZIVAL

Kind of had my heart set on this one.

He picks up "Serenity", the spaceship from the show "Firefly". The Vendor frowns.

# VENDOR

Oh, joy, another Whedonite.  
Personally, I never saw the appeal,  
insular and twee and smug. Still,  
can't deny it's a well built  
vessel.

# INT. VENDOR'S WORKSHOP - LATER

The "Vonnegut", as Parzival has renamed it, is now complete. He circles it, inspecting it from every angle.

# PARZIVAL

It's amazing.

# VENDOR

So you really did it. You got the first key.

# PARZIVAL

Course.

# VENDOR

Can I see it?

Parzival turns to look at the Vendor. He seems desperate.

# VENDOR (CONT'D)

I'm not gonna go Gollum on you, kid.

# PARZIVAL

Okay, sure.

Parzival takes the key from around his neck and hands it to him. The Vendor's eyes light up as he turns the key over in his hands.

# VENDOR

The Copper Key. See how perfect that is, down to the pixel? Highest density resolution, just amazing work.

In fact, the key is magnificent, like it somehow has more weight, and catches more light, than anything else around it.

VENDOR (CONT'D)

I wondered if anyone would find it. He would have been happy to see someone like you holding this, instead of those IOI beefjugglers.

PARZIVAL

Wait, did you know Halliday?

VENDOR

In some ways, yes.

The Vendor looks over his shoulder, to make sure Aech isn't listening.

VENDOR (CONT'D)

I want to give you something. You have to promise not to tell Aech, he would be furiously jealous.

PARZIVAL

Yeah, sure.

The Vendor rummages in his pockets. Parzival's excitement grows, he can only imagine what it could be, this is a guy who can make anything.

VENDOR

Here you go.

The Vendor drops a single quarter in Parzival's hand.

VENDOR (CONT'D)

Remember, don't tell anyone.

As the Vendor walks away, Parzival looks down at the measly quarter and laughs. He flips it, then adds it to his INVENTORY.

INT. VONNEGUT - DAY (OASIS)

Wade straps into the driver's seat of the Vonnegut. The ship rockets through the open bay door of the planetoid and accelerates into space.

INT. WADE'S Hideout (REAL WORLD)

Wade, in his full body bootsuit, is taking the thrill ride of his life. He steers with a virtual wheel, accelerates with a virtual thrust, flips switches on a virtual switchboard.

INT. THE VONNEGUT (OASIS)

All of which is rendered in loving detail inside the Vonnegut. Parzival deftly navigates two oncoming ships, a massive GROUPON DEAL-HAULER and some tween girl's HELLO KITTY shuttle, then loops through the BROKEN RINGS of the FACEBOOK PLANET, which has been dormant for years.

# PARZIVAL

"The place where lovers couldn't leap/ In the dark, while counting sheep/ Take the jump, prove how you're made/ Then you will find the key of Jade." That mean anything to you, Kitt?

The voice of his onboard computer, KITT, responds.

KITT (O.S.)

No, sir.

Parzival puts the ship on autopilot, then calls up a map in his HUD.

# PARZIVAL

Clearly some sort of jump. So many options. Set a course for Lover's Leap, in the Valentine's Day sector on Hallmark 4.

KITT (O.S.)

Very good, sir.

As the ship hurtles through space, his HUD operates like a FIND FRIENDS app, showing that ARTEMIS is nearby, on PLANET DOOM.

# PARZIVAL

Locate.

His Hud spins for a moment, but Artemis isn't available. He leaves a message.

# PARZIVAL (CONT'D)

Hey, it's me. Z. Ha ha, that rhymed.

He abruptly stops and DELETES the message. He tries again.

# PARZIVAL (CONT'D)

Howdy... (disgusted with himself) What the hell, am I a cowboy now? Act like a human being, Wade.

Now he gets his shit together.

# PARZIVAL (CONT'D)

Artemis, it's Z. I'm in your neck of the woods, thought maybe I'd drop by. Anyway, I wanna thank you for helping me figure out the first challenge. So here's me helping you out. Go backwards. And let's meet up sometime. You know, just to hang or... whatever.

He pauses for a moment, wondering if he should do this. Then he sends the message.

EXT. THE VONNEGUT --

The Vonnegut suddenly rockets forward. As it does, reveal that another craft SPEEDS UP AS WELL, not quite as fast, clearly trying not to be seen.

INT. SLAVE 6 --

The interior of Number Six's ship reveals a one-man bounty hunting operation. He has a live surveillance feed of the Vonnegut, simultaneous from five different angles.

He's also got what must be an ILLEGAL FEED of PARZIVAL'S personal heads up display, though no sound. THEMESSAGE TO ARTEMIS becomes visible as it FIRES FROM THE VONNEGUT.

# NUMBER SIX

(voice command)

Lock me on to that bitch, Slave.

The Slave Six SUDDENLY LEAPS INTO PURSUIT OF THEMESSAGE.

EXT. SPACE -- THE OASIS

The race between Parzival's message and Six in his spaceship is so fast that the ship itself appears as A MASSIVE BLUR.

INT. SLAVE 6

But the result is that for as long as he can keep up with the message, Six can ACTUALLY HEAR IT. It's warped and broken into pieces, but still audible.

# PARZIVAL

... figure out the first challenge... returning the favor...

Six smiles despite the G-force distorting his face. He's onto something and he knows it.

CUT TO:

# INT. AECH'S BASEMENT

Aech is putting the finishing touches on the IRON GIANT, lost in his work.

PARZIVAL (O.S.)

Wow, that looks amazing.

# AECH

(not looking up)

You told her.

PARZIVAL

What?

Aech turns on him.

# AECH

You told her! I can't believe you told her.

# PARZIVAL

I don't know what...

# AECH

Have you seen the board? Artemis is on it.

Aech snaps open a window. A live feed of The Scoreboard reveals Artemis's name in the number two position.

# PARZIVAL

Oh. Yeah. Well, I just felt like... she helped me.

# AECH

That's not why you gave her the clue. Man, I can't believe it. What happened to "Guy Friend before Female you want to Date"? And how much have I helped you?

# PARZIVAL

Dude, I'm sorry, I'll totally give you the...

# AECH

I don't want it, okay? I'll figure it out on my own.

Parzival's call alert starts beeping. He's too embarrassed to answer it.

# AECH (CONT'D)

Well? You just gonna let it ring?

# PARZIVAL

Probably vid-spam.

# AECH

It's her, isn't it? Don't be a tool, answer it.

# PARZIVAL

Nah, she's just a girl, man.

# AECH

ANSWER IT.

ON SCREEN -- A message from Artemis. "Let's meet up".

Parzival's thrilled. Aech is annoyed.

# AECH (CONT'D)

She could be using you, in fact SHE could actually be a HE. Think about that.

Parzival frowns, he hadn't thought of that.

# INT. IOI HEADQUARTERS - REAL WORLD

An excited Nolan Torrento, on his headset, practically runs through the Sixer department at IOI.

# SORRENTO

Backwards? Are you sure?

# NUMBER SIX (O.S.)

I watched her get the key.

Sorrento runs into the main SIXER BULLPEN. There are dozens of Sixers sitting in a hundred top-of-the-line immersion rigs. A monitor above each rig shows us (and Sorrento) exactly what the Sixer in the Oasis is experiencing.

Sorrento whistles, loud enough that everyone turns to look his way.

# SORRENTO

Listen up! Backwards. That's your clue. First one to finish the race, raise your hand.

The Sixers jump back into action. Torrento returns to his voice link conversation with Number Six.

# SORRENTO (CONT'D)

What do we know about this girl?

# NUMBER SIX

Coming your way.

Sorrento taps the monitor closest to him. A single touch scans his ID and instantly displays the information Number Six is sending him.

# NUMBER SIX (CONT'D)

Name's Artemis. She's got a geek cute thing going. She's also got a serious rap sheet.

ON THE MONITOR --

A list of every achievement, and infraction, committed by the avatar named Artemis.

# NUMBER SIX (CONT'D)

Board bans, game suspensions, digital vandalism, politics in a no politics zone. Anti-IOI doxxing...

Six lets out a laugh.

# SORRENTO

What's so funny?

On the monitor, one of Artemis's Oasis crimes is displayed. She is TEABAGGING an NPC in COMPUTER CHESS, but her gamertag?

NOLAN SORRENTO.

# SORRENTO (CONT'D)

That's not funny.

# SIX

Kinda funny. Anyway, I think I

found Parzival's weak spot...

# SORRENTO

You did.

Sorrento's eyes linger on the picture of ARTEMIS.

# SORRENTO (CONT'D)

It's her.

# NUMBER SIX

What? No. It's spaceships.

# SORRENTO

She'll get you what you're after.

# SIXER (O.S.)

Mr. Sorrento! I'm in Central Park, sir!

# SORRENTO

Don't let me down, Six.

Sorrento hangs up and walks over to the immersion rigs. Hetugs on the arm of the Sixer who just yelled.

# SORRENTO (CONT'D)

Come on, get out!

Sorrento yanks the surprised Sixer's visor off and puts it on himself, then climbs into his rig. We notice a special THUMB CAP that clicks in to the gloves, and now the interface reads...

LOGGING IN: NOLAN SORRENTO

INT. OASIS - CENTRAL PARK

Sorrento now stands in front of Bethesda Fountain in Central Park. The copper key just floats there, waiting for him. Sorrento reaches out and GRABS IT.

# SORRENTO

Booyah!

Then he looks around to make sure no one heard that.

EXT. SCOREBOARD

The Scoreboard, huge beyond comprehension, begins to rumble and shake as a new name rolls out into THIRD PLACE.

The Vonnegut streaks past, just a speck in the foreground.

# INT. VONNEGUT

Parzival watches in disgust as the THIRD SLOT on the scoreboard changes to the name "NOLAN SORRENTO".

Feeling guilty, Parzival pulls up Aech in his contacts. There's no response, so Parzival leaves a message.

# PARZIVAL

I'm sorry. I should've said something, you're my best friend. Here's how to beat the first challenge...

And while he explains...

# EXT. STREETS OF PLANET DOOM

Artemis is making her way through the streets of Planet Doom. Her armor meter is high enough that she doesn't need to worry about crossfire. The occasional bullet or shell pings off her and falls to the ground.

Then she notices someone following her. It's IOI Security.

She speeds up a little, then walks right past the entrance to her CLAN CLUBhouse, hoping to lose the tail. She turns a corner.

# EXT. PLANET DOOM - NIGHT

TWO IOI security guards come around a corner, only to be JUMPED by ARTEMIS. She is completely bad-ass in the Oasis, and makes quick work of them with some insane martial arts moves combined with a BLASTER that she uses with deadly accuracy.

More Security Guards close in, firing more ordinance. Artemis's shields are starting to take damage. She has to retreat.

# EXT. ALLEY -- PLANET DOOM

Artemis is PINNED DOWN in an alley, IOI Security closing in from both directions. She ducks out from behind garbage cans, returning fire, but in a few moments she'll be overwhelmed.

# PARZIVAL (O.S.)

Hey Artemis...

Artemis looks up to see Parzival, standing on a ledge above her, wearing A PAIR OF RED HEADPHONES. He tosses her a matching pair.

PARZIVAL (CONT'D)

Put these on.

She puts them on and them Parzival pulls out a supremely bad-ass RAIL GUN.

PARZIVAL (CONT'D)

Just bought this puppy. Check 'er out.

Parzival fires and the gun spits out a super-heated light wave that sprays like a shotgun. The blast incinerates everything in its path, except Artemis, who stands in the center of it, unharmed.

An impressed Artemis looks up at Parzival.

PARZIVAL (CONT'D)

Headphones of limitless protection. Keep em, those are my spares.

Parzival jumps down to the alley to join her, a fine mist of vaporized IOI goons whirls through the air.

PARZIVAL (CONT'D)

So what was that all about?

ARTEMIS

Long story. Let's get off the streets.

Parzival nods, happy to. As they walk away...

Reveal a HOODED FIGURE, watching them from afar. He follows.

EXT. SAFE ZONE -- PLANET DOOM

A comically thin strip of sidewalk is the only safe zone on Planet Doom.

ARTEMIS

Don't know if I told you this, but I like your look.

PARZIVAL

You do?

# ARTEMIS

Yeah, I mean, the Atari Game burial t-shirt, very cool. Also, I like that you're not all 'roided out.

# PARZIVAL

Yeah, I hate that.

# ARTEMIS

Your friend...

# PARZIVAL

I've tried to talk to him about it...

# ARTEMIS

The shoulders.

# PARZIVAL

Too wide, right?

# ARTEMIS

Totally. I mean, nothing personal but... even your arms are a little big.

Parzival checks out his arms.

# PARZIVAL

Are they?

# ARTEMIS

For your frame. I'm just saying, the biceps are kind of... BAM!

Parzival's biceps instantly shrink down a bit.

# ARTEMIS (CONT'D)

There you go, a little less Olympic weightlifter.

Parzival smiles, motions to Artemis.

# PARZIVAL

I like yours too. I mean, your arms, but I mean like... your butt, it's not...

# ARTEMIS

Yeah, tried to keep it real.

# PARZIVAL

And your... you know, your boobs, they're not those ridiculous porn star...

# ARTEMIS

Those things are a huge liability in a death match. You try to hide, but your cans are sticking out from behind a tree.

# PARZIVAL

Yeah.

They walk in comfortable silence; definitely a connection forming.

# PARZIVAL (CONT'D)

What do you look like in the real world?

# ARTEMIS

Hey. Boundaries, not cool.

# PARZIVAL

Yeah, I'm sorry, I just... it would be... you know, to meet you. In person.

# ARTEMIS

You'd be disappointed.

# PARZIVAL

No I wouldn't. (then)

Are you a guy?

# ARTEMIS

No!

# PARZIVAL

I'm just saying, I don't care what you look like. I'd like to meet you. I mean, I have no idea where you live, and I'm sure you'd be disappointed in me but...

# ARTEMIS

Shhh!

Artemis motions to more IOI SECURITY GUARDS up ahead, searching for their missing quarry. They duck behind a billboard advertising MADDEN 74.

ARTEMIS (CONT'D)

Parzival, listen...

PARZIVAL

My real name is Wade.

ARTEMIS

No! Are you crazy? You can't tell anyone who you are.

PARZIVAL

I'm not telling anyone. I'm telling you.

ARTEMIS

And you don't know me, you don't know anything about me. IOI is after me, they're definitely after you. This isn't a game, Z.

PARZIVAL

Uh, yeah, I think it is.

ARTEMIS

Well, you're wrong. It's not.

A hovering graphic up ahead indicates END OF NON PVP ZONE. Artemis stops.

ARTEMIS (CONT'D)

Z, seriously, what would you do if you found the egg?

Parzival is taken aback, almost like he hasn't really thought this through.

PARZIVAL

I don't know, I mean, what wouldn't I do? Buy myself the best rig, the biggest space ship... I'd get all the shit I could never afford.

ARTEMIS

And what about the Oasis?

PARZIVAL

I'd keep it like it is, I guess, like it should be.

ARTEMIS

That's the thing, Z, it isn't how it should be. Not anymore. Whoever wins this, they're going to need to work to keep things free.

# PARZIVAL

I'm not really that into politics

# ARTEMIS

It's more than politics, it's basic human decency. IOI has all this double speak about "maximizing bandwidth potential," but what it really means is the Oasis is screwed.

# PARZIVAL

Yeah, I guess.

# ARTEMIS

That's why it's so important that we win. We need you, Z. My clan needs you.

Parzival suddenly realizes.

# PARZIVAL

Oh. Oh man.

# ARTEMIS

What?

# PARZIVAL

Aech was right. I'm an idiot.

(embarrassed)

I thought... I thought you wanted to hang.

# ARTEMIS

(not getting it)

I want to do more than hang, I want to clan up.

# PARZIVAL

That's not-- nevermind. It's cool.

I better go.

He pulls the miniature Vonnegut out of his pocket and TOSSES it into the middle of the street. It instantly expands to full size. Artemis is confused by his sudden attitude.

# ARTEMIS

Wait, so what's your answer?

# PARZIVAL

Lemme think about it, okay?

Artemis, bewildered, just watches as his ship rockets away.

Watching all this from a distance, the figure who was following them removes his hood.

It's NUMBER SIX.

CUT TO:

INT. WADE'S BEDROOM - DAY (THE REAL WORLD)

Wade is sleeping in his tiny room when he hears pounding on his door.

RICK (O.S.)

Wade! Get out here!

Wade pulls some pants on, heads out of his room.

INT. WADE'S LIVING ROOM - DAY

Wade walks into the living room to find Alice and Rick waiting for him. They've got his backpack open on the table.

ALICE

Wade? Can you explain this?

Rick, wearing a "Parzival" hat that makes Wade doubletake, holds up Wade's fancy Bootsuit.

WADE

Can I explain why you guys are going through my stuff? No, I can't.

Wade tries to grab the bootsuit, but Rick holds him back.

RICK

This thing costs at least ten thousand credits. Where'd you get the money?

ALICE

Did you steal it?

WADE

I bought it.

RICK

You doing those sex chats?

# WADE

What? No. Ew. Why do you care anyway, Rick? You don't even live here.

# RICK

Neither do you.

# ALICE

Rick!

# RICK

What?

# WADE

Alice? What's he talking about?

# ALICE

We're selling the trailer, Wade.

She slides a LOYALTY CENTER PAMPHLET towards Wade. It's got the IOI logo on it, and reads: 'Work off your debt in weeks at Oklahoma City's new Loyalty Center.'

Wade leafs through the pamphlet in shock.

# WADE

Is this a joke? I don't want to live in this ass-y gulag.

# RICK

You're not gonna live there. We didn't apply for you.

# WADE

What?

Wade stares at Alice, looking for an answer.

# WADE (CONT'D)

What am I supposed to do?

# ALICE

You're getting a little too old not to have your own place. I think your Mom would have wanted...

# WADE

Don't you dare bring my Mom into this, Alice.

Wade looks really upset. Alice, feeling bad, takes him aside.

# ALICE

I'm sorry, Wade. I know it's rough. I just don't know what else to do. It's really hard to find someone you can bear to be with.

# WADE

But Rick?

# ALICE

We don't always get our first choice, kiddo.

Alice hands Wade her IOI gear.

# ALICE (CONT'D)

(whispering)

Here, take my stuff. I don't want to leave you with nothing.

Reluctantly he takes it.

EXT. STACKS - NIGHT (REAL WORLD)

A dejected Wade trudges through the stacks, backpack over one shoulder, headed for his hideout.

As he goes, we hold on a shadowy figure, WATCHING HIM. He's a big guy in a hoodie, with a really LAME TATTOO. He watches Wade disappear into the piled up cars.

CUT TO:

EXT. OBSERVATION DECK - THE OASIS -- DAY

A rail runs along the edge of a deck that hangs in the upper atmosphere. Wind whips furiously, and we reveal Parzival standing on the edge. He looks ready to jump.

He sees Aech approaching.

# PARZIVAL

Thanks for finally returning my calls.

# AECH

I looked deep in my heart and realized, you're my best friend. How can I stay angry?

Aech looks over the edge. It's at least ten thousand feet to the ground.

AECH (CONT'D)

Plus, you sounded kind of bummed when we talked.

PARZIVAL

Yeah, I guess I am.

As if to prove his point, Parzival JUMPS OFF THE EDGE!

EXT. SKY - FALLING -- OASIS

Parzival free-falls. A moment later, Aech joins him.

AECH

So you gotta move out?

PARZIVAL

I mean, they didn't give me any warning.

AECH

That's rough. How'd it go with the girl?

Parzival shakes his head.

PARZIVAL

Don't ask.

Yes, they are still hurtling towards the ground at terminal velocity, but the conversation is as casual as if they were chatting over coffee.

PARZIVAL (CONT'D)

I don't really know anyone. Where do I even go? Where do I log in? Can't believe my Aunt is doing this.

AECH

You don't get to choose your family. But I'm your friend, even in the R.W. So if you need help, you call me, okay?

Parzival looks over at Aech. Despite the fact that he looks like a linebacker and is falling through space at high speed, he can see the sincerity behind his words.

PARZIVAL

Thanks, dude.

# AECH

Now pull your ripcord.

They pull their chutes.

EXT. OASIS - LANDING SPOT

Parzival and Aech leave the RED BULL GLUTEN-PACKED ENERGY LEAP, the promotional jump they just tested out.

# AECH

So this wasn't it. The second challenge.

# PARZIVAL

Nope.

# AECH

I've tried like ten different famous jumps.

# PARZIVAL

I don't think that's the answer.

They arrive at Aech's ship, which is incongruously sitting in a parking lot among many other vehicles.

# AECH

Meaning?

# PARZIVAL

I just don't think the clue is that literal.

Aech climbs on board his ship.

# AECH

Need a lift?

Parzival shakes his head. AECH throws him the gunter salute.

# AECH (CONT'D)

Cheer up, dude. You're still on the board.

AECH'S SHIP BLASTS OFF

And once it does...

A GROUP OF SIXERS ARE REVEALED, five of them, with one very familiar leader, recognizable even through the smoke.

SORRENTO (O.S.)

It's good to meet you in person,

Parzival. I'm a fan.

Seeing NOLAN SORRENTO, Parzival immediately draws his GUNS, and his SHIELDS power up. Sorrento walks forward.

SORRENTO (CONT'D)

Whoa, take it easy, Nombre. None of

us are armed.

IN PARZIVAL'S HUD -- a quick scan reveals that he's telling the truth, no weapons on any of them.

PARZIVAL

What do you want?

SORRENTO

To make you an offer.

PARZIVAL

Not interested.

SORRENTO

This is the kind of offer where you

get everything you've ever dreamed

of.

Sorrento motions to a gleaming, blue TRANSPORT DISC, the fastest, and most expensive way to get around the Oasis.

SORRENTO (CONT'D)

Five minutes, just hear me out,

that's all I ask.

Off Parzival, debating whether to step onto that platform.

EXT. IOI HEADQUARTERS -- THE OASIS - DAY

The IOI executive transport sits on a gated platform at one end of the Courtyard in One IOI Plaza. Sorrento, Parzival and the Sixers zap in.

SORRENTO

I understand why people don't like

IOI. I really do. Everyone wants to

stick it to the man.

Sorrento leads them off the platform and into the courtyard below.

EXT. IOI HEADQUARTERS COURtyard (OASIS)

The courtyard of IOI's Oasis Headquarters is unimaginatively similar to their real world campus, though everything is bigger and more ostentatious.

# SORRENTO

And I like a good treasure hunt as much as the next person. But could you imagine if these so-called "rebs" won the contest?

They walk past a stunning gravity-defying fountain towards the massive towers.

# SORRENTO (CONT'D)

They'd dismantle the place in weeks.

# WADE

Is that what they say?

# SORRENTO

That's what they'd do. You take all the commerce out of the Oasis, it falls apart. Halliday always had a business model, he was no communist.

As they move toward the building's giant glass doors, Parzival sees hundreds of nameless IOI WORKERS filing out a side door towards their respective shitty jobs.

# PARZIVAL

This is where all your employees spawn, huh?

# SORRENTO

Yes, but don't worry, they immediately move off site. The executives -- which you would be -- don't have to interact with the worker bees.

Sorrento points  $\mathbb{Z}$  to the executive elevator.

# SORRENTO (CONT'D)

You'll barely ever see them.

Parzival notices his AUNT ALICE'S AVATAR among the crowd. Despite his mixed feelings about her, it's hard for him to feel good about Sorrento's comment.

INT. IOI HEADQUARTERS - SORRENTO'S OFFICE (OASIS)

Parzival and Sorrento step out into Sorrento's opulent office. The windows off the observation deck afford a stunning view of the surrounding virtual city.

# SORRENTO

IOI wants you, Parzival. To help find Halliday's Easter egg.

# PARZIVAL

That's what I figured.

# SORRENTO

You'd have everything at your disposal, you'd be free to follow any strategy...

# PARZIVAL

But if I win, IOI would run the Oasis.

# SORRENTO

You'd rather run it yourself?

Parzival looks at Sorrento quizzically.

# SORRENTO (CONT'D)

Do you know how hard it is to maintain the Oasis? Do you know how many hours a day Halliday worked?

# PARZIVAL

Twenty hours a day...

# SORRENTO

Twenty hours, that's right.

# SORRENTO (CONT'D)

That's what it takes. Is that the kind of person you are?

Parzival considers this. He is definitely not a "20 hours a day" kind of guy.

# SORRENTO (CONT'D)

Our offer won't require twenty hours a day. But it does come with your own penthouse apartment in Columbus, with the highest speed connection, and the best deck money can buy.

This gets Parzival's attention.

\*

\*

# SORRENTO (CONT'D)

You'll have all of our company's vast resources at your disposal. Money, weapons, magic items, ships, artifacts. You name it. And I haven't even gotten to how well this job pays.

# PARZIVAL

I don't think I can be a SIXer, it's...

# SORRENTO

(interrupting)

Two million a year. To start.

# PARZIVAL

Oh. Shit.

# SORRENTO

Regardless of outcome. And if and when you help us find the egg? You'll get a twenty-five-million-dollar bonus.

Parzival says nothing...

INT. WADE'S Hideout (REAL WORLD)

While in real life, a hyperventilating Wade has to take his visor off just to catch his breath.

# WADE

Holy crap.

He slips it back on.

INT. SORRENTO'S OFFICE (OASIS)

Parzival looks pretty cool as he considers Sorrento's offer.

# SORRENTO

Look, Z, I know you're using emotion-suppressing software right now, and why wouldn't you? It's smart not to give away your hand.

In the background, the planet's simulated sun begins to set, casting a glow over the room. It's actually quite beautiful.

# SORRENTO (CONT'D)

But one thing I can tell you is that life is a lot easier when you have money in the real world. Relationships are easier.

Parzival isn't sure what he's getting at, but it definitely makes him think.

# PARZIVAL

When you say we... One question...

# SORRENTO

(knows the question)

As our employee, you'd be playing on behalf of IOI.

# PARZIVAL

So IOI would own the Oasis?

# SORRENTO

We would own it, Wade. All of us who work at IOI. Well, all of us who own stock.

# PARZIVAL

But we keep Halliday's rules? Equal access, equal bandwidth...

Sorrento tightens, tries to smile. This is a bit of a sore subject.

# SORRENTO

Ah yes, equal bandwidth, Halliday's dream. Do you know how much that slows things down, Wade? It's a lovely idea, but do you know how much faster and better the Oasis can be? If we maximize the bandwidth potential for income?

ON PARZIVAL -- hearing those buzzwords, maximize bandwidth potential. It strikes a chord.

# SORRENTO (CONT'D)

Your 25 million will be worth fifty million two months after IOI takes over. That's a guarantee. Fifty million, is that a good deal?

# PARZIVAL

I'm sorry, no.

Sorrento's face falls.

PARZIVAL (CONT'D)

I'm probably going to really regret this, but I can't do it.

# SORRENTO

I'm sure you'll regret it, but I understand, I really do. In fact, I'd like to say something off the record.

Parzival shrugs, "why not?"

With a wave of his hand, Torrento disables all the cameras and microphones in the room.

# SORRENTO (CONT'D)

The truth is, I had to make this offer. The Board insisted. But I was really hoping you would say no. Because if anyone wins, it's going to be me. My avatar will get that egg, because the truth is, I am the only one with the balls to run this place right.

# PARZIVAL

Wow, you kind of switched gears there from "fairly reasonable" to "maniacal overlord".

# SORRENTO

Ha, funny. There's the obnoxious wit I've heard about. Well, consider yourself lucky, Wade, because you won't be around to experience my "maniacal" reign.

Parzival reacts. Did he just say "Wade"? Sorrento gets a wicked grin on his face.

# SORRENTO (CONT'D)

Yes, that's right. I know who you are. Wade Owen Watts. Born August twelfth, 2024. Both parents deceased. I also know where you are.

A vidfeed window opens directly behind Sorrento, displaying a live aerial view of Wade's Stacks.

# SORRENTO (CONT'D)

You live with your aunt in the  
Stacks. 700 Portland Avenue in  
Oklahoma City.  
(MORE)

SORRENTO (CONT'D)  
Unit 56-K, to be exact. You were last seen entering her trailer three days ago and you haven't left since. Which means you're still there right now, and there's no time to get out.

He puts a hand on Parzival's shoulder.

SORRENTO (CONT'D) I'm sorry Wade, it really wasn't personal.

Parzival suddenly blinks out. Torrento turns back to the vidfeed monitor, watching as IOI DRONES approach the Stacks.

INT. CARGO VAN -- THE REAL WORLD

But of course, Wade isn't IN the Stacks, he's in his hideout. He tears off his haptic gear and scrambles out of the van.

EXT. THE STACKS PERIMETER - NIGHT

Wade SPRINTS towards his stack, trying to reach Alice on his headset.

WADE Alice! Alice! You gotta get the hell out of there--

OVERHEAD, Wade can see more DRONES closing in on his stack. They look like they are carrying packages, but as each of them flies in--

They maneuver towards his stack and plant their packages on the support struts of the unit...

Red lights on their side blink faster and faster.

Wade frantically calls out to his Aunt.

WADE (CONT'D) C'mon Alice, pick up...

But Rick answers.

RICK (O.S.) Hey, this bootsuit is pretty awesome, thanks for that...

# WADE

Rick, get out of there! The place is gonna blow!

Rick starts laughing.

# RICK (O.S.)

Hear that, Alice? This douchenozcle is--

And that, sadly, is the last thing Rick ever says...

# KABOOM!

The support columns are blown apart, and the entire Stack begins to teeter...

The sound of RENDING METAL pierces Wade's ears as the stack RIPS FREE of its scaffolding and CRASHES against its neighbor, like a massive domino.

Wade watches, frozen in shock and horror as THREE STACKS start falling...

# TOWARDS HIM.

He runs as the massive towers split apart and fall, containers and RV homes flipping and tumbling and catching fire as PROPANE TANKS EXPLODE.

Wade just manages to get clear of the collapse. As sirens wail and people scream...

For a moment, Wade just stands there, overcome by the horror of it.

Then he notices someone, staring at him. It's that same GUY, the one with the LAME TATTOO.

He's moving towards him. As Wade slowly backs away, the guy follows him.

Now Wade starts to run.

# EXT. STACKS

Wade is running as fast as he can, but this isn't the Oasis, his real body is out of shape. He sucks air as he rounds one of the Stacks and sees...

AN IOI TRANSPORT pull up to the burning stacks and a dozen IOI Security Guards hop out.

Wade turns and runs in the other direction.

Until Lame Tattoo rounds a corner just ahead of him. Wadeslides, almost falls down, then turns and runs in the other direction.

# AS THE STACKS BURN

Wade runs for his life through the wreckage, trying to get back to cover, his Hideout. He almost runs into another group of IOI goons, but they end up giving him the cover to escape from Lame Tattoo.

# INT. WADE'S HideOUT

Wade, still clutching his backpack, climbs into his van, out of breath.

He sits there for a moment, in shock, then starts pounding on the steering wheel. Tears stream down his face.

After a moment, he catches his breath and tries to calm himself down.

# EXT. WADE'S HideOUT

Wade looks both ways before emerging from the hideout. In one direction, the burning remains of the stacks, in the other, the beckoning lights of Oklahoma City.

He starts off in that direction when he is suddenly GRABBED FROM BEHIND.

It's Lame Tattoo.

Before he can scream, he has a GAG in his mouth, plastic cuffs around his wrists. Then a HOOD goes over his head.

Everything goes black.

# EXT. STACKS - NIGHT (REAL WORLD)

Police and ambulances surround the disaster at the stacks. An IOI clean up CREW picks through the wreckage right alongside the police.

We hear chatter among onlookers and police about "an exploded meth lab".

IN THE WRECKAGE -- One of the IOI guys pulls out the charred remains of...

A SHAPTIC BOOTSUIT. As he lifts it up, the ashes of an incinerated body drop out of it.

IOI GUY checks the serial number with a scanner. On a small display screen, the details come up...

"Purchaser: WADE WATTS"

Satisfied, IOI GUY nods to the others. Their work here is done.

INT . SUBURBAN HOUSE - BEDROOM - DAY -- REAL WORLD

As the hood is pulled off, the world is blurred and too bright. When WADE'S EYES finally adjust, the first thing he sees is...

A KNIFE. Wade raises his hands defensively, but Lame Tattoo just grabs them and...

SLICES THE HANDCUFFS. Then he pulls the gag out.

Wade coughs, spits. His vision is starting to adjust. He can now see someone sitting just across from him. A woman.

She looks familiar, dark hair and hazel eyes. She has a prominent BIRTHMARK on her left cheek which she hides with her new wave hairdo, but otherwise there's no doubt who it is.

# ARTEMIS

Hey, Wade. Welcome to the rebellion.

It's the real life Artemis, in the flesh.

INT. REB SAFE HOUSE

Wade and Artemis walk through the Reb Safe House. It's run down but animated, filled with other young people committed to the cause.

# ARTEMIS

When I was a kid, we moved around a lot. My Dad was always getting hassled, by the government or corporations or whoever, he just couldn't catch a break. But he fought for his rights, even when it got him in trouble.

# WADE

Wow. Sounds rough.

# ARTEMIS

Well, he went broke, and then he abandoned us. But the point is, he taught me never to back down. He refused to give in to the system's injustice. So damn right I picked up the torch.

Everyone they pass nods to Artemis. She's a leader here.

# WADE

You're even more badass in real life.

# ARTEMIS

Nah.

Artemis leads him past the Reb Oasis War Room, where a bunch of Rebs are logged in to haptic rigs.

# EXT. REB SAFE HOUSE

Wade and Artemis step outside into a rundown neighborhood, a suburban slum. In the distance he can see the gleaming skyline of COLUMBUS, OHIO.

# WADE

That's Columbus, huh?

# ARTEMIS

World's nicest city. If you're rich and powerful. Otherwise you live out here in the bandwidth slums.

She motions to the rundown neighborhood around them.

# WADE

Never knew it was so bad.

# ARTEMIS

It isn't just Columbus.

Artemis points to the horizon, where the Slums are expanding, Favela-like, to cover the Ohio countryside.

# ARTEMIS (CONT'D)

It's everywhere. IOI messes with access speeds to force more and more people into debt. Case in point.

She points to an IOI SECURITY TEAM, accompanied by the POLICE, dragging someone out of his home, The guy has a MOHAWK and wears an ironic "MATRIX KIDS!" t-shirt. His screaming, half-naked girlfriend holds a screaming, totally-naked baby.

# WADE

What the hell?

# ARTEMIS

That was LaJeremy, our neighbor.

LaJeremy is pushed into the back of an IOI transport van and whisked away.

# ARTEMIS (CONT'D)

You fall into enough debt, IOI

takes you in for "loyalty service".

Have you ever seen a "loyalty

center", Wade?

# WADE

Only on a pamphlet.

EXT. IOI LOYALTY CENTER - COLUMBUS DIVISION (REAL WORLD)

An enormous building, like the projects, but there's no activity outside; everyone is inside, all the time.

# ARTEMIS

The key to the whole scam is

getting around Halliday's first

rule; one person, one avatar.

INT. LOYALTY CENTER

The bullden at the loyalty center is quite literally a SEA OF a THOUSAND HAPTIC DECKS, each with a poor soul in it under servitude to IOI.

# ARTEMIS (O.S.)

Sorrento came up with the

workaround. A way to spoof

accounts, so he can take over for a

Sixer whenever he wants. But it's

worse than that.

We watch some random guy working and working, piling up coins from his loyalty rig...

ARTEMIS (O.S.) (CONT'D)

The "loyalists" don't have an identity in there. Earnings just go into a shared account. IOI's.

The coins DRAIN OUT OF HIS ACCOUNT just as quickly.

EXT. COLUMBUS SUBURBS

Artemis and Wade are walking back now.

# ARTEMIS

No matter how hard they work, their debt goes up. IOI charges them for their deck, their access, and room and board. The Oasis was built to be free. These Loyalty Centers will turn everyone into slaves.

# WADE

Halliday never would have let this happen.

# ARTEMIS

I know you love the guy, Wade, and I had a lot of respect for him too, but Halliday knew there were issues, but he never did jack one about it. He wanted the whole world to be a game, and it just isn't.

Wade nods, he's experienced that first hand. Suddenly the events of the past few days come rushing back.

Wade has to stop walking for a moment, he feels dizzy.

ARTEMIS (CONT'D)

You okay?

Wade sits down on the sidewalk.

ARTEMIS (CONT'D)

Wade?

# WADE

They killed my Aunt. She was a jerk to me, but she still raised me, she didn't deserve to die. None of them did.

(turning to her)

And you saved my life.

Wade's eyes are tearing up.

WADE (CONT'D)

Aw man, I must look pathetic.

Artemis dries his tears, she holds his face in her hands.

ARTEMIS

Stop it. You've been through hell.

And you're not pathetic, you're the

number one gunter in the world.

That is bad ass.

Wade and Artemis are incredibly close now, his face just inches from hers. It feels like one of those moments...

But they just sit there, awkwardly. Wade can't make the move. The moment is gone.

ARTEMIS (CONT'D)

We should get back before the

patrols start.

CUT TO:

INT. REB SAFE HOUSE - BEDROOM

Artemis leads Wade into the Oasis War Room. Wade pulls his Aunt's IOI gear out of his backpack.

Artemis shakes her head.

WADE

Oh. Right, IOI can trace it?

She nods.

ARTEMIS

Now you're getting the hang of it.

Wade gets into one of the empty rigs. Artemis watches as Wade does some quick customization, cleaning off the haptic receivers with his shirt, balling up the cord on his headset so it doesn't snag.

Artemis is impressed; when it comes to the Oasis, Wade is a pro. She even imitates him, pulling slack on her cords, as she gets in her rig.

INT. AECH'S BASEMENT - NIGHT

Aech is in his basement, studying a smaller version of the Vendor's Oasis Map.

# AECH

Enhance.

Despite looking like a real map, the image ZOOMS IN. Aech refers to a few different MARKED LOCATIONS where "The Leap" might be.

# AECH (CONT'D)

Gotta be the Brooklyn Bridge.

# PARZIVAL (O.S.)

Nope, not the answer.

Aech turns to see Parzival entering, Artemis right behind him.

# AECH

Z! I was worried about you, man.

He and Z do their elaborate high-five move. The one that really is cool.

Aech nods to Artemis, somewhat less enthused. The feeling is mutual.

# PARZIVAL

Are they here?

# AECH

(nods)

They're here.

SHOTO and DAITO step forward.

# PARZIVAL

Shoto, Daito, this is Artemis.

Artemis takes a small bow.

# PARZIVAL (CONT'D)

Of all the gunters, Shoto and Daito are the two most skilled fighters I've ever seen. They're maxed out on all PVP categories.

Shoto and Daito bow back to Artemis.

# PARZIVAL (CONT'D)

You guys all got my message? Aech, are you someplace safe?

# AECH

I'm on the run.

Parzival turns to Shoto and Daito.

# PARZIVAL

Same for you two. If you're with us, they'll come looking for you.

Parzival pauses, then addresses the group.

# PARZIVAL (CONT'D)

A good friend told me that we would be better off working together. I didn't listen to him.

Aech is a bit embarrassed, he knows it's him.

# PARZIVAL (CONT'D)

I thought Halliday wanted us to do it alone, but that's only how he would've done it. I think he wanted someone to be better than him.

# ARTEMIS

So we're clanning up?

# PARZIVAL

Yes. (to Artemis) But I'm not joining your clan.

Artemis is confused. Wade turns to Shoto.

# PARZIVAL (CONT'D)

(to Shoto)   
Not yours either. (to the group)   
We are the Clan. Right here in this room, this is the Oasis Dream Team. We're the "first five" and we are going to win this thing together or not at all.

Murmurs of agreement from everyone, except Artemis.

# ARTEMIS

Z, you know it's not that easy for me, I'm committed.

# PARZIVAL

Does your Clan know how to find the second challenge?

# ARTEMIS

No, of course not.

# SHOTO

Do you?

Everyone turns to look at Z. He smiles.

# PARZIVAL

Yes.

(to Artemis)

Don't want to put you on the spot, but if you're with us, you're with us.

Artemis nods.

# ARTEMIS

Okay. I'm in.

# AECH

So spill, where's the jump?

# PARZIVAL

There is no jump.

# AECH

Skeptical, but intrigued.

# PARZIVAL

"Where lovers wouldn't leap." It hit me today. It's about a girl. (meeting Artemis' eye) And the leap he didn't take.

Artemis doesn't seem to get Parzival's meaning, but Aech does.

# PARZIVAL (O.S.) (CONT'D)

After they blew the Flunkie Sprat job, Halliday and Morrow met to work on a new idea. It was a seminal moment in history.

INT. GREGARIOUS GAMES -- 1998

Gregarious games headquarters, circa 1998. Morrow sits at his laptop, Halliday paces.

# MORROW

I don't think that'll track.

# HALLIDAY

Just try it, Og.

Morrow hits a button, the machine renders, SLOWLY.

REVEAL --

That our assembled team is watching the scene together in the Halliday Journals. The Historian is there as well. Parzival monologues.

# PARZIVAL

I've watched the scene a million times, the night they sketched the plans for the Oasis. It took sixteen years to make it work, but this is where it began.

Bored, Morrow leans back in his chair.

# MORROW

So, how was it?

# HALLIDAY

I missed the voiceover. I don't care what people say, I like the voiceover.

# MORROW

You know that's not what I mean.

Halliday, frustrated, paces quickly now.

# MORROW (CONT'D)

What happened with her?

# HALLIDAY

She thought it was kind of dull, can you believe that?

# PARZIVAL

This is the same girl Halliday was swooning over months before. He took her to a movie, but he still hadn't taken the leap.

Morrow shakes his head, it's like pulling teeth with him.

# MORROW

What does that have to do with getting your mack on?

# HALLIDAY

It just bothers me, it was a bomb when it came out, how can people not recognize genius?

# MORROW

Ahead of its time. Like us. But Jim... did she....

# HALLIDAY

She invited me back to her place.

# MORROW

And?

# HALLIDAY

I don't know. Nothing happened.

# PARZIVAL

STOP!

Parzival turns to Aech.

# PARZIVAL (CONT'D)

See what I'm talking about?

"Counting sheep." That's what gives it away.

# AECH

(catching his drift)

"Do Androids dream of electric

sheep...." Right. I mean, you forget because he says it was a bomb...

# ARTEMIS

(figuring it out)

Wait, it was a bomb?

# PARZIVAL

Way ahead of its time. The Citizen Kane of dystopic future noir films.

# AECH

You think this is the clue to the key?

# PARZIVAL

Definitely.

The Historian clears his throat.

# HISTORIAN

I know I'm a computer program and I should know this, but what movie are you talking about?

They all look at him, disappointed. Then, together...

# ALL Blade Runner!

EXT. SPACE -- THE OASIS

The Vonnegut rockets across the Oasis Solar System, once again passing the enormous SCOREBOARD. We hear Parzival's voice, pre-lapped.

PARZIVAL (O.S.) Everyone knows Blade Runner has its fingerprints all over the Oasis, in the architecture, the vision of the future, even the avatars.

The Vonnegut shoots towards a large planet with a number of orbiting moons.

# EXT. MOVIE THEATER ROW - NIGHT

A row of MOVIE THEATERS extends to the horizon, each of them playing one of Halliday's favorite movies: War Games, Star Wars, Raiders, Road Warrior, Terminator, Ferris Bueller, Last Action Hero, all of the Monty Python movies...

PARZIVAL But if you know Halliday, you know that one of the first things he built in the Oasis was a place for his favorite movies.

Our fabulous five come to a marquee with BLADE RUNNER: ORIGINAL EDITION on it.

SHOTO So, what, we're gonna watch Blade Runner?

PARZIVAL Something tells me there'll be more to it than that.

They pass through the doors of the movie theater, and are suddenly transported to...

# EXT. LOS ANGELES 2019

HARRISON FORD as Deckard sits at his counter seat at the noodle parlor. People speak crazy polyglot languages. It is -- literally -- Blade Runner.

Parzival, Aech, Artemis, Shoto and Daito suddenly appear in the middle of the crowded street.

# SHOTO

Whoa. We're IN Blade Runner?

# AECH

It's the immersive cut. (looking around) Think it's the Oculus Criterion Edition.

# PARZIVAL

Yeah, but this isn't the beginning of the movie.

# AECH

We're what, eight minutes in?

# PARZIVAL

Nine forty I believe.

Parzival notices a counter in the corner of the screen, going down from three hours.

# PARZIVAL (CONT'D)

But that's not what's in our HUDs. Stay on your toes, people, this is the challenge.

# ARTEMIS

I wonder what we're supposed to do?

# SHOTO

Let's just go ask Deckard.

Shoto immediately heads over towards the noodle shop. Daito follows him.

# PARZIVAL

Hold on, that might not be...

But they've already gotten close enough.

# PARZIVAL (CONT'D)

... the best idea.

# SHOTO

Hey, Deckard.

Deckard looks up at Shoto for a moment, then he pulls out his gun and SHOOTS HIM. The rest of them scatter.

Daito takes a bullet to the back and dies too. He and Shoto are both dead in the challenge, though they can still be heard arguing in Japanese over voice chat.

EXT. LOS ANGELES 2019

Parzival, Artemis and Aech hide in a side alley.

# ARTEMIS

Well, now we know what the challenge is.

# PARZIVAL

Do we?

# AECH

We're replicants, the bad guys.

# PARZIVAL

They weren't the bad guys, they were misunderstood. They're more like the Na'vi in Avatar.

# AECH

Whatever dude, split hairs.

# ARTEMIS

We expire in less than three hours. Not much time. What should we do?

# PARZIVAL

Something in the clue, "prove how you're made". That's the key. To the key. Come on.

He grabs Artemis's hand and leads her away. Aech reluctantly follows.

# INT. INTERVIEW OFFICE - TYRELL CORPORATION

Parzival, Artemis, and Aech walk through the office building from the opening scene, the one with the ceiling fans and atmospheric smoke. A wall suddenly appears between them, separating them.

# ARTEMIS

Hey!

# PARZIVAL

Remember what you...

Too late, the three of them will each be doing the challenge on their own.

# INT. OFFICE - NIGHT

Parzival slowly approaches a desk with a Voight-Kampff machine sitting on it. He knows which chair is his.

To his surprise, instead of Morgan Paull, the original actor, ANORAK sits across from him. He's still got the cigarette and the slicked back hair.

# ANORAK

You're walking through a desert and come upon a tortoise...

Parzival smiles, he knows this part.

# PARZIVAL

What's a tortoise?

# ANORAK

You ever seen a turtle?

# PARZIVAL

Of course.

# ANORAK

Same thing. You reach down and flip it on its back.

# PARZIVAL

Do you make up these questions, Mr. Halliday?

# ANORAK

Just answer the questions. You're on a date...

That throws Parzival, definitely not from the movie.

# ANORAK (CONT'D)

At the movies. Your date invites you to her place for a drink. What do you do?

Parzival takes a long pause.

# PARZIVAL

I go with her.

A long pause. Then Anorak stands up and extends his hand.

# ANORAK

Alright. You're not a replicant.

Anorak hands him a clipboard with the results to his test:

PASSED -- HUMAN

# ANORAK (CONT'D)

(re: clipboard)

Take this down to the next room.

When Parzival looks down, the clipboard is now...

The JADE KEY.

When he looks back up, Anorak has disappeared. And the office door is a JADE DOOR. He turns the key and walks through...

EXT. NEONOIR (OASIS)

Only to find Artemis waiting on the other side. They are back outside the movie theaters.

# PARZIVAL

What the...

# ARTEMIS

Guess I answered quicker.

They look up to see the SCOREBOARD...

ARTEMIS in the lead, PARZIVAL in second.

Aech steps through a moment later.

# AECH

Damn, you guys beat me?

AECH appears on the scoreboard too.

INT. SIXER DEPARTMENT (REAL WORLD)

Sorrento is looking at images of what little is left of the Portland Avenue Stacks, including Wade's Bootsuit. He talks to NUMBER SIX on his HUD at the same time.

# NUMBER SIX

I'm telling you, whatever you did

to his account, he's back online.

# SORRENTO

Not possible, I... deleted his account. Permanently.

Clearly Six doesn't know exactly how deep and dirty Sorrento goes.

# NUMBER SIX

Well, look at the scoreboard.

Sorrento checks one of the display screens, sure enough there's PARZIVAL, second on the Scoreboard, now behind Artemis.

# SORRENTO

We have to go about this a different way. Get me her identity.

# NUMBER SIX

Gonna cost you extra.

# SORRENTO

I don't care, just find out who she is.

Sorrento signs off.

INT. AECH'S BASEMENT (OASIS)

In the Oasis, the First Five clan celebrates their victory, singing along to "We Are the Champions".

In a rousing moment, Aech turns to Artemis. He holds up his hand for an old-fashioned high-five.

# AECH

Nice moves back there.

# ARTEMIS

(smiles)

You too.

She clears her throat to get everyone's attention.

# ARTEMIS (CONT'D)

Okay, ready for the third clue?

They all clap and whistle. She reads...

# ARTEMIS (CONT'D)

The first was ringed in red metal/  
The second, in green stone/  
(MORE)

ARTEMIS (CONT'D)

The third is clearest crystal/

And cannot be unlocked alone.

A beat as everyone mulls that over.

AECH

What do you think, some sort of key trick?

PARZIVAL

Doesn't say anything about where

the challenge is.

ARTEMIS

Maybe that's the trick.

AECH

Whatever, we've got time to figure

it out, right? More music!

Aech throws another track on, "My Sharona." They all start dancing again.

INT. REB SAFE HOUSE - NIGHT (REAL WORLD)

The Oasis War Room at the Reb Safe House. Wade helps Artemis out of her gear. She's humming MY SHARONA to herself.

ARTEMIS

Never heard that song before, it's

awesome.

Wade looks at her, incredulous.

ARTEMIS (CONT'D)

(shrugs)

I got into the 80’ s stuff cause of

the contest, not the other way

around. So I guess I've got gaps in

my knowledge. The other day some

guy said he was gonna pull a "Lloyd

Dobler" on me, I had no idea

whether to thank him or punch him.

WADE

Say Anything?

ARTEMIS

Excuse me?

WADE

Hold on.

Wade speaks a muffled voice command into his rig, then holds up his headphones. The sound is really good as a SONG COMES UP.

# ARTEMIS

What is it?

# WADE

A great song from Halliday's twenty-seventh favorite movie.

MUSIC CUE: "IN YOUR EYES," BY PETER GABRIEL. They sit together for a moment, just listening to the song.

# WADE (CONT'D)

What do you think?

Cynical dick can turn the page now, but the song has its magic and it WORKS. Artemis smiles, clearly into it.

# ARTEMIS

How do you know all this stuff, anyway?

# WADE

My Mom and Dad, that's what they grew up on. It was all Atari and comic books and Halliday. I didn't get much time with them, they died when I was a kid, but I did inherit their tastes.

Artemis slides closer, so she can hear better. Their legs press against each other. Wade naturally rests his hand on her shoulder.

# ARTEMIS

You ever wonder why Halliday did all this? The contest I mean.

# WADE

I think he was cut off, y'know? He wanted to be understood, but he didn't know how to talk to people. So this was a way to get them to understand.

Artemis nods, makes sense. They just listen to the song for a moment.

# ARTEMIS

So what's a "Lloyd Dobler?"

Wade turns a bit red, then smiles.

# WADE

Well... it's when a guy plays a great song for a girl he's really into, to get her to go out with him.

# ARTEMIS

Oh.

She has her hand on his now.

# ARTEMIS (CONT'D)

You know that thing you said, about not taking a leap...

# WADE

(already leaning in)

Yeah.

Before she can finish her thought, Wade completes it by kissing her. He's surprised that he made the move. She's surprised how badly she wants to kiss him back.

And it's not just a peck, not an accident, not just of the moment. It's a long, slow kiss, and the song keeps playing...

INT. REB SAFE HOUSE - WADE'S ROOM (REAL WORLD)

... as Wade and Artemis connect on a more physical level. And by that I mean sex. They have sex with each other. Or however much people feel comfortable with these days, which is probably more prudish than it should be, but whatever.

When it's over, they fall asleep holding hands.

Music takes us through a TIME CUT. When the music ends, a sleeping Wade opens his eyes. Artemis is getting dressed. From the moonlight coming in through the window, it's clearly the middle of the night.

# WADE

Hey. Where you going?

# ARTEMIS

Wade...

# WADE

Sorry if I pulled a "Dobler" on you.

Artemis can't help but smile.

# ARTEMIS

This was great. I just...

# WADE

I get it.

# ARTEMIS

No, I mean, I can't do this again. I can't be with you.

Wade's smile fades.

# WADE

Why?

# ARTEMIS

I... we both need to be focused on the contest.

# WADE

One doesn't mean the other...

# ARTEMIS

No, it does.

Artemis is hurrying to pull her boots on. Wade sits up.

# WADE

Hey. Artemis. Can you listen to me for one second?

She turns and looks at him.

# WADE (CONT'D)

These clues, the ones Halliday is leaving? They're all saying the same thing.

# ARTEMIS

Wade...

# WADE

He met someone, and he...

(a beat)

... he loved her. And he let it slip away.

# ARTEMIS

Wade, you're embarrassing me.

# WADE

I know, and I'm embarrassing me.

too. But I know what I want. I know

you feel something. I can feel it.

Artemis looks at Wade, very confused.

# ARTEMIS

I'm sorry, I just can't.

She hurries out of the room, leaving a distraught Wade behind.

# WADE (O.S.)

Remember you said if I ever needed

help... in the real world?

CUT TO:

EXT. REB SAFE HOUSE - NIGHT

Reveal Wade, slipping out one of the windows of the Reb house, backpack over his shoulder, whispering to Aech over a headset.

# AECH (O.S.)

Course. Just say it.

Wade lands on the ground. He heads towards the lights in the distance.

# WADE

Well how far away are you from

Columbus?

A pause from the other end.

# WADE (CONT'D)

Aech? You there?

# AECH

Yeah, I'm here. Not that far, maybe

two hours. I'll come get you.

# WADE

Thanks, dude, you are a true

friend.

# AECH

I know. Just don't forget that,

okay? When you meet me.

Aech hangs up, leaving Wade wondering what he meant.

EXT. REB SAFE HOUSE (REAL WORLD)

TWO DRONES have gathered above the Reb Safe House, their red lights pulsing softly. A third and a fourth join them. Something is going down.

EXT. FAST FOOD RESTAURANT - NIGHT (REAL WORLD)

Wade lingers outside of a fully automated fast food place BURGER CHICKEN-CORN PIZZARITO. There are no workers or cooks, just machines that inject processed protein glop into pre-rolled, deep fried burrito shells.

Then, AN RV PULLS UP. A mocha colored SunRider, at least two decades old. A patchwork of solar cells cover the RV's roof along with a liberal amount of rust. The windows are tinted black.

The side door opens, revealing a short ASIAN KID who's way too young to drive. He beckons Wade over.

WADE
Shoto? You're a... kid.

Shoto laughs.

WADE (CONT'D) When did you get here?

SHOTO We flew in yesterday. Aech picked us up. Join the party.

INT. AECH'S RV - CONTINUOUS (REAL WORLD)

Wade climbs in, sees an older Asian male sitting in the back.

WADE And you must be Daito.

DAITO just nods, he doesn't speak English. Then, from the driver's seat, a voice Wade doesn't recognize.

AECH (O.S.) Hi Wade.

Wade turns to see a heavyset African American girl, about Wade's age, with short kinky hair.

WADE Hi. Where's Aech?

# AECH

I'm Helen. My Dad called me "Aech" and it stuck.

Wade is shocked.

# WADE

Wait, Aech? You?

# AECH

Ugh. I knew you'd be mad. Grab a seat.

Wade barely has time to sit down before Aech peels out.

EXT. COLUMBUS (REAL WORLD)

As dawn breaks, the RV rolls into Columbus, the most spectacular city in the world, Paris on the Scioto River.

INT.VAN--

Wade now sits in the passenger seat. The tension is palpable.

# AECH

So what is it, that I'm a girl? Or Black? Maybe I'm heavy, is that it?

# WADE

Of course not. It's just... all those times we talked about girls...

# AECH

Oh, yeah. Well, I'm a lesbian.

# WADE

Really?

Aech laughs. Now that she's smiling, he recognizes her.

# WADE (CONT'D)

Damn, I had no idea.

# SHOTO

You didn't know? Dude, your gaydar is broken.

Aech looks over at Wade.

# AECH

I'm sorry I wasn't honest with you.

# WADE

It doesn't matter. I didn't tell you I was even better looking in the real world.

(looking around the RV)

I like your set up here.

# AECH

We keep it moving. Stay one step ahead. We're rigged up for five if we need it...

She taps what looks like a radar detector on her dash.

# AECH (CONT'D)

Got my 40G wifi hotspot, fully encrypted.

# WADE

Cool.

# AECH

What happened with Artemis?

# WADE

She hasn't realized that she loves me yet.

# AECH

But you love her?

# WADE

Doesn't matter. We have a key to find.

# AECH

That's the spirit.

CUT TO:

INT. REB SAFE HOUSE - DAWN (REAL WORLD)

Artemis walks up to the second floor, looking like she didn't get a good night's sleep. She knocks on Wade's door.

# ARTEMIS

Wade?

No response. She opens the door. His stuff is gone. And so is he.

ARTEMIS (CONT'D)

(tearing up)

Damn it, Wade, I liked you.

Then she sees something strange out the window, shadows moving over the front lawn. Pulling herself together, she goes downstairs to check it out...

EXT. REB SAFE HOUSE - DAWN

Artemis steps outside, studying the strange shadow patterns on the ground. She looks up and sees a weird formation overhead. She squints, realizing too late what it is...

THE SKY IS FILLED WITH DRONES, HUNDREDS OF THEM, like BATS CIRCLING OVERHEAD.

THEN -- BLINDING LIGHTS

A HELICOPTER FLIES IN, BLACK SUITED SECURITY GUYS rush the house. Artemis tries to run but is tackled by IOI SECURITY. THEN TEN MORE SECURITY GUYS rush into the house, gunfire and explosions break the night's silence.

It's an all-out assault.

CUT TO:

INT. AECH'S RV - DAY (THE REAL WORLD)

Aech drives while Daito and Shoto are logged in to the Oasis, keeping up the hunt. It's Wade's turn to sleep, but he keeps tossing and turning, something on his mind...

Finally he bolts upright.

WADE

I just figured it out. The crystal door.

Wade climbs up to the front seat.

WADE (CONT'D)

In Anorak's Castle, there's a crystal door.

AECH

Dude, there's a thousand Anorak's Castles.

WADE

But I think I know which one.

Aech pulls the RV over.

EXT. ANORAK'S CASTLE -- PLANET DOOM (OASIS)

The Vonnegut emerges in orbit on the dark side of PLANET DOOM. Daito yells in Japanese, Shoto points out the window...

# SHOTO

Look!

Nolan Sorrento has just jumped ahead on the scoreboard.

# AECH

Sorrento's got the second key!

# PARZIVAL

And I think they've beat us to the

third challenge...

Even miles away from Anorak's Castle, they can see AN ENORMOUS DOME-LIKE FORCE FIELD surrounding it.

# PARZIVAL (CONT'D)

No, you gotta be kidding me.

The group deflates.

# PARZIVAL (CONT'D)

Screw them.

# AECH

Excuse me?

# PARZIVAL

Screw them. They can't stop us that

easy. I've got an idea.

INT. AECH'S RV - MOVING (REAL WORLD)

Daito is now in the driver's seat, Shoto in the passenger seat translating into Japanese.

# WADE

(zipping up his haptic suit)

Tell him to drive in the middle

lane, safely and slowly.

Shoto translates, Daito nods. Aech gets in her haptic rig.

They log in: READY PLAYER ONE?

INT. IOI HEADQUARTERS -- THE OASIS

Sorrento, in his office in the Oasis, receives an update through a vidfeed window in his HUD. Number Six stands in front of ANORAK'S CASTLE, INSIDE the force field.

# NUMBER SIX

The intel you got from the raid was good, the challenge is in there. It's not easy. But the perimeter's secure, we've got time to figure it out.

# SORRENTO

I'm on my way. Don't do anything until I get there. I want to be the one to walk through the gate.

# NUMBER SIX

Yeah, I figured.

Sorrento closes the vidfeed window and exits...

# INT. IOI HEADQUARTERS -- THE OASIS

Sorrento leaves his office, heading for the executive transport platform in the IOI courtyard. As he walks past the gravity-defying fountain, someone steps in his way.

It's a bad-ass looking Samurai. Despite a face mask, we recognize him as SHOTO. Sorrento tries to step around him, but Shoto blocks him.

# SORRENTO

Get the hell out of my way! Do you know who I am?

# SHOTO

Nolan Torrento, I send greetings from Wade Watts and the First Five.

# SORRENTO

Are you serious? Security!

Before Sorrento can get the word out, SHOTO ZAPS SORRENTO WITH a CATTLE PROD. His avatar crumbles to the ground.

# INT. SORRENTO'S HOME -- THE REAL WORLD

Nolan Torrento's eyes suddenly jolt open. That actually hurt. He looks around.

He's in his Haptic Hamster Ball, in the same room we saw during the virtual tour of his home. He breathes a sigh of relief, the Oasis is so real sometimes...

Relieved, he pulls off his visor, then hits a button, which rotates him until he is standing. The hamster ball separates, revealing...

WADE WATTS, in the flesh, standing right in front of him.

# WADE

Hello Nolan.

Wade is pointing a gun at him. Sorrento goes pale.

# SORRENTO

No, it's not possible.

Sorrento climbs out, catching a glimpse of his own reflection in the polished walls of the rig. It's real world Sorrento, all right.

# SORRENTO (CONT'D)

How did you get into my home?

# WADE

Without killing anyone. So far.

SHOTO steps out, dressed in civilian clothes, but holding a SWORD and a TASER. Despite his age, the look in his eye is deadly.

# WADE (CONT'D)

If you want to keep it that way, you're gonna tell us everything you know about the third challenge and how to pull down that force field.

Off Sorrento, terrified...

CUT TO:

INT . SORRENTO 'S HOME - LATER

The door to Sorrento's Haptic Rig Room opens up, and Wade emerges.

# WADE

(back into the room)

Shot, if his info is bad, start

taking fingers.

We can hear Sorrento's protests as Wade shuts the door behind him. He walks away from the room, and now we reveal...

That this "room" is actually a virtual set inside of AECH'S OASIS WORKSHOP. Wade walks over to AECH, who sits at a control board which has fifteen camera views of the action.

WADE (CONT'D)

He totally bought it.

Wade hands Aech a DATA PACKET (remember they are in the Oasis) and specs for the IOI force field come up in his HUD.

AECH

Course he did. He's in full haptic feedback, he can't tell where he is.

WADE

You hear back from Arty?

Aech shakes his head "no", Wade nods.

WADE (CONT'D)

Great job on the skins, by the way.

AECH

Yeah, missed a spot or two.

Aech points on one of the monitors. THE BACK OF SORRENTO'S HEAD is unfinished.

WADE

Can't look at the back of your own head, right? I wouldn't worry about it.

Suddenly, there's an earthquake-like JOLT.

INT. AECH'S RV - DRIVING -- THE REAL WORLD

DAITO, driving as carefully as he can, has just driven over a huge pothole, but only because he's trying to lose...

THREE IOI DRONES

It's not clear if they are simply sweeping over or actually tailing them, but Daito is taking no chances. He swerves again.

WADE (O.S.)

What the hell?

INT. CONTROL ROOM -- OASIS

WADE speaks through his HUD to DAITO.

# WADE

Slow and steady, D.

Daito lets out a stream of Japanese, the only recognizable words are "IOI Drones".

# AECH

Semi-bad news.

Wade turns back to Aech, who has finished analyzing the IOI force field.

# AECH (CONT'D)

The Force Field is from a spell in

Gauntlet 2027, Magic and Physics

proof. We can un-cast it, but only

if we're in close proximity.

# WADE

So we go to the castle and un-cast.

# AECH

Yeah, but we better hustle.

Aech refers to another monitor, a live feed from a gunter clan...

OUTSIDE IOI HQ -- the SIXER ARMY is preparing for transport to Planet Doom. THOUSANDS OF THEM.

# WADE

Okay, let's wrap this up.

They turn back to the feed of Sorrento. To their surprise, Shoto not only has his sword to his throat, he is angrily interrogating him.

# SHOTO

If you're lying, I cut off your

hands.

# SORRENTO

I'm not, don't! They didn't kill

her, she's still alive!

Wade suddenly looks up.

# WADE

What did he say?

# SORRENTO

The girl, Artemis. We didn't kill

her in the raid. We have her!

Wade and Aech exchange a look.

INT. SORRENTO'S FAKE DECK

Wade storms into the room and grabs Sorrento by the collar.

# WADE

Where is she?

# SORRENTO

IOI, with the other Sixers! She's

fine, a little bruised but...

WADE goes for Sorrento and Shoto has to hold him back.

# SHOTO

(under his breath)

Chill, Wade. You'll wake him up.

Wade turns away from Sorrento, whispers to Aech.

# WADE

Tell Daito to head for IOI HQ, in

the RW. Now.

AECH (O.S.)

On it.

EXT. AECH'S RV - DRIVING

But DAITO has his own issues. More DRONES close in overhead.

Daito has to drive into a tunnel to evade them. An IOI drone EXPLODES as it hits the tunnel strut. But as the van passes into the tunnel, the SIGNAL weakens...

INT. SORRENTO'S FAKE RIG ROOM

The loss of the signal causes the room to PXIELATE, just for a moment. Sorrento catches it.

# SORRENTO

What was that?

Sorrento looks at his reflection again, and this time notices something strange about the back of his head. He tries to contort himself so he can see it, but it's not easy.

Another BUMP, another GLITCH...

Sorrento's eyes narrow. He knows what's going on.

SORRENTO (CONT'D)

You slimy little bastard. Guess

what, I am gonna hurt your little

girlfriend.

Suddenly Sorrento starts pulling at wires that don't seem to be there and... he DISAPPEARS!

# INT. IOI HEADQUARTERS - DAY

The real Sorrento wakes up in his actual home, in his real rig, his high-impact haptic skull piece no longer attached. He carefully opens his hamster ball...

There's no one there.

Furious, Sorrento scrambles out of his unit for real.

# INT. AECH'S RV - DAY

Aech drives as fast as she can in the direction of IOI headquarters, which is visible, not that far away.

WADE

Go faster!

AECH

Going as fast as I can. This isn't my spinner.

It's true, compared to the Oasis, driving in the real world is painfully slow.

AECH (CONT'D)

Can I just make a point here?

WADE

No.

AECH

The Sixers are at the castle on Boom, but they won't take the key without Sorrento. So we have a short window to get out there...

Wade shakes his head.

# WADE

I'm going after Artemis.

# AECH

But Wade... think this through.

# WADE

I love her, Aech.

Aech sighs, she understands.

# AECH

I get it, but breaking into IOI in the Oasis isn't the same as doing it in real life... oh, crap!

Suddenly, Aech swerves...

# EXT. STREETS OF COLUMBUS

Aech's RV has been cut off by a TESLA LIMO-BUS, the kind kids in the future take to prom.

Aech immediately throws the van in reverse...

BUT A SECOND TESLA, an electricity-guzzling SEDAN, has them blocked off.

# AECH

Dude. We're f-ed.

# WADE

We gotta run for it.

Before they can go for the door, a FIGURE steps out into the street, calls to them.

# FIGURE (O.S.)

Aech! Don't be a moron! Get out of your car!

Wade looks at Aech.

# WADE

Who is tha

# AECH

It's not Sorrento.

# FIGURE (O.S.)

All of you, stop juggling your nads and get out here, time is ticking ticking into the future.

EXT. LIMO VAN

They four of them tentatively exit the van and walk towards the figure, slowly.

# FIGURE

Can you please walk faster? Before

all the bad things happen?

# AECH

Ven?

The voice is the same, but it doesn't look like David Cross. And yet that is unmistakably the inflections of the Vendor, who is now revealed to be...

OGDEN MORROW.

INT. LIMO VAN

Ogden leads them into the back of the giant Tesla party-mobile.

# MORROW

(to the driver)

Take us to the back entrance of IOI.

The driver pulls out as Morrow rummages through a bag of stuff.

# MORROW (CONT'D)

I'm impressed with you guys.

Particularly you, Wade, you really picked up on Halliday's message very quickly.

# WADE

One thing I still don't understand, who was the girl, and why Bethesda fountain?

Morrow smiles wistfully.

# MORROW

Her name was Kira. And she was my wife. And Bethesda Fountain, that was the last place I ever saw Halliday.

Off the four, still not understanding...

EXT. BETHESDA FOUNTAIN - FLASHBACK

Halliday and Morrow argue in the real Central Park, circa 2017.

# MORROW

You have to let it go, Jim. Do you understand how insane this is?

# HALLIDAY

I don't have to do anything. You stole her from me.

# MORROW

Stole? Kira and I are getting married. You went on one date with her, fifteen years ago.

Halliday is clearly not thinking straight.

# HALLIDAY

She was the one. The only one. And you betrayed me. You're OUT!

Morrow has tears in his eyes. Halliday walks away, leaving a stunned Morrow alone at the fountain.

INT. LIMO VAN - BACK TO PRESENT

Morrow is emotional recalling the moment.

# MORROW

After Kira died -- and then he got sick too -- he sent me a letter. Very unlike him. It only had two words on the page. "I'm sorry."

# AECH

(tearing up)

Damn. Now I'm getting emotional.

# MORROW

This contest is his confessional. He wants someone to fix the mistakes he made. Or simply not make them again.

The Limo Van comes to a halt.

# MORROW (CONT'D)

As a major shareholder, I'm not supposed to interfere, but that luckbox kidnapped your lady, and that is not cool. Here...

He hands Wade and Aech ID CARDS. For IOI.

# AECH

How'd you get these?

# MORROW

I'm super, super obscenely rich. I can get anything I want. (then)   
Now go. Save your girl. And the Oasis.

The four of them jump out of the car.

INT. IOI HEADQUARTERS (REAL WORLD)

Sorrento, in his own car, is moments away from IOI HQ.

# SORRENTO

Have my rig ready. After I talk to the girl, I'm going in.

EXT./INT. IOI HEADQUARTERS - DAY

Wade and Aech use their ID CARDS to enter IOI HQ. They act casual, careful not to raise suspicion from IOI security.

# WADE

I'll head up to the Sixer floor.

You hit the computers?

# AECH

Got it.

They split off.

EXT. IOI HEADQUARTERS (REAL WORLD)

Sorrento pulls into the executive lot. He literally throws his keys at the valet parking guy.

EXT. PLANET DOOM (OASIS)

Artemis is on a VIRTUAL CHAIN GANG, helping to fortify IOI defenses around Castle Anorak. She drags her feet, a Supervisor glares at her, but then suddenly, she sees the LOG OUT SCREEN...

INT. SIXER BULLPEN

Artemis emerges from the Oasis to see WADE standing over her rig.

# ARTEMIS

Wade? Oh my God, Wade, you came for me!

She embraces him, then he KISSES HER.

# WADE

Come on, we need to move.

He pulls her out of the rig.

EXT. IOI COURtyard -- REAL WORLD

Wade leads Artemis by the hand across the courtyard.

# ARTEMIS

Wait, the exit is over here.

# WADE

We're not leaving, we're logging in.

Artemis looks at him, surprised.

# WADE (CONT'D)

No one's beaten the third challenge yet. You were the one who convinced me. This needs to be done.

# ARTEMIS

Well then we're doing it together. But where...

# WADE

The one place they won't think to look, and where they won't find us if they do.

Wade leads her to the adjacent IOI LOYALTY CENTER.

INT. IOI HEADQUARTERS (REAL WORLD)

Sorrento enters the Sixer department, only to see one of his befuddled functionaries standing next to the rig Artemis was just in.

# SORRENTO

No. You're kidding me.

# SIXER

She was in here...

# SORRENTO

I thought you had her tethered?

# SIXER

We did, sir.

# SORRENTO

Well find her! DAMN YOU, FIND HER!

The Sixer runs off, frightened.

# INT. LOYALTY CENTER

Wade and Artemis run through the rows of hundreds of haptic decks, looking for one in particular.

# WADE

(intocomms)

Talk to me, Aech.

# AECH (O.S.)

It's in the seventh row... exactly

eleven units from the end!

With Aech's directions, Wade quickly locates the rig. They swing it open, revealing...

# ARTEMIS

LaJeremy!

It's LaJeremy, Artemis's NEIGHBOR WITH THE MOHAWK. Wade undoes his restraints.

# WADE

Your debt is officially paid off.

# LAJEREMY

Thank you Artemis! You too... dude.

He bolts out of there. Artemis gets in. Wade climbs in to the next deck.

# WADE

First to the key...

# ARTEMIS

First to the egg!

INT. SIXER DEPARTMENT -- THE REAL WORLD

Sorrento paces up and down the rows of the Sixer department, urging his troops on.

# SORRENTO

Come on, people, first one to get to the final screen gets a bonus. I'm counting on you.

A SIXER approaches.

# SIXER

Sir, we have reason to believe Artemis is still on the premises.

# SORRENTO

Where?

# SIXER

I don't know, but she's in the Oasis right now.

INT. THE VONNEGUT -- THE OASIS

Indeed she is in the Oasis, flying the Vonnegut to Planet Doom, while Parzival streams out a message.

# PARZIVAL

Fellow Gunters, today the assclowns at IOI found the third challenge and they put a FORCE FIELD around it. They think we are too busy fighting each other to notice. Nolan Sorrento thinks the gamers in the Oasis will never pull it together.

Parzival pauses for dramatic effect.

# PARZIVAL (CONT'D)

Well I say, tell that to the gunter clans in the gold mines of Ludus.

(MORE)

# PARZIVAL (CONT'D)

Tell it to the anons and the channers, the newbs in the Reddit Army and the 98th level ninja magic users...

As Parzival speaks, we see his message broadcast...

# EXT. INCIPIO -- THE OASIS

On every billboard, on every blimp, on every screen, in every heads up display... all over Incipio, Avatars stop what they're doing to watch Parzival's message on their live stream.

# PARZIVAL

Tell it to themed Gunter clans, the Dothraki Klingon Alliance, the Trekkies, the 8 Bit Warriors from the Atari system, the stat-heads from the Fantasy Sports guild.

# EXT. THE REAL WORLD (VARIOUS)

Now we focus on individuals in the real world; a portly kid sweating it out in his cheap haptic rig; a cute cheerleader type in a glossy pink immersion unit; a LAN party of 12-year-old pimple-faced geeks in the stacks of Memphis.

# EXT. PLANET DOOM - APPOMATTOX (OASIS)

On the hills of a civil war reenactment, Union and Confederate soldiers stand side by side, looking up at the message in the sky.

# PARZIVAL

I am Parzival of the first five, in the name of Artemis and Aech and Daito and Shoto, we call on all gunters!

# EXT. TIMES SQUARE (OASIS)

Avatars watch Parzival making his declaration on the jumbotron in Times Square...

# PARZIVAL

Join us in glory! Meet us on the dark side of Planet Doom! In the name of Halliday himself, fight for the future of the Oasis!

A BATTLE CRY rises up from a million souls. SHIPS launch into ORBIT. Transport platforms are overrun.

# INT. IOI HEADQUARTERS

Sorrento watches from the Sixer division, growing increasingly frustrated as none of his Sixers have gotten close to the final key.

He gets a message from Number Six.

NUMBER SIX (O.S)

Hey, Sorrento, looks like we've got company.

# EXT. CASTLE ANORAK

Number Six stands outside the Castle. Sorrento appears in a vidfeed window, watching with him. They peer into the distance.

PARZIVAL stands atop the highest point of Anorak's Fence, holding a BOOMBOX above his head. We hear the first few strains of high-pitched guitar...

PARZIVAL

First to the key, first to the egg!

And now the fiery earwig of death that is BLACKENED by Metallica thunders out into the air. And an ARMY OF GUNTERS rushes past Parzival and down towards the castle, all of them chanting...

GUNTERS

First to the key, first to the egg!

A SQUADRON OF FLYING VEHICLES scream across the sky.

ON THE HILLTOP --

Artemis swerves up in the DeLorean. Parzival jumps in, and off they go.

# EXT. CASTLE ANORAK

Number Six notices that Sorrento has disappeared from his HUD. He turns to look back at the Horde.

NUMBER SIX

They'll never get through the force field.

# EXT. CASTLE ANORAK

The Vonnegut, Shoto at the helm, flies over the top of the Castle. DAITO leaps out from the belly of the ship and falls towards the force field. Just as he's about to hit, he utters the magic incantation of undoing...

DAITO RayKassarRassakYar!

... and the spell is un-cast!

# EXT. CASTLE ANORAK -- OASIS

Sorrento zaps in on the transport platform and walks over to Number Six, just as the FORCE FIELD SUDDENLY VANISHES.

NUMBER SIX What the hell?

Sorrento, armoring up, yells an order to his troops.

SORRENTO Sixer Army, do not let them through the castle walls! Attack!

The Sixer Army races out to meet the enemy.

# EXT. VALLEY OF DOOM

An overhead shot of the two massive armies racing towards each other.

WADE (V.O.) Geeks the world over would sing songs of that day. The day the citizens of the Oasis rose up with a mighty fist and collectively rammed it up IOI's hairy sphincter. To the metaphorical elbow.

Within the GUNTER HORDE we find the DELOREAN, weaving past all manner of avatar and vehicle.

# EXT. VALLEY OF DOOM

The DeLorean bounces across the rocky field, plowing through and around Sixers and their allies. Parzival opens his gull wing door and leans out, steering with one hand.

# PARZIVAL

Sniper rifle!

A SNIPER RIFLE suddenly appears in his hand.

# WADE (V.O.)

They say I drove and sniped at the same time. I don't know that it's ever been done before, maybe I had auto-aim on, but I know that bodies fell by my hand.

The armies grow closer and closer. Parzival pops off a shot that blows up a Sixer jeep.

# WADE (V.O.)

The sweat of a hundred thousand nerds poured forth that day. It was violent and aggressive and slightly NSFW.

And now the armies MEET! It's an insane fight, every kind of Avatar one can imagine, as if Peter Jackson staged a battle with cosplayers from Comicon.

# WADE (V.O.)

They sent trolls...

Huge TROLLS stomp across the battlefield, one of them about to STOMP on the DeLorean...

# WADE (V.O.)

... And we countered with Giants.

... until an enormous robotic hand reaches down, grabs the troll and FLINGS IT ACROSS THE VALLEY.

It's the IRON GIANT, driven by Aech.

# INT. IRON GIANT

Aech is steering the Iron Giant from his customized cockpit.

# AECH

Eat giant metal, bitches!

# INT. DELOREAN

Artemis takes over behind the wheel as Parzival fires off more sniper shots. He runs out of ammo and tosses the gun.

# PARZIVAL

More weapons!

# ARTEMIS

Staff of piercing?

Artemis tosses him a DATA PACKET that becomes a long SPEAR in his hand.

# PARZIVAL

Staff of piercing!

He throws it, skewering eleven Sixers at once.

# ARTEMIS

Nuchakus of destiny!

They appear in Parzival's hand and he smacks a disgusting ORC with them, literally knocking it into next week.

# ARTEMIS (CONT'D)

Bow of ending!

Parzival fires a destructive arrow, and now OTHER GUNTERS get into the action, offering their own inventory to Parzival. He repeats the names of each as he uses them.

# PARZIVAL

Anti-personnel ordinance cannon!

Rail Gun! Axe gun!

A gun that fires AXES. Silly, but effective.

# GUNTER

Velociraptor!

Parzival throws a full grown dinosaur at a group of Sixers.

# GUNTER 2

Grenade disguised as a kitten!

Parzival, a bit surprised, looks down at the cute kitten now in his hand. He shrugs and throws it.

IN THE FIELD -- A group of sixers look down at the cute widdle kitty... she purrs and then EXPLODES, incinerating them.

# PARZIVAL

(solemnly)

Musket of Infinite Velocity.

A MUSKET, courtesy of Aech, appears in Parzival's hand. He fires it and A MUSKET BALL smashes through a SIXER, then continues and LITERALLY CIRCLES THE PLANET before smashing into the next sixer, and the next one...

# WADE (V.O.)

Sixer blood ran safe-for-teen green in the rivers of Planet Doom, in the shadow of Anorak's lair.

# EXT. CASTLE ANORAK

Sorrento, starting to get nervous, sees that the tide is turning. He pages through his HUD, looking for the right weapon.

# EXT. ANORAK'S CASTLE

Shoto and Daito are at the front lines, expertly cutting down trolls and IOI soldiers with their samurai swords, trying to clear the one bridge into the castle when...

They come face to face with a SAURON/SMAUG/VOLDEMORT mash up. Forty feet tall, one huge EYE staring down at them menacingly.

Shoto and Daito brandish their swords and face off with the creature, realizing... it's SORRENTO.

Torrento makes short work of Daito, though Shoto manages to hack off one of his hands.

Then AECH steps in as the IRON GIANT. He SQUASHES SORRENTO.

# INT. IOI HEADQUARTERS (REAL WORLD)

Sorrento, infuriated, finds himself logged out of his rig. He rushes to get out of the rig and take another Sixer's spot, when he is approached by IOI Security.

# IOI SECURITY

Sir, we've found them. They're in the loyalty center.

Sorrento follows the guards.

# EXT. ANORAK'S CASTLE

Artemis, driving now, steers away from the main gate where the battle is still being pitched.

# PARZIVAL

All the other bridges are destroyed, we need to go through the main gate.

# ARTEMIS

Too many obstacles.

She heads for one of the shattered side bridges. It has collapsed into the water, but part of it sticks up, almost like... A RAMP.

# PARZIVAL

Could just be a glitch.

# ARTEMIS

C'mon Z, what have we learned? There are no glitches. Halliday put it there for a reason.

The DeLorean roars up the collapsed bridge, hits the ramped part, and TAKES OFF...

Jumping the moat the same way Artemis once jumped the cement truck... and landing right in front of the castle, crushing some Sixers in the process.

Artemis and Parzival prepare to enter the Castle when suddenly...

THE IRON GIANT reaches down and deposits Aech next to them.  
A moment later Shoto and Daito drop in.

The five of them enter the Castle.

# INT. ANORAK'S CASTLE

As our team wanders down a cobblestone corridor, they can hear a SIXER struggling with the challenge.

# SIXER (O.S.)

No. NO!

Tentatively the Five step inside the Castle's cavernous Great Hall to find...

The final challenge is deceivingly simple. It's a stand up arcade cabinet of DONKEY KONG.

The stressed-out Sixer makes a mistake.

# SIXER (CONT'D)

Crap! These effing barrels!

And POOF, he disappears. Clearly you get one shot at the challenge, then you have to start over another day.

Parzival turns to look at the troops.

# PARZIVAL

Everyone ready for some Donkey

Kong?

# NUMBER SIX (O.S.)

Not so fast.

They turn to see NUMBER SIX waiting for them, holding a briefcase.

# PARZIVAL

Who are you?

# NUMBER SIX

Name's Number Six.

# AECH

What'cha got there, paperwork?

# NUMBER SIX

Briefcase nuke. Sorry bucko, but a

job's a job.

Number Six hits a button on the handle...

# BOOM!

A sound like the entire universe cracking in half.

# WADE (V.O.)

When your avatar gets killed, your

point of view shifts into third-

person, giving you an out-of-body

replay of your final moment.

WADE'S POV -- An INCINERATING WHITE LIGHT fills the world, accompanied by an earsplitting wall of sound.

A blast disintegrates everything, all the Gunters and Sixers outside, all the dragons and robots and bunnies. Even the First Five are incinerated, to a fine, atomized dust, suspended in the air for a moment before slowly settling to earth.

# WADE (V.O.)

I waited for the inevitable, final message to appear in my display, the words I knew every other avatar in the sector must be seeing at this very moment.

ANORAK'S CASTLE remains standing, and the Donkey Kong arcade cabinet is still there. Otherwise, the place is empty.

# WADE (V.O.)

GAME OVER.

But instead, a different message appears:

Congratulations! You have an extra life!

Parzival's avatar reappears, fading back into existence right where he'd died a few seconds earlier.

# WADE (V.O.)

In the history of the OASIS, there was no record of any avatar ever acquiring an extra life.

He looks down to see that everything he'd been carrying is gone, and his avatar now wears a black T-shirt and blue jeans, the default outfit on every newly created avatar.

# PARZIVAL

Hello? Can anyone hear me?

Silence. He reaches in his pocket, pulls out...

THE QUARTER. Only now do we realize that it is made of the same high-definition material as the keys, it is a special, gleaming quarter.

# WADE (V.O.)

Morrow had given me the most powerful weapon in all of the Oasis.

Parzival walks up to the Donkey Kong cabinet. He drops the quarter in.

# INT. IOI HEADQUARTERS (THE REAL WORLD)

Sorrento and his Security team race into the Loyalty Center bullpen. Sorrento taps a screen, bringing up a GUIDE to who's in which rig.

ON THE SCREEN -- Every rig has the same name, NOLAN SORRENTO.

# SORRENTO

Let's go, rig by rig, start checking!

The team spreads out through the room, opening one rig after another, searching for Wade and Artemis.

INT. ANORAK'S CASTLE (OASIS)

Parzival calmly progresses through a game of Donkey Kong.

# WADE (V.O.)

I could tell you it was the most epic game of Donkey Kong I'd ever played...

We time lapse Parzival playing a really long game of Donkey Kong, INTERCUT with Sorrento and his men opening rig after rig...

# WADE (V.O.)

But it was actually easier than I expected. Halliday's score wasn't that great.

Parzival finishes a level, his score overtakes Halliday's, Donkey Kong FALLS off the scaffold, and in the process lets go of what he was holding. No, not the Princess...

THE CRYSTAL KEY

It leaps off the screen and appears in front of Parzival. He snatches it out of the air.

INT. LOYALTY CENTER (REAL WORLD)

Sorrento is starting to lose hope that he will find them, the room is so big, there are so many rigs to check...

INT. ANORAK'S CASTLE (OASIS)

Parzival approaches the legendary UNOPENABLE CRYSTAL GATE. It is famed for its lack of a keyhole, but today it has THREE keyholes. Parzival takes out the Copper Key and places it into the first key hole. Then he puts the jade key in the second, and the crystal key in the third. He turns the three keys one by one, then...

THE CRYSTAL GATE OPENS, leading into a spinning whirlpool of stars. Parzival steps through the gate...

INT. ANORAK'S CASTLE - STUDY (OASIS)

And into Anorak's study. Towering shelves line the room, filled with ancient scrolls and dusty spellbooks. And floating in the center of the room...

The egg.

Parzival stares at it, a large white oval with pixelated edges. He gently takes it in his hands, in awe.

Directly beneath a black dragon painting, on an ornate crystal pedestal, sits a gold chalice, encrusted with tiny jewels. Its diameter matches that of Parzival's silver egg.

Parzival places the egg in the chalice. It fits perfectly.

In the distance, a fanfare of TRUMPETS grows, and the egg begins to glow.

VOICE (O.S.)

You win.

Parzival turns to see ANORAK standing right behind him. His obsidian black robes seem to pull the sunlight out of the room.

ANORAK

The game is over. It's time for you to receive your prize.

Anorak holds out a long-fingered hand. Parzival hesitates, then he takes it.

Cascading bolts of blue lightning erupt in the space between them, their spiderweb tines enveloping them both.

When the lightning subsides, Anorak is no longer dressed in his black wizard's robes. In fact, he no longer looks like Anorak at all.

He's James Halliday. Pale, middle-aged, dressed in his Space Invaders T-shirt.

When Parzival looks down at his own avatar, he sees HE is now wearing Anorak's robes. The icons and readouts around the edge of his HUD now show his stats all completely maxed out. He now has a list of spells, inherent powers, and magic items that seem to scroll on forever.

And his credit readout now displays a number twelve digits long.

# HALLIDAY

Congratulations, Parzival. Your avatar is immortal and all-powerful. Whatever you want, all you have to do is wish for it. Pretty sweet, right?

# PARZIVAL

Super sweet.

Halliday leans toward Parzival and lowers his voice.

# HALLIDAY

So you ready to run this place?

# PARZIVAL

Actually, I'm going to split it with my friends.

# HALLIDAY

(nods)

Good thinking. You need someone you can trust, worst mistake I ever made was thinking I could do it alone.

# PARZIVAL

I've got someone I trust, Mr. Halliday.

# HALLIDAY

Don't ever let her go.

Halliday disappears. Parzival barely has a moment to register that he's gone when he's violently pulled from the OASIS.

INT. IOI HEADQUARTERS - THE REAL WORLD

Wade is suddenly pulled out of the Oasis and back into the real world. His rig is surrounded by IOI Security, who also hold Artemis hostage. Nolan Sorrento holds a gun up to Wade.

# SORRENTO

Out. Get out of the rig.

Wade climbs out, though he LEAVES HIS HEADSET with the microphone facing out.

# SORRENTO (CONT'D)

The notion that a piece of stacktrash like you would ever run the Oasis is laughable. The entire system would fall apart in days.

# WADE

Maybe. But it's better than the future you've got planned out, you can of monkey balls.

# SORRENTO

Well, I guess we'll just see about that. Because you're not walking out of here alive.

# WADE

I think you forget, I've already won. I'm a God in the Oasis.

# SORRENTO

You're not in the Oasis anymore.

# WADE

No, but once I tell everyone that they are released from any debt incurred while in the Oasis and are therefore free to log out right now, well...

Sorrento turns to see hundreds of people, rising up out of their rigs.

# WADE (CONT'D)

I guess the question is, how many bullets do you have in that gun, punk?

The crowd of downtrodden "Loyalists" close in on Sorrento.

# ARTEMIS

Put the gun down, Sorrento. It's over.

The Guards, seeing they have no chance, let Artemis go.

# WADE

She's right, Nolan. And before you do anything stupid, you might want to hear about the offer I'm prepared to make you, now that I'm in charge.

Sorrento is nothing if not pragmatic. He puts the gun down. Wade takes it away from him, and then some of the loyalists grab him.

# SORRENTO

Well, what's your proposal?

# WADE

Dude, you killed a whole bunch of people including my aunt. You're going to jail, that's my proposal.

Sorrento yells as he is dragged away.

WADE (CONT'D)

Don't drop the soap!

EXT. IOI HEADQUARTERS - DAY (REAL WORLD)

As Torrento is taken into police custody, Wade and Artemis are joined by Aech, Shoto and Daito. They do a communal three slap hi-five, because as goofy as it looks, that is what's cool in 2044.

# WADE

First to the key...

# ALL

First to the egg!

BY THE FOUNTAIN

Wade and Artemis share a quiet moment away from the crowd. He takes her hand.

# WADE

So what happens now?

# ARTEMIS

I don't know.

# WADE

Maybe we should buy a really nice apartment and move in together.

# ARTEMIS

Well, we only just met a few days ago.

# WADE

Yeah. But I'm in love with you.

Artemis' lower lip starts to tremble.

# ARTEMIS

You're sure about that?

# WADE

Yes. I am. And I'm not gonna miss my chance to tell you.

Artemis leans over and kisses him. We begin to pull back...

WADE (V.O.)

As we stood there, kissing, it occurred to me that for the first time in as long as I could remember...

The kiss is still going...

WADE (V.O.)

... I had absolutely no desire to log back into the OASIS.

And as we pull back, back, we hear another voice...

KID (O.S.)

Did all of that really happen?

HISTORIAN (O.S.)

Exactly as it was told.

INT. WADE WATTS BIOGRAPHY -- THE OASIS

A young boy's avatar -- ERNIE, age ten -- follows the Historian as he ambles down a long hallway, closing all the doors they've opened. The narration of the movie has indeed been Wade telling his own story, just as Halliday told his.

ERNIE

But what happened with the first five? Did Wade share the Oasis with them?

HISTORIAN

Of course. Well, until the great schism. But that's next door, in volume three.

ERNIE

The what?

HISTORIAN

After the War of the Oasis, in volume two, there was the Great Schism. When Shoto raised an army of...

(catching himself)

I don't want to spoil it. Off you go now, your class is leaving.

# ERNIE

Do you know any cheats for Aech's scavenger hunt?

# HISTORIAN

No, and if I did I wouldn't tell you. Off we go.

# ERNIE

I'll come back tomorrow.

# HISTORIAN

No need. Try another book. Or maybe video games?

# ERNIE

I love Parzival and I'm coming back every single day! And I'm gonna write my own memoir!

The Historian looks less than thrilled as Ernie races off to catch up with his class as they exit.

EXT. MEMOIR-OPOLIS (OASIS)

A long line of people snake down the street, all waiting to enter the most popular biography on Memoiopolis:

READY PLAYER ONE: THE STORY OF Z

Wade's story is divided into three separate buildings, one for each volume.

As we pan past the line, we reveal other memoirs, some more crowded than others:

COOKING WITH SWORDS -- Shoto and Daito's poorly reviewed cookbook.

THE HUNT FOR JRC -- A badass account of how Artemis hunted down a rogue JaRichard Cheney in the Oasis Wars.

And finally...

OASIS 2.0, Aech's account of how she built the mysterious and frightening Second Oasis, that some claim exists INSIDE the first Oasis.

Ernie walks past them all, a smile on his face, a sparkle in his eye. Inspired, as we all are, by a great story... no matter what form it might take.

GAME OVER.