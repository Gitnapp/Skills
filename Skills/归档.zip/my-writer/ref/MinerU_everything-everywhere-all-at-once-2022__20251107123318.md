# EVERYTHING EVERYWHERE ALL AT ONCE

Written by

Daniel Kwan and Daniel Scheinert

1

INT . APARTMENT - DINING ROOM/LIVING ROOM - NIGHT

A round mirror sitting on a cluttered vanity. disco lights flash across the clutter. We hear the opening bars of KARAOKE MUSIC.

BEGIN OPENING CREDITS.

Through the hazy mirror, we watch as a Chinese family of three, THE WANG's, sing karaoke together.

They can't agree on a song but they settle on "Barbie Girl" by Aqua. They are awkward and off pitch. But it's sweet. A brief snapshot of happiness. Then, like a flip of a switch-

2

INT . APARTMENT - DINING ROOM/LIVING ROOM - MORNING

SNAP. EVELYN WANG bursts into the room, a 55 year old Chinese woman in an over-sized t-shirt, streaks of gray in her hair, and thin outdated designer glasses.

The tiny dining room is overpopulated with workout equipment, self-help and inspirational business books, an old TV playing a Chinese soap opera, a live security feed for the laundromat downstairs, a rice cooker spewing steam, & a microwave with one minute to go. It is a still life of chaos.

Evelyn sits and looks down at years of tax documents and old receipts. Picking up one of the receipts, she decides which pile to place it on. She changes her mind and holds the receipt in the air, frozen by indecision.

A hand enters frame and grabs hold of the receipt and playfully throws it into a pile. WAYMOND, Evelyn's husband in transition lens glasses and an ill fitting polo shirt, smiles down at her.

Note: Chinese dialogue will be italicized. The random pieces of broken English will be bold for emphasis.

EVELYN

EVELYN

別問

No. Don't even ask.

WAYMOND

WAYMOND

我知道我幫不了你，

我們現在可以聊點別的嗎？

I know better than to ask to help you. But, is now a good time to talk about something else?

He nervously clutches some paperwork with colored tabs poking out.

# EVELYN

I'm listening. Talk.

Evelyn grabs the papers, but he quickly snatches it back.

# WAYMOND

我知道你沒在聽，等你有空再說吧。

# WAYMOND

I know you aren't ... just let me know when would be better

The rice cooker BEEP BEEP BEEPS. Without really taking her eyes off her work, she opens the rice cooker, stirs the steaming rice before shutting it and getting back to work.

# EVELYN

Later. Maybe. I need to

finish this before 爸醒來

你先去 steam the table cloths for tonight. Then paint over the ceiling water stain.

# EVELYN

Later. Maybe. I need to finish this before my father wakes up. Go steam the table cloths for tonight. Then paint over the ceiling water stain.

She gets a text message on her laptop. The sound of a POT OF WATER BOILING OVER in the kitchen.

# WAYMOND

已經辦好了。對了，我剛剛跟Byron提到晚上的事…他的men’s choir準備了一個fun surprise給爸爸。

# WAYMOND

Already did. Also, I just talked to Byron about tonight. The men's choir have a very fun surprise for-

# EVELYN

Noodles! 去煮面

# EVELYN

Noodles. Put in the noodles.

Waymond rushes into the kitchen to tend to the pot.

# WAYMOND (O.S.)

等我們的 Appointment都結束了。我們再聊吧。Like this afternoon?

# WAYMOND (O.S.)

So we'll talk later, like this afternoon? After our appointment-

# EVELYN

5 minutes.

# WAYMOND (O.S.)

What?

# EVELYN

Check the pot in 5 minutes.

爸最討厭煮爛的麵。And which paint did you use?

# EVELYN

Check the pot in 5 minutes. My father hates overcooked noodles. And which paint did you use?

WAYMOND

WAYMOND

白色的。

The white paint.

As Waymond steps back in, Evelyn slams down the calculator.

# EVELYN

We have two different white paints, one for the apartment, and one for the laundromat. Has to be a模一樣，要不然...

# EVELYN

We have two different white paints, one for the apartment, and one for the laundromat. It has to match or else-

WAYMOND

嘘～嘘～嘘～,不要緊張。

# WAYMOND

Shhh. Shhhh. Shhh. Hey calm down.

Waymond turns her chair towards himself.

WAYMOND (CONT'D)

我知道你想把爸爸的party

弄得很完美，讓他看到你已經擁有幸福的家庭和成功事業，他一定會為你感到驕傲。

# WAYMOND (CONT'D)

I know you want everything to be perfect for your father's party, but he's going to see you've nurtured a happy family, and a successful business-

# EVELYN

神經病。你明知道爸不會這樣看我們。

# EVELYN

You know that's not what my father is going to see.

# WAYMOND

但至少是你和我都看到的，不是嗎？

# WAYMOND

But, it's what you and I see, right?

Evelyn begins to relax into Waymond. She looks around the room. She doesn't see much to be proud of.

GONG GONG (O.S.)

# GONG GONG

小莲… 小莲

Little Evelyn ... Evelyn...

# EVELYN

Too late. He's awake.

2-1 A BUZZER. Evelyn turns to the security feed and sees two girls waving at the camera. The MICROWAVE BEEPS.

# EVELYN (CONT'D)

Joy is here? Set the table.  
He's probably hungry.  
我去開門。

# EVELYN (CONT'D)

Joy is here? Set the table. He's probably hungry. I'll get the door.

WAYMOND WAYMOND 好吧，we can talk later- Okay, we can talk later

She is already out the door.

Waymond sighs: typical. He flips over the papers. "Petition for Dissolution of Marriage". Divorce papers.

We can hear the POT BOILING OVER AGAIN.

# INT. LAUNDROMAT - THAT MOMENT

Waiting by a door, JOY WANG - 20's, sporting a worn down hoodie and a stoic, blank expression, stares into a tumbling laundry machine with unfocused eyes. It's hypnotic. A hand grabs her shoulder, pulling her in for a big kiss, snapping Joy out of her daze. It's BECKY SREGOR, Joy's girlfriend. She holds Joy close.

BECKY Thanks for doing this.

Joy rolls down Becky's sleeves to cover up her tattoos and parts her hair to hide her side shave.

JOY (uncomfortable) You look really pretty right now.

BECKY Oh, you like this hot Mormon look?

JOY I'm just telling you now, in case my mom says you're fat or whatever.

Joy points at her nose to indicate Becky "missed a spot". Becky inverts her septum piercing up into her nose.

BECKY You said when she says shit like that it means she cares, right?

JOY My mom is gonna be EXTRA caring now that Gong Gong's here. He literally hasn't spoken to us in decades, and suddenly shows up-

Suddenly the door opens. Evelyn looks from Joy to Becky with a noticeable pause on Becky.

JOY (CONT'D) BECKY Hey Mom. Hi, Evelyn!

EVELYN I only made enough food for three people. I'll have to cook more.

Without waiting for a response she is already up the stairs.

JOY Nailed it.

4 INT. APARTMENT - DINING ROOM/LIVING ROOM - THAT MOMENT

Evelyn comes running up the stairs. Waymond is halfway through setting the table.

EVELYN It's Joy. And she brought Becky.

WAYMOND  
你記得嗎？我們跟Ms.Deirdre說過，Joy爲了避免誤會，會來參加。所以Becky 會去幫忙照顧公公。

WAYMOND Remember? We told Ms. Deirdre Joy would come to avoid any more miscommunications so Becky is going to help watch Gong Gong.

Before Evelyn can object, Becky and Joy are in the doorway.

BECKY Hi, Mr. Wang! WAYMOND Becky! Call me Waymond. Thank you for coming. Sit down, eat!

Evelyn hands Joy a stack of bowls and beckons her into the kitchen. She sloppily strains the noodles before haphazardly dumping in soy sauce, chopped scallion, and sesame seeds.

EVELYN 咬呀～煮爛了！You know he doesn't have to stay.

EVELYN Aiyah. Overcooked... You know he doesn't have to stay.

JOY   
Who?   
EVELYN   
Becky.   
JOY   
Becky is a "she" mom.

# EVELYN

You know I always mix the words. "He", "she". In Chinese, there is one word, tā?, so simple. The way you two dress, I don't think I'm only one calling him: "he"... I mean her "him"... Anyways, our English is fine. And we have Google. You stay with Gong Gong, she can go. I'm sure she is very busy... with her full-time job.

Evelyn takes the entire pot back into the dining room. Joy follows, still holding empty bowls.

# JOY

I honestly think it's weird, but Becky wants to help Mom. She used to volunteer at the nursing home with her church or whatever.

# BECKY

I always learn something when I hang out with the elderly. Old people are very wise.

# EVELYN

It's okay, we'll take Gong Gong to the meeting. You and Becky stay and decorate.

# WAYMOND

quietly to Evelyn)

爸到底知不知道我們被查稅了？

# WAYMOND

quietly to Evelyn)

Does your father even know we are being audited?

# BECKY

Where is he? When can I meet him?

Evelyn thinks about this, clearly uncomfortable.

4-1 A BUZZER goes off. Evelyn looks up at the security camera to see a customer is waiting downstairs at the counter.

# EVELYN

Eat. Fast.

She is out the door. Joy shakes her head, frustrated.

5 INT. APARTMENT - STAIRCASE - CONTINUOUS

Evelyn rushes down the stairs with Joy following behind.

JOY

Mom, wait.

EVELYN

"Wait. Wait." Today, no time for wait.

They go through the door into the adjoining laundromat-

# INT. LAUNDROMAT - CONTINUOUS

Evelyn weaves through laundry carts and customers. We now see Evelyn's laundromat is as eclectic as she is: an old arcade cabinet, a TV playing an old musical, signs advertising wash & fold, alterations, and even singing lessons.

EVELYN

Joy, any other day, I beg that you come and eat, or call me or anything. But today very busy.

Evelyn spots the water stain that Waymond attempted to paint over. It is clearly a different shade of white.

JOY

Mom, this is what it's always like... Look, I know you haven't always liked Becky, but-

EVELYN

I like Becky. She is very nice.

JOY

But...

# EVELYN

你很 lucky 啦。。。

你媽對你交往女朋友的事，已經很

open 了。還是個老外。But Gong Gong, I don't think his heart could take that. Especially not after that flight. Coming all of the way from China just to die like that.

# EVELYN

You are very lucky, your mother is open to you dating a girl. A white girl. But Gong Gong, I don't think his heart could take that. Especially not after that flight. Coming all of the way from China just to die like that.

JOY

Mom... he's not going to die-

Joy follows Evelyn behind the front desk which is cramped with sewing machines, piles of laundry.

A customer with a relatively big nose and a baby carriage is impatiently waiting.

# EVELYN

# EVELYN

哇，他的鼻子很大哦 Welcome, how can I help you?

Wow, what a big nose.

Welcome, how can I help you?

# DEBBIE THE DOG MOM

Um, I wanted to see if my clothes

were ready? I called three times

and-

# EVELYN

Ticket please.

The frustrated customer begins to rummage through her purse. Joy peeks into the carriage but is momentarily horrified to find a fat snorting French Bulldog instead of a baby.

# DEBBIE THE DOG MOM

Here it is-

Evelyn snatches it out of her hand and heads to search through piles of pick up laundry.

# JOY

Mom, we've been together for three

years, don't you think Gong Gong

would want to know-

# EVELYN

Of course. Just not now. Let him

enjoy his party tonight.

# JOY

You think Becky is going to make it

through the entire party without

introducing herself to Gong Gong?

Have you met Becky?

# EVELYN

# EVELYN

(taken aback)

(taken aback)

我以為她要上班。

I thought she had work.

# JOY

She got someone to cover for her.

Is that... not okay?

# RICK

Evelyyyyyn! My belle! Guess whose

20 got eaten by the machine again.

It's RICK, a chipper older white regular, who comes in a little too regularly.

Without missing a beat, Evelyn picks up a baseball bat and uses the handle to THUMP a dented air vent in the ceiling.

# EVELYN

Waymond! More customers need help!

# RICK

(inhaling deeply)

Evelyn! You know, my wife, God rest her soul, used to wear the same exact perfume...

# EVELYN

I see you at the party tonight?

Rick playfully pulls out a party invitation from his pocket.

Used to his come-ons by now, Evelyn smiles in approval then spots Waymond and Becky.

EVELYN (CONT'D)

EVELYN (CONT'D)

客人衣服在哪？三十二號不見了。

Did you move our customer's clothes? 032 is missing!

# WAYMOND

Sorry! It was too crowded. I moved some upstairs. I think the clothes are happier there.

Becky looks to Joy who gives a mock thumbs up.

7

INT . APARTMENT - DINING ROOM/LIVING ROOM - MOMENTS LATER

Evelyn and Joy re-enter the apartment. Hanging precariously from a shelf by the Security Cam TV are some clothes wrapped in plastic with two googly eyes and a sharpie drawn smile.

# WAYMOND (O.S.)

(shouting up the stairs)

See? They're happier here.

# EVELYN

不是說好把Google eyes

全部收起來嗎？No More google eyes!

# EVELYN

I told you to take down all of the google eyes before tonight! No more google eyes!

# JOY

Could we talk about-

Evelyn begins ripping the googly eyes off.

# EVELYN

妳爸阿...过了这么多年

I still don't understand how

his brain works-

# EVELYN

Your father... after all of

this time. I still don't

understand how his brain

works-

# JOY

Can Becky come or-

# EVELYN

Stop changing subject. You know,

with our auditor, she's a terrible

person. Targeting Chinese in the

community. After two year of

meetings, she puts a lien on our

laundromat, and you know what your

father does? He brings her cookies.

神經病！(crazy person!)

7-1

Meanwhile, in the security camera feed we see Waymond's head fall forward then lift up again. He looks around the store suddenly very alert. He beelines it towards a supply closet as if he's in a spy movie. He begins stuffing random objects into Evelyn's purse and his fanny pack.

# EVELYN (CONT'D)

Everyday here is a battle. I fight

I fight I fight for all of us.

Everything I do, I try to make

things simpler, easier,

但妳爸...(but your father...)

Waymond resumes his position by the coin machine and gives

Rick an awkward smile before his head knocks forward again.

Then he wakes up, a little disoriented, but continues hitting

the coin machine... What?

# EVELYN (CONT'D)

...有時候我在想,如果沒有我他怎麽

survive...

# EVELYN (CONT'D)

... sometimes I wonder how he

would have survived without

me...

Evelyn watches Waymond in the security monitor as he

playfully mock-dances with the coin machine. Ignored again,

as usual, Joy grits her teeth.

8

INT．LAUNDROMAT - CONTINUOUS

Evelyn enters as Waymond reaches behind the machine to unplug it, while laughing with Rick.

Joy returns as well and storms over to Becky.

# WAYMOND

Evelyn you have to see Rick dance.

Look, he knows all of the moves!

8-1 He gestures to the TV still playing an old musical. As the two lovers on the screen dance to the orchestral music, Rick follows in time. Waymond claps.

# WAYMOND (CONT'D)

Did you know Rick is in the community theater? He wants to be an actor like you

did. 她也可以去試鏡啊。

# WAYMOND (CONT'D)

Did you know Rick is in the community theater? He wants to be an actor like you did.

Maybe you can audition too.

Evelyn watches the screen as the lovers dance, sing, and circle one another. They move in for a kiss. A flash of longing comes across her face.

She snaps out of it and hands Waymond the Dog Mom's laundry.

# EVELYN

# 把這個給大鼻子

(to Rick)

How much you lose?

# EVELYN

Give this to the customer

with the big nose.

(to Rick)

How much you lose?

# RICK

Twenty. But I take tips.

Meanwhile Becky is trying to calm Joy down.

# JOY

(whispered to Becky)

I don't know how to be any fucking clearer. She can choose: You cometo the party with me, Gong Gong is eternally ashamed, until he forgets it all happened at all, then hedies. OR we don't come. Gong Gong is proud of Mom, until he forgets it all, then he still dies.

Evelyn gasps and shoots Joy a horrified look. Joy's face falls.

# JOY (CONT'D)

I didn't mean that. It was a joke.

# WAYMOND

That's not a very funny joke.

# BECKY

Hey, guys...

Becky is looking at something behind all of them. Joy sees it too. Evelyn angrily rummages through her purse.

# JOY

Mom.

Waymond sees it now and freezes. Evelyn pulls out a $10 roll of quarters and hands it to Rick.

# RICK

This is $10. I thought you people were very good at math-

# WAYMOND

Evelyn...

# EVELYN

Next time I give you rest with interest. You will need it. Actors are very poor-

# JOY

MOM!

Evelyn is startled by her volume. She finally turns:

We see the white wispy hair on the back of an old man's head. He is hunched over his cane wearing a white undershirt and slippers. This is GONG GONG. He stands by the stairwell with unfocused, wet eyes.

# EVELYN

# EVELYN

爸！你落嗥做咩啊？

Baba! How did you get down here?

(In Cantonese)

# GONG GONG

# GONG GONG

我既早餐呢？

Where is breakfast?

(In Cantonese)

Evelyn looks at Waymond who obediently runs up stairs. Gong Gong watches Waymond go with a clear look of contempt.

# EVELYN

# EVELYN

爸，你認唔認得阿Joy?[]

Baba, you remember Joy.

(In Cantonese)

Joy awkwardly approaches. Becky stands behind her, excited.

JOY JOY 公公，好。你..飛機...好不好？ Gong Gong, hello. How was your trip?

GONG GONG GONG GONG哇，七但D唐話越來越差啊。 Wah, her Chinese is getting worse every time we talk. (In Cantonese

Evelyn eyes Becky who is slowly approaching Gong Gong. Joy watches Evelyn watch Becky. Joy tests the water.

JOY JOY   
公公…这是Becky．Becky Gong Gong...this is Becky. 她是我的Howdo you say it Beckyismy...How do you say it again...shit，I mean, again...shit，I mean， crap．She is my...   
她是我的

Gong Gong begins to stare at Becky. Evelyn interrupts.

EVELYN EVELYN好朋友！Becky係侄好朋友。 Good friend. Becky is a very (In Cantonese) good friend.

JOY Mom! EVELYN What?

Joy glares at Evelyn, about to unload everything she wants to say. But she hesitates. Becky smiles, unaware.

EVELYN (CONT'D) AH! Big nose!

Evelyn spots Debbie the Dog Mom leaving. She grabs the laundry and rushes out the door.

Joy grabs Becky and heads for the exit.

BECKY Um, okay, it was nice to meet you.

Waymond comes back with noodles to see Gong Gong standing alone in the room. Gong Gong spits on the ground.

EXT. LAUNDROMAT - THAT MOMENT

Debbie the Dog Mom loads her dog into the car and shuts the door, as Evelyn arrives and hands her the laundry.

DEBBIE THE DOG MOM

Took you long enough.

She takes the coat and looks it over. Evelyn watches Joy and Becky head to their car.

EVELYN

Give us 5 stars? Please!

DEBBIE THE DOG MOM

Are you serious?

EVELYN

(still watching Joy)

Also. We have a Chinese New Year party tonight. Open to all of my customers in the community. Please come and enjoy nice music and food. Let me get an invite- One moment, Joy wait!

She leaves the customer dumbfounded.

Joy has one foot in the car. Evelyn falters.

JOY

What?

EVELYN

I just want to say... Try to eat healthier. You're getting fat.

Becky looks from Joy to Evelyn. No response. Joy shakes her head and shuts the door.

Evelyn turns and walks back into the laundromat.

10 INT. APARTMENT - STAIRCASE - LATER

Evelyn patiently stands with her father as he takes one small step at a time up the stairs. For the first time, we get a sense of how exhausted she is.

11 INT. APARTMENT - DINING ROOM/LIVING ROOM - LATER

Back at her table, Evelyn tries to finish her taxes while Gong Gong loudly slurps on noodles beside her.

Her eyes are drawn up to the wall in front of her. Family portraits, report cards, and children's drawings. She sees an old childhood photo of Joy smiling back at her.

She is surrounded by the chaos of her apartment. Frozen, holding a receipt.

# WAYMOND

# WAYMOND

妳幹嘛？沒事吧

What are you doing? What is wrong?

We hear a DEEP RUMBLING sound. It's in her head, in her soul.

TITLE: "PART 1: EVERYTHING"

12 INT. LAUNDRY RV

Evelyn drives their laundry delivery van, a converted RV filled with racks of clothing and bags of laundry. Waymond is carrying a Tupperware of cookies, looking out the window. Gong Gong sits in the back muttering in his sleep.

# GONG GONG

走啊…快D走啊…日本仔打到來啦… (In Cantonese)

# GONG GONG

We have to go... We have to go. The Japanese are here....

Evelyn turns on the radio.

13 INT. IRS BUILDING LOBBY - LATER

Evelyn and Waymond walk in together pushing a half asleep Gong Gong in his wheelchair through security.

# GONG GONG

# GONG GONG

我咄係邊度啊？

(In Cantonese)

Where are we?

# EVELYN

哩個係…嗯…係我地既生意… (she looks to Waymond)

哩度….我地宜家生意好好。

唸住攤多個牌開多閒。 (In Cantonese)

# EVELYN

This is... um, our business is...

(she looks to Waymond) so busy... we are applying for a new business license so we can expand.

Waymond is shocked by her blatant lie.

# GONG GONG

(with disdain incantonese)

# GONG GONG

(with disdain)  
Hmph. Another laundromat.

咾話。。。又多間？有出色。

WAYMOND WAYMOND 人總有洗不完的衣服，能幫上忙的感覺 People always have dirty 挺好的 clothes. It's nice to feel needed-

Gong Gong's eyes are closed. He's trying to sleep. Crisis averted.

Waymond eyes an elderly couple in front of them. They are holding hands. Adorable.

The couple stops by the restrooms. She hands him her purse and they kiss before she enters. Double Adorable.

Waymond looks at Evelyn, in her own world.

WAYMOND (CONT'D) WAYMOND (CONT'D) 我在想，等這個事情結束以後. I was thinking. Maybe after this is all done, we can go我们要不要一起去旅行？還是.. on a trip or-

EVELYN If I have to think about one more thing today my head will explode.

Waymond grimaces and says nothing. They enter the elevator.

14

INT. IRS ELEVATOR - THAT MOMENT

As the doors close, Waymond's head snaps forward again.

He pulls out a compact umbrella from his oversized fanny pack and opens it up, covering the security camera in the corner.

EVELYN EVELYN 你幹嘛...? What are you-

ALPHA WAYMOND (clear English) You may be in grave danger. There is no time to explain. Hold this.

He shoves the umbrella into her hands, pulls two outdated bluetooth earpieces, places one in each of Evelyn's ears.

Gong Gong SNORES.

# ALPHA WAYMOND (CONT'D)

Pay attention: when we leave this elevator, you can either turn left towards your scheduled audit appointment, or you can turn right and go into the janitor's closet. Do not go into the janitor's closet.

# EVELYN

# EVELYN

神經病 Why would I go-

Don't be stupid. Why would I go-

# ALPHA WAYMOND

Not now.

He shuffles through his bag and pulls out the divorce papers from earlier and, ignoring their contents, begins rapidly writing on the back.

# ALPHA WAYMOND (CONT'D)

Breathe in. You're going to feel a slight pressure in your head.

He presses a button on his phone. A status bar labeled "ALTERNATE LIFE PATH SCAN" begins to go from 0-100%.

# EVELYN

Always downloading these apps on my-

The bluetooth devices turn a bright burning red and her eyes shoot open wide. A bright light spills between the crack in the elevator doors. She breathes in-

14-1 DING! The camera pushes through the elevator doors and we see two legs extend from either side as men in medical scrubs and face masks beckon us in. We hear a baby CRY.

The camera turns to see the father- Gong Gong- who can't hide his disappointment.

# DOCTOR (O.S.)

# DOCTOR (O.S.)

唔好意思，係個女。

I'm sorry. It's a girl.

(In Cantonese)

14-2 DING! Little Evelyn is chasing behind two young boys running with sticks in their hands.

# GONG GONG

# GONG GONG

小蓮(xiao lian)

Evelyn!

The camera/Evelyn looks up at a disapproving Gong Gong and then down at her own two sticks. The two boys run ahead.

14-3 DING! Little Evelyn is sketching the back of a boy's head in class. It's a young Waymond.

WAYMOND

WAYMOND

嘿，畫的漂亮！ Hey that's pretty good.

She hides the drawing.

14-4 DING! Evelyn on the porch beside Waymond now in his 20s.

WAYMOND (CONT'D)

WAYMOND (CONT'D)

將來一定好的。我們可以自己養活自己，跟我走吧。

Can't you see how wonderful it'll be? We can make our own way. Please, come with me.

14 BACK IN THE ELEVATOR: Evelyn watches, overwhelmed.

14-5 DING! Evelyn looks out a taxi window at her crying mother and through the window, we see Gong Gong's stoic stare.

GONG GONG (V.O.CANTONESE)

GONG GONG (V.O. CANTONESE)

如果你真係跟哩個傻仔走，

If you abandon this family for that silly boy, then we will abandon you.

你以後都唔洗翻來啦！

我就當沒生過你！

14-6 DING! Evelyn kicks open the door of their empty apartment. It's small, but it will do.

14-7 They turn on the lights on an old run down laundromat.

14-8 DING! Evelyn stares at laundry tumbling like a tiny black hole.

EVELYN (O.S.)

.phone voicemail incantonese)

啊爸，又係我。你瞬完未啊？等緊你電話！

EVELYN (O.S.)

phone voicemail incantonese)

Ba..It's me again, wondering when you'll call back...

14-9 DING! Evelyn sits at the front desk, customers zip in and out in a time-lapse. She has the sudden urge to vomit.  
14-10 DING! Evelyn finishes throwing up in the sink, holding her belly, she looks up at Waymond. Something ignites in her.  
14-11 DING! Pregnant Evelyn happily wallpapers the laundromat.  
14-12 DING! Evelyn sings baby Joy to sleep.

14-13 DING! Evelyn chases little Joy around the laundromat with a broomstick.  
14-14 DING! Teen Joy slams the front door in Evelyn's face.  
14-15 DING! Evelyn and Joy, parked on the side of the road. A brooding tension.

VOICEMAIL (O.S.)

黃太，麻煩你復翻個電話俾我地，關於你爸爸…(In Cantonese)

VOICEMAIL (O.S.)

Mrs. Wang? We're calling about your Father...

DING! Evelyn is now standing outside of her laundromat with a few suitcases and Gong Gong sitting in a wheelchair, looking clearly disappointed.

14-17/18/DING! Evelyn sorts tax receipts earlier today! DING! Joy shuts the car door on Evelyn. DING! Waymond sighs as they enter the elevator DING! The elevator door closes-  
14 Evelyn blinks. She is back. She exhales, shell shocked.

Waymond shoves the papers he was writing on into her hands.

ALPHA WAYMOND

The moment you are situated in your meeting, follow these instructions, but remember: no one can know. Don't even talk to me about this because I won't remember.

EVELYN

But I-

He shushes her and places a hand gently on her cheek. Evelyn shrivels under the intimacy.

His phone BEEPS. He closes the umbrella, shoves everything into his bag, and strikes a natural pose.

ALPHA WAYMOND

(side of mouth)

Talk to you soon.

His head goes limp.

DING. The elevator door opens. Waymond's head lifts up and he looks around disoriented.

WAYMOND

WAYMOND

哇！電梯好快！

Wow...what a fast elevator...

14-20 He walks out pushing a snoring Gong Gong, leaving Evelyn grasping for understanding.

As she exits, her gaze lingers on the janitor closet to her right.

15 INT. IRS 10TH FLOOR CUBICLE - MOMENTS LATER

The back of the crumpled instructions lay in Evelyn's hands under a desk.

The first line reads: "1. Switch shoes to the wrong feet."

DEIRDRE (O.S.)

Mrs. Wang, are you with us right now?

Evelyn hides the instructions in her lap and looks up.

DEIRDRE ATKINS, a frumpy woman in a cheap suit, is poking at a calculator with one hand and squeezing a hand grip strengthensener in the other.

EVELYN

Of course. I am here. Just thinking.

Clearly frustrated, Deirdre takes a big bite from one of Waymond's cookies and chases it with a protein shake, then points at a receipt with a big red sticky note on it.

DEIRDRE

I asked if you could explain this?

EVELYN

It is a receipt. My receipt. (to Waymond)

我們在說什麼？

EVELYN

It is a receipt. My receipt. (to Waymond)

What are we talking about?

GONG GONG

GONG GONG

净係識係度發白日夢… (In Cantonese)

God, always daydreaming...

Gong Gong doesn't understand but can sense the meeting's going poorly.

# DEIRDRE

I was just hoping you could enlighten me on how, as a laundromat owner, a karaoke machine would constitute a business expense?

# EVELYN

I am a singer.

# DEIRDRE

What?

# WAYMOND

It's true. She has a beautiful voice. (to Evelyn) Sing a song for her.

Deirdre scoffs and shuffles through a pile of forms.

# DEIRDRE

That won't be necessary. But I will need a separate Schedule C for each of these "businesses", because based on what you're trying to deduct, it looks like you're also a novelist, a chef, a-

# EVELYN

But last time, you told me-

# DEIRDRE

Up, up, up... let me finish. A teacher, a singing coach, a... <continues to speak indiscernibly>

Frustrated, Evelyn fakes a smile towards Gong Gong, nodding along as she glances down to her shoes. She slips them off and switches them to the wrong feet.

The next instruction reads: "2. Close eyes, imagine you are in the janitor's closet."

Evelyn scoffs at the absurdity, but she closes her eyes.

We see an imagined POV of the closet door.

The bluetooth devices in her ears VIBRATE and a GREEN light blinks on. Evelyn sits up straight.

The final instruction: "3. Hold that thought and press the green button. P.S. Don't forget to breathe."

Evelyn breathes in and presses the button-

Like the sudden sensation of falling, Evelyn finds herself shooting past cubicle after cubicle until she stops abruptly inside the closet:

16 SPLIT SCREEN: INT. JANITOR'S CLOSET / CUBICLE - THAT MOMENT

In a split-screen, we see half of Evelyn is in a cluttered, dimly lit closet. The other half is still in the tax audit. She looks all around in both worlds. What just happened?

16-1 INT. CUBICLE:

# EVELYN

What is happening?

Deirdre looks up, clearly frustrated.

# DEIRDRE

God, feels like I'm talking to my ex-husband. I already told you... <continues to speak indiscernibly

16 INT. JANITOR'S CLOSET: Someone grabs Evelyn and turns her around. It's Waymond.

# ALPHA WAYMOND

Shhhh... Don't talk. Try to relax your body. Go into auto-pilot.

16-1 INT. CUBICLE: Evelyn tries an innocent smile towards her concerned husband. Deirdre continues to ramble.

16 INT. JANITOR'S CLOSET: [split screen slides away]

# ALPHA WAYMOND (CONT'D)

They do not know I'm talking to you here yet, so hopefully I'll have some time to explain: I am not your husband. At least not the one you know. I am another version of him from another life path, another universe. I'm here because we need your help.

# EVELYN

Sorry, very busy today. No time to help you-

Alpha Waymond covers Evelyn's mouth.

# ALPHA WAYMOND

There is a great evil that has taken root in my world and has begun spreading its chaos throughout the many verses. I have spent years searching for the one who might be able to match this great evil with an even greater good and bring back balance. All those years of searching have brought me here. To this universe. To you.

Evelyn takes a moment to digest this information.

ALPHA WAYMOND (CONT.) (CONT'D)

I know it's a lot to take in right now but I need you to- <continues to speak indiscernibly>

DEIRDRE (O.S.)

Mrs. Wang... Hello?

16-1 INT. CUBICLE: Alpha Waymond's voice fades away and the split-screen focuses on the tax meeting as Evelyn takes control of her body there.

# DEIRDRE (CONT'D)

Mrs. Wang, I'm sure you have a lot on your mind, but I cannot imagine anything mattering more than this conversation we are having right now concerning your tax liability. Need I remind you there is a lien on your property? Repossession is well within our rights.

# EVELYN

I know. I am paying attention.

# DEIRDRE

You think I'm stupid.

EVELYN

EVELYN

你不是嗎？

Maybe?

Waymond puts his hand on her lap. Deirdre is clearly frustrated. She gestures to a small shelf of trophies that say "Auditor of the Month".

# DEIRDRE

You see these? You don't get one of these unless you've seen a lot of shit. Pardon my French. You might only see a pile of boring forms and numbers, but I can see a story. With nothing but a stack of receipts, I can trace the ups and downs of your lives. I can see where this story's going and it doesn't look good.

# WAYMOND

Sorry, my wife confuses her hobbies for businesses. An honest mistake.

Evelyn looks at her husband, hurt. He ignores her.

# DEIRDRE

With this many 'honest mistakes,' even if you aren't charged with fraud, we'll have to fine you for gross negligence.

# EVELYN

You're always trying to confuse us with these words.

# DEIRDRE

Didn't you say you'd bring your daughter to translate?

ALPHA WAYMOND (O.S.)

Hey! Are you paying attention?

16

INT. JANITOR'S Closet: Evelyn's attention is back in the closet where Alpha Waymond is perturbed.

# EVELYN

I cannot talk now. Unless, you can help my taxes. What is "gross necklaces-"

Waymond grabs her by the shoulders and pulls her in.

# ALPHA WAYMOND

I know you have a lot of things on your mind, but nothing could possibly matter more than this conversation we are having right now concerning the fate of every single world of our infinite multiverse.

(he leans in) (MORE)

# ALPHA WAYMOND (CONT'D)

My dear Evelyn, I know you. With every passing moment, you fear that you might have missed your chance to make something of your life. Well I'm here to tell you every rejection, every disappointment has led you here. To this moment. Don't let anything distract you from it.

Evelyn turns towards these words like a flower to the sun.

16-1 INT. CUBICLE: [SPLIT SCREEN] Evelyn smiles.

# DEIRDRE

Oh, so you think this is funny?

GONG GONG

GONG GONG

(Simultaneous)

(Simultaneous)

快D復翻個女人啦。(In Cantonese)

Evelyn! Answer the woman.

ALPHA WAYMOND (SPLIT SCREEN)

(Simultaneous)

So, what will it be?

EVELYN (IRS)

EVELYN (CLOSET)

我捻紧啊-

I'm thinking-

(In Cantonese)

GONG GONG

(to Waymond)

GONG GONG

(to Waymond)

咐有出色。垟都係俾女人話事。

What kind of man has the woman leading the business? Is this how it has been?

成何體統。你係咪男人來啊

(In Cantonese)

Waymond sits up and begins talking to Deirdre during the following scene-

16 INT. JANITOR'S Closet: A loud BOOM shakes the door. Someone is trying to get in.

# ALPHA WAYMOND

Our time here is up. They are going to kill us.

# EVELYN

What?!

Evelyn defensively grabs a broomstick. Another BOOM.

# ALPHA WAYMOND

Do not worry, this is just a burner universe we are using for communication.

A fist bursts through the door, grabbing his face.

# ALPHA WAYMOND (CONT'D)

(calmly)

You will know when it is time to fight. I will be in contact soon. Trust no one.

# EVELYN

Shhhh, I think my other husband is messing up the audit-

Another fist bursts through. Both hands grab hold of his head and SNAP HIS NECK. He falls over dead.

The hands open the door. They belong to Deirdre, who now wears her own pair of earpieces, and has aMESSY SHARPIE CIRCLE scrawled across her forehead. She rips a metal pipe from the wall.

# EVELYN (CONT'D)

No! NO! NO!

Deirdre hits Evelyn across the face with a deadly KLUNK. As her head snaps to the side, the split screen swings away-

17 INT. IRS 10TH FLOOR - CUBICLE

Evelyn's head snaps to the side as she leaps to her feet.

# EVELYN

N0000000000000000000000

She opens her eyes and realizes she is still in the audit. Everyone in the office is looking at her.

# DEIRDRE

Good lord.

# WAYMOND

# GONG GONG

你沒事吧？

(Is everything okay?)

發生畔事？！ (In Cantonese)

(What happened?!)

# EVELYN

Yes, yes of course, everything is very very okay. But I think I forgot something at home-

# DEIRDRE

Sit down.

Evelyn looks from Waymond to Gong Gong, terrified...

She sits. Nobody notices as the scribbled instructions fall from her pocket onto the ground.

Deirdre crushes her protein shake bottle.

# DEIRDRE

I have a feeling I'll regret this

later... but you can go.

# EVELYN

What?

(to Waymond)

你和她說什麼了

# EVELYN

What?

(to Waymond)

What did you say to her?

# GONG GONG

廢話少講。等我同但講。幫我翻譯.

(In Cantonese)

# GONG GONG

Probably something useless.

Let me talk to her. Translate

for me.

# DEIRDRE

You have until I leave the office

tonight to drop everything off.

6pm. Last chance.

# EVELYN

Tomorrow is better, we have

an important party-

# WAYMOND

Thank you. 6pm. Thank you.

# DEIRDRE

Last chance.

Evelyn and Waymond exchange a look. Deirdre's stare never leaves Evelyn as she pushes Gong Gong away.

Waymond spots the instructions on the floor. He picks them up, confused for a moment. His eyes go wide -

18 INT. IRS 10TH FLOOR - MOMENTS LATER

Evelyn briskly pushes Gong Gong towards the elevator periodically looking behind her as Waymond catches up.

# GONG GONG

我仲未老得哂，推我翻去，等我同伯講數。

(In Cantonese)

# GONG GONG

Turn around. I may be old, but I still know how to negotiate.

WAYMOND  
等一下！事情不是你想的那樣。  
(quieter just to her)  
我知道你爲什麼怪怪的。

WAYMOND Evelyn... wait, wait it's not what it looks like. (quieter just to her) I know why you are acting so strange.

EVELYN EVELYN在說什麼？ What are you talking about?

Waymond holds up the divorce papers. But from Evelyn's perspective, she sees the written elevator instructions.

EVELYN (CONT'D) So... you know about this?

WAYMOND WAYMOND  
當然...這是我的。 Of course...this came from me.

EVELYN It's you...? Like... you, who was in the elevator.

WAYMOND WAYMOND對啊。。。I was in the elevator-Yeah...I was in the elevator-

EVELYN Come back next week.

GONG GONG GONG GONG 你地又兩個又係度吵啦啊？ What are you two bickering about? (In Cantonese)

Evelyn looks past Waymond to see Deirdre charging out of her cubicle in their direction. She's coming for them.

Evelyn grabs the papers, throws them on the ground, then presses the elevator button.

EVELYN I'm not ready to fight yet. WAYMOND (really sad) Maybe we don't have a choic

Deirdre is getting closer. Evelyn presses the elevator button again and again.

GONG GONG

GONG GONG

沒膽匪女，做垟都半途而廢。

Little girl. Always running away. Never finishing what you started.

(In Cantonese)

His words cut to Evelyn's core. Evelyn looks up at her distorted reflection in the elevator door, and then down to her fist as it tightens.

EVELYN

EVELYN

老豆，你錯勒！你一地都唔瞭解我。

Father, you are wrong about me...

Meanwhile, Waymond picks up the divorce papers from the floor and sees the scribbles on the back.

WAYMOND

Switch shoes to- WHAT!

Evelyn pushes past Waymond and PUNCHES Deirdre in the face.

Deirdre's body crumples on the ground. Evelyn looks at her fists surprised by how much it hurt her hand.

WAYMOND (CONT'D)

What are you doing?!!!

Deirdre cowers in fear with her hands over her head. People run over to see what the commotion is about.

DEIRDRE

Help! Call security!

WAYMOND

WAYMOND

妳幹嘛打她？！

Why did you hit her?

EVELYN

You told me to do it!

WAYMOND

WAYMOND

妳疯了嗎？！

Are you CRAZY?

EVELYN

You said I would know when it was

the time to fight! She was coming

after us...

Evelyn sees Deirdre is holding their taxes file folder that they left behind.

# DEIRDRE

You have no idea how much trouble

you are in. Assaulting an IRS agent

is a... you have no idea!

# WAYMOND

# WAYMOND

我是在說我們的事。

I was talking about us.

Waymond lifts up the crumpled divorce papers.

# EVELYN

"Dissolution of marriage"? 什麼?

(What?)

# DEIRDRE

(oh phone)

Yes! I'm on the tenth floor. I

don't know what they want, I don't

know if they're armed...

# EVELYN

# EVELYN

是誰給你的。？

Who gave you those papers?

# WAYMOND

# WAYMOND

沒人給我啊！

Nobody gave them to me!

# EVELYN

你哥... (Your brother) gets divorce

and now you think divorce is okay?

# WAYMOND

I don't think it's okay!

# EVELYN

We made a vow!

# WAYMOND (CONT.)

# WAYMOND

Eveyln...我只是希望你和我…

Evelyn...I know. I just wish

you and I.

He lowers his head fighting back tears. Then his head shoots back up and he speaks - in English:

# ALPHA WAYMOND

I told you to stay low and out of

sight.

Evelyn hits him over and over.

# EVELYN

Oh, now you're here? You're confusing me! Coming and going. Stop coming here!

The elevator door opens. It's filled with security guards.

# DEIRDRE

That's her. The Chinese lady!

# EVELYN

(at Alpha Waymond) No! This is his fault!

# GUARD

Everyone remain calm. I need you two to lie down on the ground with your hands behind your heads.

Evelyn obediently lies down, but Alpha Waymond takes her bluetooths and places them in his own ears.

GUARD (CONT'D)

Sir, please comply...

Alpha Waymond reaches into his pouch. The security guards all draw their weapons.

He pulls out his chapstick.

# GUARD (CONT'D)

Whatever you are thinking about doing, don't do it.

He pops open the cap, twists it to FULL STICK, and eats it WHOLE.

# GUARD (CONT'D)

Sir...?

He chews and chews. The guards lower their guns, confused.

The devices VIBRATE and glow GREEN. He presses the button. His head snaps back as if kicked back by a shotgun.

He flashes a devious smile to Evelyn as a security guard walks over and reaches to grab his arm.

He unsnaps his fanny pack which dangles from his fingers.

# GUARD (CONT'D)

Okay, that's enough-

Alpha Waymond whips his fanny pack like a pair of nunchucks right into the guard's face. He recoils in pain.

He deftly knocks each of their guns to the ground, whipping them in the face for good measure.

The guards pull out batons and circle him. It's a standoff.

Alpha Waymond calmly lengthens the fanny pack to full length, prompting the nervous guards to cautiously take a step back.

He reaches into a fish bowl on an adjacent office desk, pulls out a fist of little pebbles, then drops them into the unzipped fanny pack.

They attack. ZIP. He starts beating the living hell out of them with his heavy pack. He is incredible.

# EVELYN

Holy shit.

He snaps the packs around one of their necks then punches him over and over again.

He unsnaps, then whips the buckle up inside one of their nostrils. He spins the pack then yanks, sending the guard spiraling into a printer.

The last wimpy guard runs for the stairs leaving his semiconscious coworkers groaning on the floor. Alpha Waymond turns to Evelyn.

# ALPHA WAYMOND

On your feet!

Evelyn doesn't know what to do. An ALARM begins to blare. Emergency lighting is triggered. Onlookers run for an exit.

# EVELYN

How did you... what is happening?

我們真的要離婚嗎？

# EVELYN

How did you... what is happening? Are we getting divorced?

Waymond slaps her.

# ALPHA WAYMOND

I'm not the Waymond who wants to divorce you, I'm the Waymond who is saving your life. Now, you can either come with me and live up to your ultimate potential, or lie here and live with the consequences.

# EVELYN

I... I... want to lie here.

Frustrated, Alpha Waymond picks her up like a fireman.

Alpha Waymond carries Evelyn past the janitor's closet. The door is closed and unharmed. CUT TO:

19

CLOSET UNIVERSE: INT. IRS 10TH FLOOR

The door is now open and has a massive hole punched through it. Inside lay Closet Evelyn and Closet Waymond's bleeding bodies.

Deirdre with the black circle (bagel) on her forehead addresses confused hostages lined up along the cubicle walls.

# DEIRDRE (BAGEL)

Citizens of the 4,655th Thetaverse.

You are about to be graced by the presence of our sovereign leader,

Jobu Tupaki.

Two small boots walk into frame stumbling forward like a drunk person's. A gentle Rumble builds with each step.

# DEIRDRE (BAGEL) (CONT'D)

Let me assure you of one thing:

Just like every other moment in

your miserable lives, this is

nothing more than a statistical

inevitability.

A hand gently runs along the outer wall of a cubicle.

Directly on the other side of wall push pins sporadically change position, post-it notes change colors and text, a family portrait subtly changes family members.

# DEIRDRE (BAGEL) (CONT'D)

Jobu Tupaki has seen all and knows

all. She knows what makes you tick.

What fragile branches you rest your

self worth upon

Jobu points a finger at Deirdre. Their face is hidden behind an elaborate mask.

# JOBU

Shut up Deirdre, no one likes you.

Deirdre chokes on her words- then breaks down in tears. With her hands in her face she leaps off the balcony. THUD.

The hostages shriek.

JOBU (CONT'D)

Duck, Duck, Duck...

Jobu walks down the line not quite touching any of them on the head. Then stops at Evelyn.

JOBU (CONT'D)

Goose.

They reach out to touch Closet Evelyn, not quite dead after all. The LOW RUMBLE builds. Her eyes go wide.

19-1

RAPID MONTAGE OF CLOSE UPS: We see Evelyn in a series of random universes. She's lying in a field, on a hospital gurney, she's a scarecrow, a surgeon, bees are coming out of her mouth. The universes escalate, almost to insanity-POP.

Closet Evelyn now wears a little baby outfit. Jobu is tickling her. Evelyn is very ticklish.

JOBU (CONT'D)

Funny. You'd think on the verge of death, the brain would turn off the reflex that makes you ticklish.

Closet Evelyn thrashes and laughs. Spitting up blood.

JOBU (CONT'D)

But here you are, blood pressure rising, muscles contracting, pushing out more and more of your precious life source. In a way, this is nice. How often do people literally die laughing?

Closet Evelyn dies. Jobu Tupaki uses her bib to wipe the blood off their hands. Jobu shakes their head disappointed.

A hostage begins to cry loudly.

JOBU (CONT'D)

Shh. Shh. It's not her. But they might be close...

Jobu Tupaki hears a Distant SOUND. CHAD cowers in fear.

Jobu listens more intently before rotating their head. Click! Click! click! Like a radio tuner, we wind through different universes never seeing their face:

19-2

CLICK - They're driving a bus into oncoming traffic.

19-3 CLICK - They're on Wall Street as the stock market crashes.  
19-4 CLICK - They're tagging a wall with graffiti. The FUZZY RADIO SIGNAL suddenly clears up. It's TV News:  
20 INT. DIVE BAR - AFTERNOON

CLICK - Jobu sits in a dive bar nursing a beer sporting a hoodie. They watch people exiting the IRS Building on TV.

NEWS ANCHOR (V.O.)

... there is no word yet on who was behind the attack or what their motives may have been...

BECKY (O.S.)

Ugh. I'm so sick of all of this bad news...

We reveal that Jobu is sitting next to Becky. Jobu abruptly stands up & marches towards the door.

BECKY (CONT'D)

Babe...? What's up-

As Jobu opens the door, the light reveals - IT'S JOY. Jobu Tupaki has taken her over. She leaves, and the camera lingers on the IRS building on the TV.

21 INT. IRS 10TH FLOOR - LATER

Alpha Waymond is pulling Evelyn along through the hallway. They pass small groups of frantic civilians running to safety.

EVELYN

My husband won't even kill a spider. How are you the same person?

ALPHA WAYMOND

You underestimate how the smallest decisions can compound into significant differences over a lifetime. Every tiny decision creates another branching universe, another- were you not paying attention before?

EVELYN

Of course... but you're very bad at explaining-

Waymond spots a couple guards up ahead and yanks Evelyn into an office, shutting the door behind them.

22

INT. IRS 10TH FLOOR OFFICE - CONTINUOUS

# EVELYN

Wait, oh my god. We have to go back. We left my father!

# WAYMOND

Don't worry, we're monitoring him. He's safe.

FLASH: IRS. BREAK ROOM: Gong Gong is finishing his third pudding snack.

Back in the office, Alpha Waymond pulls up a map with thousands of green circles on his cell phone. In the center is a flashing white dot. They speak in hushed whispers.

# WAYMOND (CONT'D)

This is you, this is your universe, one bubble floating in the cosmic foam of existence. Every surrounding bubble has slight variations. But the further away you get from your universe, the bigger the differences.

# EVELYN

A universe where I am finished with my taxes?

# ALPHA WAYMOND

We are talking about infinity. If you can imagine it, somewhere out there, it exists.

# EVELYN

A universe... where I don't have any taxes?

# ALPHA WAYMOND

Sure.

Waymond zooms out on the map to show another flashing white dot far from this universe.

# ALPHA WAYMOND (CONT'D)

This is where I am from.

Alpha Waymond blinks and we match cut to him in the-

23 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

In a chair with an array of wires and cables flowing from every angle, sits Alpha Waymond. Alpha Officers operate various pieces of equipment. One part CIA surveillance truck, one part condemned Radioshack, and one part laundry delivery.

# ALPHA WAYMOND (V.O.)

The Alphaverse. The first universe to make contact with the others. You can call me Alpha Waymond. In this world, you were a brilliant woman. But most people thought you were crazy.

Alpha Waymond looks over at a shrine for Evelyn in the corner. There are some candles, an ornate urn, and a portrait of Evelyn in glasses and a turtle neck.

# ALPHA WAYMOND (V.O.)

In your search to prove the existence of other universes, you discovered a way to temporarily link your consciousness with another version of yourself, accessing all of their memories, their skills, even their emotions.

24 INT. IRS 10TH FLOOR OFFICE - PRESENT UNIVERSE

# EVELYN

Like the Janitor's closet... Like you right now.

# ALPHA WAYMOND

Exactly. It's called Verse Jumping. I need you to pay attention because you need to learn how to do it, right now.

# EVELYN

Right now?

# ALPHA WAYMOND

It may be our only chance of getting out of here alive.

Evelyn is suddenly overcome with nausea.

Alpha Waymond finds a piece of chewed up gum stuck under the desk and pops it in his mouth before pressing his bluetooth. This doesn't help Evelyn's nausea.

ALPHA WAYMOND (CONT'D)

(spitting out gum)

Two guards coming this way. On my

signal, try to blend in.

EVELYN

No! This is crazy... Why can't your

Evelyn do this?

ALPHA WAYMOND

My Evelyn is dead.

Evelyn throws up a little in her mouth.

ALPHA WAYMOND (CONT'D)

Go.

(fake screaming)

Oh my god, oh my god, what is

happening-

25 INT. IRS 10TH FLOOR - CONTINUOUS

Waymond swings open the office door. A group of frantic civilians run past. Waymond grabs Evelyn, still screaming, and joins the group.

Two armed guards approach the group opening office doors. Evelyn and Waymond run right past them.

As soon as the guards pass out of sight, Waymond stops screaming and pulls Evelyn into a stairwell.

26 INT. IRS STAIRWELL

Evelyn and Waymond stand with their backs against the door inches away from each other.

EVELYN

How did I die?

ALPHA WAYMOND

I've seen you die a thousand ways.

In a thousand worlds. In every

single one, you were murdered.

Alpha Waymond heads down the stairs.

EVELYN

What?! Who wants me dead?

# ALPHA WAYMOND

An evil omniversal being with unimaginable power. An agent of pure chaos, with no real motives or desires. Jobu Tupaki.

# EVELYN

You're just making up words-

Waymond puts his hand on her lips. A few floors below, they catch a glimpse of police headed up towards them.

They head back up the stairs.

# ALPHA WAYMOND

(into earpiece)

We need another exit.

# EVELYN

Wait. Why is Joey Joowee hunting me?

# ALPHA WAYMOND

Jobu Tupaki. Because she knows, no matter how powerful she is, no matter how unlikely it is, in an infinite number of universes, there has to be at least one where someone can stop her.

27 INT. IRS 8TH FLOOR CORRIDOR

# EVELYN

Let her destroy the other bubbles.

You say there is a lot of them, maybe it's okay if we lose some.

Just leave me out of it.

Alpha Waymond gets serious.

# ALPHA WAYMOND

It's not so simple. She's been building something. We don't know exactly what it is. We don't know what it's for. But we can all... feel it. You've been feeling it too, haven't you? Something is off. Your clothes never wear as well the next day, your hair never falls in quite the same way, even your coffee tastes... wrong.

(MORE)

# ALPHA WAYMOND (CONT'D)

Our institutions are crumbling, nobody trusts their neighbor anymore, and you stay up at night wondering to yourself...

# EVELYN

How can we go back?

Evelyn is completely taken in by Alpha Waymond's speech.

# ALPHA WAYMOND

This is the Alphaverse's mission: To take us back to how its supposed to be. But that begins with finding the one who can stand up to Jobu's perverse shroud of chaos. One who believes in truth and order.

# EVELYN

And you think that's me?

# ALPHA WAYMOND

Why else would we risk everything to get you out of here?

The color drains from her face. He pulls her into an office space to reveal:

28

INT. IRS 8TH FLOOR - CUBICLES

# DEIRDRE (BAGEL)

There you are.

# EVELYN

Oh, Miss. Deirdre, look I think I finally understand--

Deirdre is wearing her own modified bluetooth headsets. She picks up a post-it note and staples it to her forehead. We see that her hands are red: blood. The headsets turn GREEN.

# EVELYN (CONT'D)

What's she doing?

# ALPHA WAYMOND

Verse jumping. Run!

Deirdre slams the stairwell door shut. Evelyn and Alpha Waymond run. They spot dead bodies around the room.

Deirdre presses the button, her head cocks back. She opens her eyes and flips a table with incredible strength.

As they flee. The camera pushes into Waymond's head

29 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

ALPHA OFFICER #1

She jumped somewhere: brute force.

Sumo wrestler? Body builder?

ALPHA WAYMOND

Doesn't matter. Counter with

someone agile.

An onscreen interface rapidly scans a cluster of circles each representing other universes. A few begin to blink.

ALPHA OFFICER #2

On your perimeter we've got break

dancer, mime, gymnast-

ALPHA WAYMOND

Give me gymnast! Go!

ALPHA OFFICER #1

Calculating route...

Onscreen, we see rapidly flashing images of gymnasts. Then flashing paths through circles. Finally a path solidifies. "ROUTE FOUND"

ALPHA OFFICER #1 (CONT'D)

Paper cuts. Four of them. One

between each finger.

30 INT. IRS 8TH FLOOR

Waymond rips some paper from a bulletin board and starts trying to slice paper cuts while running. It's not working.

ALPHA WAYMOND

Paper cuts only happen when you

aren't trying. It's impossible.

ALPHA OFFICER #1 (O.S.)

Probability of 1 in 8 thousand.

It's the strongest jumping pad

we've got.

Frustrated, Alpha Waymond gets down on one knee to focus.

EVELYN

What are you doing???

SLICE. One down. Deirdre is closing in on them.

SLICE. Two down.

SLICE. Three down. Evelyn leaves him behind and runs.

SLICE. That's four. The bluetooth turns GREEN. He is about to press the button-

Deirdre catches his hand. With effortless strength, she lifts him up in the air, and spins him over her head like a prow wrestler. His headsets fly out of his ears.

31 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

ALPHA OFFICER #1

Is that... pro wrestling?

ALPHA OFFICER #2

She's going for a backbreaker!

32 INT. IRS 8TH FLOOR

Deirdre lifts him up to drop on her knee, but Alpha Waymond grabs an exit sign and holds on as Deirdre tries to tug him away. The exit sign rips from the ceiling. Just as Deirdre drops him, Alpha Waymond slips the sign between his spine and her knee.

The exit sign shatters. It's painful as hell for both of them, but at least Alpha Waymond's spine is intact.

As Alpha Waymond painfully begins to retreat, Deirdre runs at him and drop kicks him in the chest with both legs knocking him back down a nearby stairwell.

Deirdre shuts the door and shoves large filing cabinets to block it.

Across the room, Evelyn hides under a desk.

33 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

ALPHA OFFICER #1

She's gotta run.

ALPHA WAYMOND

No! She can jump. Somewhere she can

fight.

ALPHA OFFICER #2

She's not ready. A jump like that would fry most people's brains.

ALPHA WAYMOND

She's not most people.

34 INT. IRS 8TH FLOOR STAIRWAY HALLWAY

Alpha Waymond pushes against the cabinets. They won't budge. He is weak again, like regular Waymond.

35 INT. IRS 8TH FLOOR

Evelyn's phone vibrates. Waymond is calling.

ALPHA WAYMOND (O.S.)

Evelyn! Can you hear me? You're going to have to verse jump.

She spots the two bluethoos on the floor. She picks them up and places them in her ears.

EVELYN

Okay. What do I do?

ALPHA WAYMOND (O.S.)

Concentrate on a universe in which you studied martial arts.

EVELYN

Just because I'm Chinese doesn't mean I do kung fu-

ALPHA WAYMOND (O.S.)

Just do it!

Evelyn closes her eyes.

36 ALPHAYERSE: INT. LAUNDRY RV CONTROL ROOM

Onscreen images flash: Kung Fu masters, a baby crying, a deer in the headlights, etc.

ALPHA OFFICER #2

I'm locking in. Ready in 3, 2, 1...

"CALCULATING ROUTE" blinks onscreen."

37 INT. IRS 8TH FLOOR

Deirdre stalks the cubicles looking for Evelyn.

ALPHA WAYMOND (O.S.)

You have to profess your love to

Deirdre.

EVELYN

No way.

ALPHA WAYMOND (O.S.)

It's like eating the chapstick. Or

switching your shoes.

38 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

On the screen, we see the center universe marked Point A (Current Verse). Far away is a highlighted universe marked Point C (Fighter Verse). Along the highlighted route is Point B between them (the Universe where Evelyn professes her love to her Attacker).

ALPHA WAYMOND (V.O.)

It takes an immense amount of mental energy to jump to further universes. You developed an algorithm that calculates which statistically improbable action will place you in a universe on the edge of your local cluster, giving you the momentum needed to reach your desired counterpart. It's your jumping pad.

39 INT. IRS 8TH FLOOR

Evelyn frantically crawls through the cubicles as Deirdre stalks her like a Minotaur in its maze.

EVELYN

That doesn't make any sense!

ALPHA WAYMOND

Exactly. The less sense it makes, the better. The Stochastic Path Algorithm is fueled by random actions. Tell her you love her. And mean it!

EVELYN

Are there any other jumping pads?

# ALPHA WAYMOND

The next best paths are break your own arm, or take a nap. You're not sleepy are you?

Suddenly Deirdre's foot steps right in front of Evelyn's face. She looks up at Deirdre in terror.

# EVELYN

(meekly)

I love you?

The earpiece blinks YELLOW. Evelyn pushes the button.

# ALPHA WAYMOND

Wait!

Her mind launches out the building and we land-

40 TAXES UNIVERSE: INT. LAUNDRY RV [SPLIT SCREEN]

Evelyn and Waymond sit in the RV. Evelyn spots the divorce papers in her lap. This isn't the universe she wanted to jump to.

# EVELYN

No, no, no, no...

40-1 FLASH: We see the moment in the elevator where Alpha Waymond first contacted her. Only this time Evelyn refuses to take the umbrella and Alpha Waymond gives up.

41 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

# ALPHA OFFICER #1

She's in a local divergent universe.

# ALPHA WAYMOND

She's gone home to... finish her taxes.

42 INT. IRS 8TH FLOOR [SPLIT SCREEN]

Evelyn panics and tries to punch Deirdre. Deirdre easily catches her wrist and twists it. Evelyn screams in pain.

Deirdre laughs and slaps her over and over.

43 TAXES UNIVERSE: INT. LAUNDRY RV [SPLIT SCREEN]

Evelyn's face is red with pain. Waymond is shy and scared.

# WAYMOND

我沒有要傷害你！

教會的Byron告訴我，以前，他和太太的感情一直不好，直到他們開始談離婚，因爲把話聊開了。反而感情變好了。

# WAYMOND

I'm not trying to hurt you. Byron, from church said he and his wife were miserable, until they discussed divorce and- talking it out actually helped...

# EVELYN

# (strained)

This doesn't make any sense...

# WAYMOND

Think about it.

除了紧急的事,每次我找你聊。you always get pulled away-

# WAYMOND

Think about it. Unless it's an emergency, whenever I try to talk to you, you always get pulled away-

An arm grabs Evelyn's collar and pulls her away-

44 INT. IRS 8TH FLOOR

Deirdre grapples Evelyn in a spectacular finishing move sending her through a cubicle wall. The bluetooth light goes out: she's disconnected.

Evelyn spots the cabinets Alpha Waymond is trapped behind. She runs and starts tugging a cabinet out of the way.

# ALPHA WAYMOND

I'm sorry, Evelyn. I gotta go.

# EVELYN

What?

Alpha Waymond has his hand pressed against the cabinets gently.

# ALPHA WAYMOND

I need to find the right Evelyn.

And this one... it's not the one.

# EVELYN

Wait, no! Let me try again!

Evelyn pushes a cabinet away and squeezes through. Waymond looks utterly confused.

WAYMOND WAYMOND Evelyn！怎麽回事？ Evelyn! What's going on?

Alpha Waymond is gone. Evelyn pushes Waymond back through some doors and shuts the door tight behind them.

INT. IRS STAIRWELL

WAYMOND Evelyn! Your face.

Evelyn's nose is bleeding and her face is battered.

EVELYN You left me. You just left me.

WAYMOND  
What? I'm still  
what? I'm still here. Do you mean the divorce?  
here.你是指離婚的事嗎？

The reminder of the divorce causes a great dissonance in her mind. Her bluetooth malfunctions and flashes GREEN:

TAXES UNIVERSE:EXT．LAUNDROMAT

Evelyn and Waymond sit in the RV.

WAYMOND I wanted to start off the new year on a new foot. But...  
我希望新年有個新的開始。但是。也許  
你是對的。如果我們沒結婚的話也許會  
更幸福。  
we had never gotten married.

EVELYN EVELYN  
我從來沒說過. I never said that  
WAYMOND WAYMOND  
你根本不用說, You didn't have to. It's the way you look at me.

EVELYN Waymond...

The car door is ripped off-

47 INT. STAIRWELL

The door is ripped from its hinges to reveal a sweaty angry Deirdre. Evelyn panics.

```txt
EVELYN ... I love you! WAYMOND (touched) What?
```

EVELYN

EVELYN

走開啦！

Get out of the way! (to Deirdre) I love you! I love you!

(to Deirdre) I love you! I love you!

Her bluetooth turns YELLOW. Evelyn grabs Waymond's hand and they run down the stairs as Deirdre laughs.

Evelyn turns to see Deirdre leap off the top step and straight into the air right towards her. Evelyn falls on her knees and finally gives in.

```txt
EVELYN (CONT'D) (like a prayer) I LOVE YOU!
```

The bluetooth turns GREEN. She presses the button.

A shock goes through her brain. Just as Deirdre's knee is about to hit Evelyn's nose, TIME SLOWS DOWN TO A CRAWL.

The camera patiently pushes into Evelyn's head, through countless universes then stops:

48 MOVIE STAR UNIVERSE: INT. LIMOUSINE

Evelyn lounges in her limo dressed in a lovely gown. She gasps as she rapidly downloads memories.

WE GO THROUGH MEMORIES LIKE A TRAIN GOING THROUGH A TUNNEL:

48-1 - EXT. HONG KONG ALLEY - 1980s - Evelyn and Waymond, in their early 20's, on the porch.

YOUNG WAYMOND

YOUNG WAYMOND

難道你看不到嗎？如果你跟我走，我們會有美好的將來。

Can't you see it? How wonderful it would be if you came with me?

The screen fractures like a prism, and we see two options: one universe where Evelyn drives away in the taxi with him, and one where she stays with her family.

We follow the universe in which Evelyn stays:

48-2 -EXT. HONG KONG STREET - NIGHT - Evelyn is walking alone crying softly to herself. A mugger grabs her purse and knocks her to the ground.

Moments later, her purse drops back down beside her. She looks up to see a regal woman in traditional attire: classic KUNG FU MASTER. She has beaten up the mugger.

48-3 - EXT. WOODS - Classic training montage moments: Evelyn carrying buckets of water up and down a mountain, doing pinky push ups, breaking clay pots with her fists.

In a quick series of moments, the Kung Fu Master playfully keeps a cookie away from Evelyn. This is her toughest challenge. She never quite gets it.

KUNG FU MASTER (V.O.) 功夫不只是打鬥，而是熟能生巧，做好一塊餅乾也是功夫。

KUNG FU MASTER (V.O.) Gong Fu is not just about combat. It is the mastery of any discipline. Even this cookie can be Gong Fu.

48-4 - INT. KUNG FU COMPETITION - Evelyn executes a perfect kick to her opponent's face.

She is being honored with a medal. She looks at her Master with great pride. Her Master bows her head. A Hollywood Manager with a cigar seems very impressed.

48-5/6/7 - MONTAGE - of Evelyn working with her Kung Fu Master on a film set. Then another one and another one.

MOVIE STAR UNIVERSE: INT. LIMOUSINE - She's back. She looks across the limo at her MASTER like she has never seen her before. She pulls out a cookie from her pocket and Evelyn instinctively grabs for it and they do a poetic kung fu dance as she marvels at her own hand's abilities.

Evelyn almost grabs the end of the cookie but fails. The Master smiles. It's a sweet moment.

KUNG FU MASTER  
雖然我們已經不再是當年的自己，但你不能忘記當年學武的初心。  
我以你為榮。

KUNG FU MASTER Though we are far from our humble beginnings. You must never forget why you learned Gong Fu. I am proud.

The camera pushes back into her head:

49

INT. IRS - STAIRWELL - ORIGINAL UNIVERSE

Not even a second has passed. A single tear is suspended from her eye.

Evelyn's fists close tightly, and she inhales. TIME RESUMES LIKE A SLAP TO THE FACE.

In one fluid motion, Evelyn side steps the knee, grabs hold of Deirdre's arm mid-air, then slams her to the ground.

Evelyn looks at her hands. It worked.

Deirdre attempts to grapple her, but Evelyn easily dodges the advance and sends Deirdre tumbling down the stairs. Her head crashes through the drywall and she goes limp.

Evelyn disconnects. Waymond runs over and lifts her up.

# WAYMOND

Why did you-? How-? 你在哭嗎？

# WAYMOND

Why did you-? How-? Are you crying?

# EVELYN

(through tears)

我看到我的人生如果沒有你會是多麼的美好！

# EVELYN

(through tears)

I saw my life... without you... I wish you could have seen it...

Waymond is drawn in.

# EVELYN (CONT'D)

... it was beautiful.

# EVELYN (CONT'D)

... it was beautiful. I should have listened to Baba. All of those years ago-

我當年應該聽我爸的話，不要跟你走。

Waymond looks at her with a pained confusion. He begins to say something, but Alpha Waymond returns. He grabs her hand and begins walking away from Deirdre's limp body.

# ALPHA WAYMOND

We better keep moving. Now you've definitely got Jobu's attention.

50

INT. IRS - CONFERENCE ROOM

Alpha Waymond leads Evelyn into a conference room with half-eaten catering bagels and fruit strewn across the table. Waymond collects napkins and ice to tend to their wounds.

# ALPHA WAYMOND

Stay calm. Your brain is under an incredible amount of stress.

# EVELYN

Wait... let me finish talking with my husband-

# ALPHA WAYMOND

Shhh, you're not thinking straight.

# EVELYN

No, he needs to know how good my life could have been-

Evelyn hears VOICES. The bluetooth glitches. Flashing lights hit her face. We hear ROARING CROWDS.

51 MOVIE STAR UNIVERSE: INT. LIMOUSINE

The limo door to reveal she is at a movie premiere: the red carpet, the screaming fans, the flashing lights. It's beautiful..

ALPHA WAYMOND (O.S.)

Evelyn... Evelyn!

A hand slaps her in the face-

52 INT. IRS - CONFERENCE ROOM - ORIGINAL UNIVERSE

Alpha Waymond slapped her in the face.

# ALPHA WAYMOND

Are you with me?!

# EVELYN

I thought I was disconnected... why am I still there?

Alpha Waymond shows her the map of her mind. There are three new green circles, for each universe she has jumped to.

# ALPHA WAYMOND (CONT.)

Your mind, it's like a clay pot holding water. Every jump opens another crack... causing things to leak through. With training, you will learn to reseal these cracks. Eat. You need energy.

Alpha Waymond hands her a plate of half eaten food. He takes a massive bite from a bagel with cream cheese. His eyes close in ecstasy.

ALPHA WAYMOND (CONT'D)

Cream cheese... Ohhhhhh. In my universe, the cattle were killed off. One of the many things we've lost in our war against Jobu.

He begins chugging from a carton of half and half.

EVELYN

What if... I want to go back? Back to the other universe-

Alpha Waymond begins shaking her furiously.

ALPHA WAYMOND

SHUT IT DOWN. SHUT IT DOWN! ARE YOU WITH ME?! COME BACK!!!

EVELYN

I'm with you! Okay. I'm with you!

He checks the map. Evelyn is stable.

ALPHA WAYMOND

Listen: You are only using the other worlds to acquire special skills. Do you understand? If you fall for their temptations you invite contradiction. Chaos. The clay pot could shatter and you could die... or far worse.

EVELYN

What is worse than death?

ALPHA WAYMOND

We should keep moving until reinforcements arrive.

EVELYN

No, I don't have time for your clay pots. Explain it to me now.

She puts her foot down. Alpha Waymond sighs.

ALPHA WAYMOND

You're right. In the Alphaverse, we began training many young minds to verse jump.

(MORE)

# ALPHA WAYMOND (CONT'D)

Imagine what we could have done with the collective knowledge of all these worlds. Cured diseases, ended war. But there was one who was far and above the most gifted. Our little explorer... <sigh>. You saw her potential, so you pushed her... beyond her limit.

This strikes a nerve with Evelyn.

52A ALPHAYER: INT. BUNKER (FLASHBACK)

We see Joy hooked up to various devices. She verse jumps over and over again as Evelyn looks on.

# ALPHA WAYMOND (V.O.)

Though the overloaded mind usually dies, her mind was fractured, shattering the filter that upholds the illusion that we exist in one linear reality.

The machines break and Joy's eyes turn an eerie BLACK.

53 VARIOUS UNIVERSES: JOBU TUPAKI'S WALK

Jobu walks down a deserted dystopian road, dead bodies, smoking cars, a distant burning city.

53-1/2/3 Then with every step, we see her in a different universe: a mother walking down a grocery aisle, an axe murderer stalking her next victim, a celestial goddess walking through a temple.

# ALPHA WAYMOND (V.O.)

Now her mind experiences every world. Every possibility. At the same exact time. Commanding the infinite knowledge and power of the multiverse.

53-4 EXT IRS BUILDING: Jobu stops walking. She's outside. In their universe. Cut back to:

54 INT. IRS - CONFERENCE ROOM

# EVELYN

(mouth full of food)

Joobooby.

# ALPHA WAYMOND

Jobu. Tupaki. Now, she's seen too much. Lost any sense of morality, any belief in objective truth. And no one has been able to stop her... until now.

Alpha Waymond leads Evelyn out. Evelyn hesitates.

# EVELYN

But you said I was the wrong one.

# ALPHA WAYMOND

What you did back there. It changed my mind. You were incredible...

<cedes away>

Evelyn glows. She hears the CHEERING crowd from the premiere again.

Alpha Waymond exits the room as he explains, but as Evelyn follows, she sees CHEERING FANS. She shakes her head but the CHEERING just gets louder. She can't help but be pulled in

55

MOVIE STAR UNIVERSE: INT. MOVIE THEATER

She is back on the red carpet soaking in the limelight.

Then she spots someone in the crowd: Waymond. Everything goes quiet. Waymond looks different, smartly dressed, confident in his stride. Their eyes lock. Time slows. CUE: ROMANTIC MUSIC.

# EVELYN (MOVIE STAR)

Waymond...

We reveal her locket around her neck has an old photo of Waymond. A deep longing fills her soul as she walks off the carpet towards him. She pushes her way through the crowd.

Everyone is staring at them.

# WAYMOND (CEO)

EVELYN (MOVIE STAR) (CONT'D)

你怎麼會…你先…

你怎麼會…不好意思…你先說…

(What are you- Wait you go-)

(What are- I'm sorry, you go)

They both shut up and stare at the floor. They laugh.

# WAYMOND (CEO) (CONT'D)

WAYMOND (CEO) (CONT'D)

我在廣告牌上看到你。可能這聽來很傻…我在想你會記得我嗎？

I saw your face on a billboard and- This is silly... I wondered if you

remembered me...

EVELYN (MOVIE STAR) Of course, 但…你…变得很帅。哇噻，那是真的嗎？

EVELYN (MOVIE STAR) Of course, but... you look so... good... Is that a knock off?

It's definitely real.

EVELYN (MOVIE STAR) (CONT'D) EVELYN (MOVIE STAR) (CONT'D) 你不是應該在美國？不是很窮嗎？ But... you should be in America. And very poor. How...?

WAYMOND (CEO) (laughs) 還好啦！我比較幸運。

WAYMOND (CEO) (laughs) I guess I got lucky.

This dissonance hurts her brain. A hand grabs Evelyn's shoulder. It's her MASTER. Evelyn waves him away.

MASTER  
全神貫注，不能再分心了。 No time for distractions.

He grabs her wrist to tug her away. Evelyn resists but realizes her hands are now in handcuffs.

ALPHA WAYMOND (O.S.) Evelyn! Come back!

56 INT. IRS 9TH FLOOR - ORIGINAL UNIVERSE

Evelyn is being detained by a police officer while a small team of Police struggle with Alpha Waymond. They are now in a hallway by a freight elevator.

ALPHA WAYMOND  
Evelyn! Jump to another combat universe. Try peeing yourself, it's always a good jumping pad

WHAM. An officer knocks Alpha out cold with their gun.

EVELYN What?Waymond!Come back!

No response. Evelyn doesn't know what to do. She spots another officer escorting a shell-shocked Deirdre towards the elevator. Deirdre yanks a staple out of her forehead.

DEIRDRE (to Evelyn) What did you do to me?

EVELYN

I didn't do that.

OFFICER #1

Sir, we have movement on the

elevator. Did you request back up?

The elevator number slowly ascends to their floor.

OFFICER #2

Fuck. These new recruits don't know

how to stay put.

(into walkie)

We've detained the assailants. Back

up was not requested. Y'all wasted

a trip. Copy?

The officers all share a laugh. No response on the walkie.

OFFICER #2 (CONT'D)

I said do you copy?

57 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

Alpha Waymond watches the screens in horror.

ALPHA WAYMOND

Run, Evelyn. Come on, run.

58 INT. IRS 10TH FLOOR - ORIGINAL UNIVERSE

The Officers ominously watch the elevator reach their floor.

DING. The doors open. Through pink smoke stands a woman in a Vegas-style Elvis jumpsuit, a cigarette hangs from her mouth, and she is accompanied by a pig on a leash.

It's Joy. No, it's Jobu Tupaki. She exhales more pink smoke.

EVELYN

Joy? Why do you look so stupid?

Jobu wobbles and sways out the elevator door led by her pig.

OFFICER #2

Miss, you can't be up here.

Officer #2 stands in her way. She takes one last drag from her cigarette and then puts it out right on his badge.

# JOBU

Is it that I can't be here, or that I'm not allowed to be here?

# EVELYN

# EVELYN

# 禮貌一點！

You show them some respect!

Jobu places her foot on the Officer's shoe and taps it.

# JOBU

See I can physically be here. So you meant to say you're not allowing me to be here.

Jobu Tupaki laughs in his face and begins to walk by him.

# OFFICER #2

Alright, hands behind your head.

Officer #2 pulls out a pair of handcuffs.

# JOBU

You're going to make me walk through you?

# OFFICER #2

No ma'am, I can't let you do that.

# JOBU

Again, with the "can't". I don't think you understand the meaning of that word.

She reaches out and touches him on the nose. Rumble - He tries to speak but confetti pours out. POP! He explodes into confetti. Everyone screams. Jobu walks towards Evelyn.

# JOBU (CONT'D)

See, I can walk through you.

Evelyn's brain is broken. What did her daughter just do?

# OFFICER #1

Officer down! Take her out!

A gun is pushed against the back of Jobu's head. Jobu turns, shoves the gun in her mouth, and takes a deep drag like a bong while he uselessly pulls the trigger.

She spins him, RUMBLE POP! They are now dressed as Salsa dancers and as they dance, the others OPEN FIRE, and he becomes her human shield, riddled with bullets, blood splattering the walls. She tosses him into the other officers.

Handcuffed Evelyn awkwardly grabs Waymond's unconscious body and drags him away. Deirdre hides behind a corner.

Jobu jumps on another officer RUMBLE POP! They are now luchador fighters. He is midair, upside down. She pile drives his neck.

Jobu tumbles until she is face-to-face with Evelyn. She winks at her. Then BANG. Jobu's chest explodes with blood, splattering Evelyn's face. We reveal a guard behind her holding a smoking gun. Jobu stumbles forward clutching her chest. Evelyn is horrified.

JOBU Don't... worry... Evelyn...

She reveals she is holding a bottle of ketchup. No wound.

JOBU(CONT'D) ...it's organic.

The officer drops his gun and charges Jobu with his baton, she catches it and it becomes a veiny dildo. Jobu violently beats the officer with the dildo, finally knocking him unconscious.

EVELYN (CONT) Oh my god, it's you...

SLOW MOTION: Jobu looks up at her mother still holding the undulating dildo. Evelyn is horrified.

EVELYN (CONT) (CONT'D) You're Juju Toobootie.

DEIRDRE (BAGEL) (O.S.) Its Jobu Tupaki, and consider yourself blessed to be in her presence!

Bagel Deirdre steps out and bows her head before Jobu who transformed her bloody clothes into clean golfing attire.

EVELYN The "Great Evil" that Waymond was talking about... is in my Joy?

# DEIRDRE (BAGEL)

Do not mistake what you see from your limited perspective as "evil". Decree 241, rule 6: There is no good, there is no evil. There is only "goovil".

# EVELYN

Shut up! Her name is Joy. A beautiful name. This, this is just make up sounds.

# JOBU

That's exactly right, Evelyn.

# EVELYN

Stop calling me that! I am your mother!

59 ALPHAYERSE: INT. LAUNDRY RV CONTROL ROOM

Alpha Waymond is trying to wake up in the IRS building.

# ALPHA WAYMOND

Don't engage. She can't be reasoned with.

60 INT. IRS 9TH FLOOR - ORIGINAL UNIVERSE

Evelyn's mind is going a mile a minute. She gasps.

# EVELYN

It's you. It's been you this whole time. You are the reason my daughter doesn't call anymore. Why she dropped out of college, gets tattoos. You are why she thinks she's a gay.

# JOBU

Hah! You're still hung up on the fact that I like girls in this world? The universe is so much bigger than you realize, Evelyn.

我都乾了(I've fucked everything.)

# EVELYN

Watch your language!

She struggles to get away, but Jobu continues to stalk her.

# JOBU

You've fucked everything too. Girls. Dogs. Cars...

She pulls a picture frame off the wall and with a RUMBLE POP POP POP, we see the photo in the frame change to photos of Evelyn lovingly with Deirdre, a dog, a car.

# EVELYN

Never.

# DEIRDRE (BAGEL)

Decree 3707, rule 34: If you can imagine it, you have fucked it.

# JOBU

In this very moment, there's a world where you and your auditor over here are deeply in love.

The pictures flicker and show Deirdre and Evelyn on vacation, walking their cat on a leash, etc. Evelyn looks from the photos to Deirdre who nods menacingly.

# JOBU (CONT'D)

You miss her when she is gone. You love the way she smells. Her obsession with Crossfit and bird watching...

# EVELYN

Impossible.

# DEIRDRE (BAGEL)

Do not be so closed minded that you blind yourself from the truth!

# EVELYN

I'm not close minded! I just don't like you. Nobody likes you Deirdre!

# DEIRDRE (BAGEL)

Your insults mean nothing in the grand scheme of the cosmo-ho-ho...

Deirdre begins to cry. She beats her chest and slaps herself.

# DEIRDRE (BAGEL) (CONT'D)

C'mon Deirdre! C'mon! Keep it together. We worked on this.

Deirdre runs off crying down the hallway. Jobu sighs.

# JOBU

Look, I'll be out of this universe in a jiffy. I'm just popping in, to check on something.

Jobu reaches her hand towards Evelyn who defensively strikes a fighting pose. The DEEP RUMBLE begins to rise.

# EVELYN

Don't make me fight you. I am really really good.

Evelyn closes her eyes to concentrate. But she can't.

60-1 FLASH: MOVIE STAR UNIVERSE: Evelyn is being ushered through, adoring fans, flashing photographers, a dancing popcorn and hot dog on a poster.  
60-2 FLASH: TAXES UNIVERSE: Evelyn is trying to work on her taxes. She sees a picture on the wall of Joy as a child next to a child's drawing of a man with wiggly worm fingers.  
60-3 ALPHAVERSE: INT. LAUNDRY RV - On screen images FLASH: a clenched fist, hot dogs, Joy's portrait, Joy's childhood drawing, back to a fist, etc.

# ALPHA WAYMOND

No, Evelyn, you're not locked in!

60 BACK IN THE IRS: Evelyn backs up against a wall.

Jobu looks down to notice Evelyn has peed her pants. Her bluetooth FLICKERS YELLOW AND GREEN. Jobu nods impressed.

Evelyn presses the bluetooth. Her head cocks back.

Both her hands go limp as if they have been pumped full of anesthesia. Her handcuffs slide off to the floor.

She tries to punch Jobu, but her floppy fingers just bounce off her face.

61 ALPHAYERSE: INT. LAUNDRY RV CONTROL ROOM

# ALPHA WAYMOND

Where did she jump?!

# ALPHA OFFICER #1

She's off the damn map.

62 HOTDOG UNIVERSE: INT. LAUNDROMAT

Evelyn is back in her laundromat, but Deirdre is standing next to her watching TV instead of Waymond.

On TV, they are watching the same old musical from this morning. Only the lovers both have hot dogs for fingers. They begin to circle each other, slapping their thighs in a bizarre love ritual as the music swells.

Deirdre sighs and wipes a tear with a hot dog finger.

DEIRDRE Oh honey, isn't it beautiful?

Evelyn looks down at her own hot dog hands and shrieks.

63 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

ALPHA OFFICER #1  
She appears to be in a universe  
where everyone has hot dogs instead  
of fingers.

ALPHA OFFICER #2 An evolutionary branch in the anatomy of the human race?

64 EXT. ROCKY DESERT (ALA 2001 A SPACE ODYSSEY)

A monkey with hot dog fingers murders a normal fingered monkey with her hot dogs. Other monkeys whoop and scream.

OFFICER #2 (VO) A jump like that would fry most people.

ALPHA WAYMOND (VO) Like I said, she's not most people.

The normal fingered monkey's outstretched hand falls limp (but still has bones).

65 INT. IRS 9TH FLOOR HALLWAY

Evelyn stumbles against a door. She tries to grab the handle but her fingers are useless and she crumbles onto the floor.

EVEI This is crazy.

JOBU You're starting to get it.

66 HOTDOG UNIVERSE: INT. LAUNDROMAT

On the TV, the hot dog couple move into the final phase of their love ritual. They place their hot dog fingers in each other's mouths. A red and yellow substance that looks like ketchup and mustard oozes down their lips. It's beautiful.

67 INT. IRS 9TH FLOOR HALLWAY - ORIGINAL UNIVERSE

EVELYN It's wrong. SO WRONG!

JOBU No wrong, no right. Only "wrong". No Coke, no Pepsi. Only "Pokesi". It all just tastes the same. Here, let me help you open your mind.

With her hands together, Jobu opens her fingers like Spock.

JOBU (CONT'D) Slide your fingers between mine.

She reaches her hands out to Evelyn who is too dazed to resist. We hear the familiar ominous RUMBLE.

JOBU (CONT'D) Open up. Take a peek.

Evelyn grimaces as she realizes this is the infamous playground Hand Vagina trick in which young boys approximate the appearance of a vagina.

Evelyn reluctantly opens up her hands and peaks inside. The RUMBLE is a deafening storm. Her eyes go wide-

67-1 Between her fingers: a large white room with a dark swirling mass like a churning black hole that resembles a bagel.

EVELYN (mesmerized) What is it?

JOBU A bagel. I got bored one day. So I put EVERYTHING on a bagel. All of my hopes and dreams. My old report cards. Every breed of dog. Every last personal ad on craigslist. (MORE)

# JOBU (CONT'D)

Sesame. Poppy seed. Salt. And it collapsed in on itself. When you really put everything on a bagel, it becomes this. The truth.

A strange peace comes over Evelyn's face.

# EVELYN

What's the truth?

# JOBU

Nothing matters.

# EVELYN

No. Joy you don't believe that.

# JOBU

It feels nice doesn't it? If nothing matters, then all of the pain and guilt that you have for making nothing of your life, it goes away too. Sucked into a bagel.

Evelyn tries to resist, but her eyes begin to turn BLACK.

SLAM! A blur of skin and metal sends Jobu Tupaki smashing through the wall.

The RUMBLING stops and Evelyn snaps out of the spell.

Evelyn looks up to see Gong Gong skid to a stop in a motorized wheelchair tricked out with equipment from around the office. It's Alpha Gong Gong!

# EVELYN

爸！？(Father?!)

# ALPHA GONG GONG

I am not your father. At least not the one you know. I am-

# EVELYN

God, you too?

Alpha Gong Gong removes his shoe and uses it like smelling salts to wake up Waymond

# ALPHA WAYMOND

What are you doing here sir?

# ALPHA GONG GONG

We need to go.

All three hurry off down the hallway.

Jobu Tupaki stumbles out from the smashed hole in the wall, unfazed, if not a little annoyed. She lifts her head to tune into an unheard frequency. Click. She leaves.

INT . IRS 9TH FLOOR EXECUTIVE OFFICE - MOMENTS LATER

Gong Gong slams the door shut.

# ALPHA WAYMOND

Sir, I have this under control.

Evelyn tries to focus on their conversation, but her mind is all over the place. She looks drunk.

Alpha Gong Gong zips around the room barricading the door with furniture. They speak in hushed whispers.

# ALPHA GONG GONG

She was nowhere near ready. Once again, you deliberately disobey me, and cause another mind to be compromised.

(gravely)

You know what we have to do now.

# ALPHA WAYMOND

Sir! No. Please. She's unlike anything we've seen. She could finally stop Jobu Tupaki.

# EVELYN

You mean the monster that is in my daughter?! Why didn't you tell me that from the beginning?

# ALPHA WAYMOND

I was waiting for the right time-

# EVELYN

She's using my beautiful Joy to kill people.

# ALPHA WAYMOND

That's why you will stop her.

Alpha Gong Gong scoffs at this idea.

# EVELYN

But how? Did you see her dance that man to death?! There is no way I'm the Evelyn you are looking for.

ALPHA WAYMOND

No. I see it so clearly.

EVELYN

See what? I'm not good at anything.

ALPHA WAYMOND

Exactly.

(off of their looks)

I've seen thousands of Evelyns, but never a Evelyn like you. You have so many goals you never finished. Dreams you never followed. You are living your worst you.

EVELYN

I can't be the worst... what about the hot dog one?

ALPHA WAYMOND

No. Everyone here agrees. This one's worse. Can't you see? Every failure here, branched off into a success for another Evelyn in another life. Most people only have a few significant alternate life paths so close to them. But you, here... you're capable of anything because you're so bad at everything.

Evelyn isn't sure if she's flattered or insulted. She grabs Alpha Waymond to steady herself.

ALPHA GONG GONG

What good is all of that power if her mind is already succumbing to the chaos.

There is a KNOCK on the door. They go quiet.

JOY (O.S.)

Hello? Hello...

They all freeze up.

JOY (O.S.) (CONT'D)

Mom? Dad? What's going on?

ALPHA GONG GONG

This is just one of her tricks.

Evelyn backs away from the door. Alpha Waymond confers with his team via bluetooth.

# ALPHA WAYMOND

Sir. Our readings indicate it's not Jobu. But if she's not here, then where...

# ALPHA GONG GONG

Oh no...

70 ALPHAVERSE: INT. LAUNDRY RV CONTROL ROOM

In the middle of the road is a lone figure- JOBU!. Alpha Gong Gong video conference's in from another base.

# ALPHA GONG GONG

Do not engage! Run! Run!

Alpha Waymond can tell he won't have a choice. Alarms flash as the RV violently swerves.

71 INT. IRS 9TH FLOOR EXECUTIVE OFFICE - MOMENTS LATER

Alpha Waymond turns to Alpha Gong Gong.

# ALPHA WAYMOND

Watch these two here while I deal with Jobu.

# ALPHA GONG GONG

(scoffs)

I'm not risking the safety of the Alphaverse for this.

Alpha Gong Gong drops his head and begins snoring.

# ALPHA WAYMOND

(to Evelyn)

Get us as far away from Joy as you can. I'll be back. I promise.

He hangs his head and snaps back as normal Waymond.

# JOY (O.S.)

Helloooooo? I can hear you guys in there... Where are we?

Waymond pushes the furniture away and opens the door. Joy steps in scrolling through her missed calls and messages.

# WAYMOND

Joy? Why are you here?

# JOY

I have no fucking clue!

# WAYMOND

Gentle language! I'm sure there is a very good explanation for all of this...Wow. Very cool clothes.

Evelyn shoves Joy into an office chair and begins frantically taping her arms with packing tape.

# JOY

What the fuck, mom!

# WAYMOND

Evelyn，你在干什么

# WAYMOND

Evelyn stop that!

# EVELYN

這是為了我們的安全。

我們女兒的腦子被Joybooby Tobacky綁架了。Alpha you 和Alpha 公公want me to fight her。But she is too powerful…

# EVELYN

It's for our protection. Our daughter's mind has been taken over by Joybooby Tobacky. Possessed. Alpha you and Alpha Gong Gong want me to fight her, but she is too powerful...

Waymond puts his hands on her shoulders to calm her.

# WAYMOND

妳.在.說.什.麽？

# WAYMOND

What. Are. You. Talking About?

# JOY

Are we, like, all having a stroke?

# EVELYN

你不記得了，因為你的身體也在另外的 universe 的 control.

# EVELYN

You can't remember anything because your bodies were under the control of other universes.

# JOY

Oh that explains it.

# EVELYN

You were like... puppets. And you could do things you normally can't do. You were like, what's that movie... Raccaccoonie?

# WAYMOND

What?

# EVELYN

You know... Raccaccoonie, the cartoon. We watched it for your birthday in middle school. With the cook, he makes bad food, but then the Raccoon sits on his head, and controls him, and then, he makes good food-

In spite of everything that is happening, Joy laughs.

# JOY

She means Ratatouille.

# WAYMOND

Ratatouille! Very good movie.

# EVELYN

No, it's Raccaccoonie. Like Raccoon. Ratatouille's not a word.

# WAYMOND

(through laughter)

So there is a Raccoon Me and a Raccoon Joy? And they are controlling us...?

# EVELYN

From other universes.

Joy and Waymond cannot stop laughing. Evelyn, suddenly self-aware, drops the tape. She can't help but laugh a little too.

GONG GONG (O.S. IN CANTONESE)

# 艺霖 (Evelyn)

Evelyn turns to see her father is awake. She goes to him.

Joy's phone begins to RING. It's Becky. Despite the tape, she is able to answer the phone while Waymond tries to free her.

# ALPHA GONG GONG

(whispered)

Quickly. While she is distracted.

Gong Gong covertly places a box cutter knife in Evelyn's hand. It's Alpha Gong Gong.

Evelyn mouths "what?" and pushes the knife back.

ALPHA GONG GONG (CONT'D)

This is just protocol. Giving her one less universe to access.

Evelyn shakes her head "no".

ALPHA GONG GONG (CONT'D)

How can you defeat her in every universe, if you can't even kill her in one?

EVELYN

She's your own granddaughter.

He places the knife in her hand. Evelyn feels the weight of the weapon.

ALPHA GONG GONG

The sacrifices necessary to win this war... I know all too well.

71-1 FLASHBACK: Jobu killing all of the policemen. We hear Jobu's voice.

JOBU (V.O.)

Nothing matters...

Evelyn grips the knife tighter. She turns and walks slowly towards her oblivious daughter who is still on the phone. Waymond laughs as he struggles to get the tape off of Joy.

BECKY (PHONE)

Wait... why are you taped up??

JOY

It's a long story. Involving Raccoons, apparently.

Gong Gong watches as Evelyn gets closer.

JOY (CONT'D)

Mom?

Evelyn raises the knife. Gong Gong nods in anticipation.

Evelyn cuts the tape, releasing Joy.

WAYMOND

Hey, you take the fun out of everything. I almost had it.

Evelyn looks at Joy, knowing she made the right decision.

They hear a CLICK from behind.

They turn to see Gong Gong has a gun in his hands. Evelyn immediately stands up to block her daughter.

ALPHA GONG GONG

You are already under her spell.

JOY

Gong Gong speaks English?!

WAYMOND

Everyone stay calm! I think it's

time for a family discussion!

EVELYN

I can't let you kill her.

JOY

Shit! Gong Gong's lost it!

Evelyn begins to breathe heavily. Her head is reeling as she experiences LEAKS from the other universes.

ALPHA GONG GONG

Can't you see what is happening to

your mind? In my universe. You

pushed your daughter. And you broke

her. You created Jobu Tupaki. I

must stop you now. It's only a

matter of time before...

(aims the gun at her head)

You become just like her.

Glancing back at Joy, Evelyn is overwhelmed with guilt.

Then - EUREKA, an idea sparks in her head.

EVELYN

(To herself)

Just like her...

Evelyn looks Alpha Gong Gong squarely in the eyes and begins dancing. To no music. It's awkward.

ALPHA GONG GONG

What are you doing?

Her bluetooth devices BLINK GREEN.

ALPHA GONG GONG (CONT'D)

No! You don't know where you'll

jump. You could end up anywhere.

She presses the button. BAM! She is an incredible dancer.

ALPHA GONG GONG (CONT'D)

That's enough.

Evelyn pulls hand sanitizer from Waymond's pack, and splashes it in her eyes. It STINGS. GREEN LIGHT.

# EVELYN

(with waymond's voice)

I know you don't understand. But

this is something I have to do!

Alpha Gong Gong wheels up to Evelyn and places the gun directly to her head. His eyes begin to water.

# ALPHA GONG GONG

Do not make me do this Evelyn.

Evelyn pulls a wad of 20 dollar bills out and rips them all in half. GREEN. She can barely stand.

Evelyn opens her mouth and performs convincing BIRD CALLS.

# EVELYN

(subtitled bird tweets)

Maybe if I become like her, I can

save my daughter...

We can hear the SOUNDs of the other universes in her head. ON WAYMOND'S BUZZING PHONE: The map blinks RED "CRITICAL".

Alpha Gong Gong's face is now streaked with tears. Snot runs out his nose.

# ALPHA GONG GONG

I cannot lose another loved one to

the darkness.

Evelyn looks back at Joy.

# EVELYN

You won't.

She swipes up a piece of snot from Alpha Gong Gong's face and brings it towards her lips. Everyone gags. GREEN.

Evelyn falls down against the desk behind her. She looks around confused.

# ALPHA GONG GONG

Where'd she jump?

72 JANITOR UNIVERSE: INT. IRS BUILDING - EXECUTIVE OFFICE

In the same spot, Evelyn wears a custodian's outfit and holds a duster.

A button underneath the desk blinks red. A secret bookshelf door swings open revealing a panic room. The District Manager comes out - sweaty, & red followed by his DOMINATRIX.

# DISTRICT MANAGER

Clean up in there. It's gunna need extra work today.

He throws Evelyn a twenty dollar bill with a shushing gesture and walks out.

Janitor Evelyn pops open the cap of a bottle of fancy whiskey and hocks a loogie into it. She smiles.

73 INT. IRS BUILDING - EXECUTIVE OFFICE

# EVELYN

(smiling)

Sorry, baba.

She pushes the button under the desk and the secret door opens. Alpha Gong Gong breaks eye contact.

# EVELYN (CONT'D)

(to Waymond and Joy)

Get in!

Before Alpha Gong Gong can pull the trigger, Evelyn picks up the whiskey bottle and smashes it into Alpha Gong Gong's gun, sending it flying out of his hand.

Alpha Gong Gong wipes the whiskey from his face, the door clicks shut. The family are locked in the panic room.

# WAYMOND (O.S.)

JOY (O.S.)

Oh. Wow. What is this stuff?

Oh. My. God.

74 ALPHAVERSE: INT. ALPHAVERSE HQ

Alpha Gong Gong disengages from his connection.

# ALPHA GONG GONG

Send every Jumper with a

counterpart in the area. Now!

We see Alpha Jumpers connecting to their jumping stations. Amongst them, Debbie the Dog Mom's counterpart closes her eyes-

75 EXT. IRS BUILDING

Debbie the Dog Mom is outside walking her dog. Her head goes limp. She turns and makes her way through the crowd of evacuees. We see a handful of others walking towards the building: auditors, security guards, random civilians.

76 INT. IRS - PANIC ROOM

The family is in a small dimly lit panic room filled with a handful of kinky toys, a limp bag of cocaine, some wrinkly porno mags, and an Xbox.

# JOY

What the hell is going on with Gong Gong? Is this like a tax thing?

Waymond tries to get Evelyn to drink water. She's a mess.

# EVELYN

My Joy. I know you have feelings. Feelings that make you so sad. That make you just want to give up. That is not your fault.

Joy leans in. Something is ringing true.

# EVELYN (CONT'D)

It's her. She has your soul in her hands. I think the only way I can defeat her... is to become like her.

WAYMOND

WAYMOND

我還是有點亂。

I'm still a little bit lost.

# ALPHA JUMPER (O.S.)

Evelyn Wang, of the 4,659th Thetaverse! You've been summoned by the 1st Order of the Alphaverse.

They all look at one another.

77 INT. IRS 9TH FLOOR EXECUTIVE OFFICE - THAT MOMENT

A ragtag group of Alpha Jumpers stand in the room, ready to fight. They put on bluetooth jumping devices. At the front is Alpha Gong Gong.

# ALPHA JUMPER

You are in direct violation of the Verse Jumping Tribunal's Code of Ethics. By endangering your mind, you've endangered us all. Surrender and hand over your daughter, or we will be forced to remove you from this universe.

78 INT. IRS - PANIC ROOM

Waymond looks over at Evelyn who is staring up at the ceiling, not fully here. He shakes her.

WAYMOND

WAYMOND

回來啊、回來！

Come back. Come back.

78-1/2/3/Me cut to a POV of her hands: Holding someone's hand, touching a hot stove, grabbing popcorn at the premiere, wiggling cause they're hot dogs etc.

EVELYN

我在这…可是 …I can still feel everything else … 越来越多.

好像 a million nerve endings, growing further and further.

EVELYN

I'm here... but... I can still feel everything else... more and more... like a million nerve endings, growing further and further

79 INT. IRS 9TH FLOOR EXECUTIVE OFFICE

Many Alpha Jumpers now wear gas masks. One pulls the pin from a tear gas can and tosses it into the ceiling vents. Alpha Gong Gong nods approvingly and rolls out of the room.

80 INT. IRS - PANIC ROOM

Gas begins seeping in through the vents.

WAYMOND

親愛的，我不知道妳怎麼了，

不過 I think you're pushing things too far.

WAYMOND

Sweetheart, I don't know what you're doing, but I think you're pushing things too far.

She grabs the phone from Waymond: a warning is flashing. She zooms out to reveal so many more untouched universes.

As gas filters in all around them, Evelyn stumbles to her feet and grabs a motorized feather toy. It begins vibrating.

# EVELYN

Or... not far enough.

Joy cringes as her mom sticks the feather into her nose. Her bluetooth device flashes GREEN.

81 INT. IRS 9TH FLOOR EXECUTIVE OFFICE

All of the gas mask Alpha Jumpers also begin doing random, stupid things: one guy rips a chunk of hair out, an older lady sits on a photo copier with her bare ass, someone is singing "Ave Maria". It's an orgy of stupid.

GREEN devices flash across the room.

82 INT. IRS SECRET SEX Closet

Evelyn presses the button and she downloads divergent memories from OPERA UNIVERSE:

82-1 - Evelyn as a child, runs with sticks, she trips.

82-2 - Her Father sings to her as a child now with bandages over her eyes.

82-3 - Evelyn stands onstage alone wearing sunglasses in front of a huge audience. A single note from the string section-

83 [SPLIT SCREEN] INT. IRS EXECUTIVE OFFICE / OPERA HOUSE

In unison both Evelyns INHALE a large lungful of oxygen.

83-1 As the blind Opera singer sings her sustained note, Evelyn unlocks and swings open the closet door in SLOW MOTION. Gas billows.

With her eyes closed and her breath held, she dodges several blows from enemy Jumpers. She grabs hold of two of the Alpha Jumpers' gas masks and rips them off. They gasp for air.

She throws the gas masks into the panic room for her family.

Someone kicks her from behind.

Opera Evelyn's voice falters and cracks. She disconnects as she hits the wall. But the epic opera music continues:

84 INT. IRS 9TH FLOOR EXECUTIVE OFFICE

She picks up a frog shaped paperweight and tries to swallow it whole - GREEN - BAM!

84-1 SIGN SPINNER UNIVERSE: We see divergent memories flash:

Evelyn, a gymnast, falls off the high bars, CRACK!

84-2 - Wearing an ankle cast she watches someone else win at the Olympics on TV.

84-3 - Evelyn in a uniform spins a sign that says "PIZZA PIZZA". She's really good. But it's also kind of sad. Someone stops to take a selfie with her.

84 BACK IN THE IRS: A SWAT Officer charges with a riot shield.

Evelyn deftly dodges him, steals the shield, and swirls it like a magnificent sign spinner, blocking bullets and miscellaneous sharp objects. The gas blows away from her, sending paperwork flying through the air.

She slams the shield to the left BAM! To the right BAM! knocking more foes over and smashing their bluetooth devices.

Meanwhile Waymond & Joy emerge from the panic room, pull off the gas masks and watch Evelyn do the impossible.

Evelyn smashes the sign into one final jumper, the shield shatters from the impact.

JOY

Holy. Shit.

WAYMOND

No Evelyn! Is he dead??

EVELYN

Come on!

85 INT. IRS 9TH FLOOR ATRIUM

The family hurries through the doors keeping their head down as they head past a break room area amongst the cubicles.

Something SHRIEKS then slams into Evelyn knocking her into an adjacent break area. A leash yanks the creature back, and Debbie catches her dog just as they strike a menacing pose.

Debbie begins swinging her weapon like a ball and chain.

Evelyn swings open the fridge looking for a jumping pad. She grabs a 2 liter of orange soda and leaps out of the way just as the French bulldog slams into the door. She traps the dog inside.

Evelyn runs for the exit, sticks the bottle in her mouth, squeezes it violently chugging all the soda in 2 seconds.

The Frenchie flies at her face. GREEN! BAM!

85-1 FLASH: CHEF UNIVERSE: INT. BENIHANA'S RESTAURANT - Evelyn is an Hibachi chef with incredible spatula skills.

85 BACK IN THE IRS: She bends backwards, grabs a spatula and a cake knife off the floor, and expertly spins them, slicing the leash.

The dog flies off into the cubicles.

Debbie is furious. Evelyn grabs an egg timer and spins it on the spatula for a moment. Then flicks it violently into Debbie's forehead knocking her unconscious!

Evelyn rejoins her family but she suddenly has a headache - a LEAK from the chef universe -

85-2 CHEF UNIVERSE: INT. HIBACHI RESTAURANT - Evelyn accidentally drops her spinning egg onto a customer's lap. Her MANAGER pulls her aside and whispers in her ear.

MANAGER (O.S.)  
Are you kidding me? Again? If you don't step up, I'm giving some of your shifts to Chad.

Evelyn looks over to see CHAD - a young, handsome chef who has a captive audience. Chad winks at Evelyn who glares back. Evelyn hears a loud ominous DRUM BEAT.

85 BACK IN THE IRS BUILDING: Evelyn turns to see an Alpha I.T. Guy drumming with two pipes so hard it's denting and splintering everything he hits. He attacks with a furious fast tempo. Evelyn fights with her spatulas but they break. She throws a monitor at him, then battles him with a keyboard, but he drums each item into bits.

She manages to hit his earpiece right as he does the same to her. SMACK, they both disconnect. They're powerless.

Evelyn looks into an adjacent cubicle and spots an Auditor of the Month trophy. For the first time we realize how much it looks like a butt plug.

ZIP. The I.T. Guy has undone his pants. He pulls aside his underwear and leaps for the trophy, he's going to use the butt plug trophy as a jumping pad!

Evelyn kicks away the trophy just in time. They fight over the trophy, grappling each other onto the ground as the trophy tumbles across the floor.

FOOTSTEPES. A SCREAM. An Alpha Security Guard comes flying over both their heads with no pants, hands on his ankles. His butt lands on the trophy. Oh No. His earpiece Clicks green.

Evelyn has to think fast, she blows on her I.T. Guy's nose making an involuntary trumpet sound, GREEN! She stands up to face the Alpha Security Guard.

He attacks with a furious series of Shaolin style moves. She battles him until she hears another scream. She turns and the I.T. Guy now has an even bigger trophy protruding from his butt, Auditor of the YEAR!

They furiously attack. She cannot keep up. But she manages to pull out their butt props and violently knocks them both unconscious.

Evelyn breathes a sigh of relief.

Waymond makes a grossed out face. She self consciously throws the props to the floor. Ew.

85-3/4 FLASH: MOVIE STAR UNIVERSE: the movie premiere audience applauds. Evelyn sees Alpha Gong Gong on screen. What?

BACK IN THE IRS: A wheel chair slams into Evelyn. Alpha Gong Gong revs across the floor then pins her against a column with the pegs of his chair, her arms and hands are trapped and she can't move anything except her pinkies.

He holds a grenade. He pulls the pin. He is going to kill himself and take her down with him. Evelyn helplessly squirms her pinkies.

The wounded Alpha Jumpers return to watch their leader suicide bomb the threat. Waymond and Joy watch from the doorway, horrified.

ALPHA GONG GONG

I am sorry, Evelyn.

Evelyn's bluetooth turns GREEN. Alpha Gong Gong looks down to see Evelyn is caressing his leg with her foot.

85-5 FLASHES: PINKY UNIVERSE: EXT. FOREST - In training, Evelyn does nothing but pinky push-ups everyday of her life. Her pinkies look like they are jacked on steroids.

85

Evelyn's pinkies clamp down on the wheelchair pegs, breaking them. Using her strong pinkies: Flick! Flick! Flick! Gong Gong and the chair go flying across the floor.

The active grenade tumbles into some cubicles. The Alpha Jumpers circle her. The grenade explodes off camera. Evelyn strikes an intimidating pinky pose as the debris and smoke curl through the air.

They attack, but Pinky Evelyn destroys them one by one. She flicks one guy's baseball bat into splinters. Then flicks them across the room, or into the air. They're all neutralized.

Waymond and Joy run over.

# JOY

Oh shit, is Gong Gong like dead?

Gong Gong is snoring. Evelyn lets out a sigh of relief.

Suddenly aware of how exhausted her mind and body are, she falls back into Waymond's arms.

# EVELYN

It's going to be so hard... to explain any of this to you.

# ALPHA WAYMOND

No need to explain, I have been watching you.

# EVELYN

You're back. Did you see how good I am? I'm going to do it, I'm going to defeat Jobu Tupaki.

# ALPHA WAYMOND

You got her name right. Evelyn, what you're doing is crazy. Reckless. Your stupid plan to somehow save your daughter has managed to piss off everyone in the multiverse... But it just might work.

He coughs in pain and caresses her face.

# EVELYN

Alpha Waymond, Are you okay?

# ALPHA WAYMOND

Don't worry, I'm just a burner.  
Waymond, used for communication.

(MORE)

# ALPHA WAYMOND (CONT'D)

(laughs to himself)

I only wish I could be there to see you finish this.

86 ALPHAYERSE: INT. LAUNDRY RV CONTROL ROOM

Jobu steps into the flipped RV where Waymond is all alone connected to his helmet. All the equipment begins to shut down, blue screens of death, smoke curling.

# ALPHA WAYMOND

Do what you will. Your time is now limited.

Jobu puts a finger to his lips... RUMBLE...

87 INT. IRS 9TH FLOOR ATRIUM

A calmness falls over Alpha Waymond.

# ALPHA WAYMOND

Be careful out there Evelyn. Do not let the chaos destroy your beliefs.

They are all you have.

(Shenods.)

I'm grateful that chance was kind enough to give us these last few moments together.

He goes in to kiss her. Evelyn's body tenses up.

As they're about to kiss, his lips quiver, his breath trembles, and his eyes roll back. His head goes limp.

# EVELYN

Alpha Waymond?

She holds him tight. Waymond lifts his head in a daze.

# WAYMOND

What happened? Was I Raccoon Waymond again?

# EVELYN

Raccoon Waymond... is dead.

Evelyn pulls away.

Jobu returns enthusiastically applauding. Evelyn stumbles to her feet.

# WAYMOND

So that's... Raccoon Joy? Am I getting it?

# EVELYN

(slurring)

You... you killed him. But I'm going to stop you Jobu. Now that I am reaching my full potential.

Jobu reaches out a hand. The eerie RUMBLING comes back...

# JOBU

You still can't see what's happening.

Evelyn raises her fists defiantly. The Rumble intensifies.

# EVELYN

No, I can see clearly. More clearly than ever before.

Evelyn is now fully cross-eyed.

We see confusing FLASHES of the other universes: CHEF: she's trying cook better than the chef (CHAD) across from her, TAXES: she has a headache, MOVIESTAR: the audience laughs around her, SIGN SPINNER: she prep to catch the spinning midair sign, etc...

Jobu nods, a spark of excitement in her eyes.

Suddenly Evelyn vomits 2 liters of orange soda and a frog paperweight. She collapses to the ground.

Jobu touches her limp body but nothing happens. She pokes her a couple of times. No rumble. No pop. Just dead.

# JOBU

Damnit. So close.

# WAYMOND

What?! No! No!

Jobu crouches down and shuts Evelyn's vacant eyes.

# JOBU

I'll see you again soon, somewhere out there in all that noise.

Waymond holds his dead wife's body, while Jobu stands over them for a moment looking remorseful. The feeling passes.

CUT TO:BLACK

# THE END

VARIOUS UNIVERSES:

87-1 MOVIE STAR UNIVERSE: INT. MOVIE THEATER - Applause. CREDITS begin to roll on screen. We pull out to reveal the audience.

WAYMOND (CEO) (O.S.)

WAYMOND (CEO) (O.S.)

結局挺有趣的，好悲傷。

Interesting ending. Very sad.

Evelyn turns in her seat to see Waymond is next to her. She screams in his face before standing up to pat her body. She's still alive.

EVELYN (MOVIE STAR)

EVELYN (MOVIE STAR)

她在哪？我們的女兒呢？

Where is she? Our daughter.

WAYMOND (CEO)

WAYMOND (CEO)

妳在說什麼？

What are you talking about...?

She runs down the aisle and bursts through the doors-

[As Evelyn goes hunting for Jobu Tupaki, she finds it increasingly more difficult not to get lost in the chaos]

87-2 SIGN SPINNER UNIVERSE: Evelyn looks down. She is now standing in the middle of the road holding her sign. A HORN BLARES, Evelyn looks up just in time to see a car driving straight towards her, she falls backwards  
87-3 OPERA UNIVERSE: Evelyn falls backwards on stage. The audience gasps, the microphone feedback SQUEALS. From backstage Gong Gong picks her up but she pushes past him  
87-4 CHEF UNIVERSE: INT. HIBACHI KITCHEN - Evelyn pushes through the prep kitchen door looking for Jobu.

Instead she sees CHAD, the young Chef has taken off his chef's hat and sitting on his head is a Raccoon pulling his hair. It's RACCACOONIE, the talking, cooking raccoon.

RACCACOONIE & CHAD

Now we're cooking...

While nobody's looking.

Raccaccoonie notices Evelyn and drops the hair, causing Chad's arms to drop.

RACCACOONIE

This isn't what it looks like.

CHAD

You can't tell anyone!

Please, I'm begging you.

# EVELYN

# AHHHHH!

Raccacoonie grabs Chad's hair and puppets him to try and stop Evelyn from leaving. She panics and shuts the door again-

87-5 HOT DOG UNIVERSE: INT. APARTMENT DINING ROOM - Suddenly someone puts a blind fold over her eyes

EVELYN (CONT'D)

Jobu? Stop with the games!

DEIRDRE (HOT DOG)

I thought maybe we could have a

special night.

She struggles to pull off her blindfold. She has hot dog hands. Candles everywhere. Romantic music plays.

Deirdre begins slapping her thighs with her hot dog hands and circles Evelyn. Evelyn recognizes the beginning of the love ritual from the musical on TV.

Evelyn pushes Deirdre over and runs out the door

MOVIE STAR UNIVERSE: EXT BACK ALLEY - Evelyn is guided out by a very concerned Waymond. She closes her eyes to block out the confusion.

She collapses into Waymond's arms. He is using a napkin to pat her head dry.

# EVELYN

My clay pot 漏了... I can think of whatever nonsense I want to and somewhere out there,

在另一個空間真的存在

# EVELYN

My clay pot is leaking... I can

think of whatever nonsense I want to and somewhere out there, it exists. It's real.

# WAYMOND (CEO)

慢慢來，想點開心的。

# WAYMOND (CEO)

Just think happy thoughts.

# EVELYN

Spaghetti. Baby. Noodle boy.

We hear the sound of water BOILING-

87-7 NOODLE UNIVERSE: INT. BOILING POT - Evelyn is a long strand of spaghetti in a pot full of spaghetti. One little macaroni approaches her. He will be voiced by a small child. This is SPAGHETTI BABY NOODLE BOY.

SPAGHETTI BABY NOODLE BOY

Mommy! Mommy! It's Throwing Day! Do

you think they'll pick me? Do you

think I'll stick on the wall?

Today, will I become a man?

Noodle Evelyn looks at her macaroni son in disbelief.

EVELYN (Noodles)

SHUT UP Spaghetti Baby Noodle Boy!

87-8/9/10VARIOUS UNIVERSES: In rapid succession, we cut to several versions of Evelyn, all screaming: sitting in an IRS cubicle, sitting on a bus, tied to a stake above a fire, she is an old leather boot.

EVELYN (CONT'D)

SHUT UP! SHUT UP! SHUT UP!

She closes her eyes tight to block it all out.

87 ACTION UNIVERSE: INT. IRS BUILDING - On Waymond's phone, Evelyn's mental map spreads further and further.

But then, it stops-

88 TAXES UNIVERSE: INT. APARTMENT - DINING ROOM/LIVING ROOM

Evelyn is staring off into the distance. A little sweat rolls down her forehead. She has stabilized.

Waymond has his hand on her shoulder.

WAYMOND

WAYMOND

你沒事吧。又看見你發呆了。

You okay? Caught you staring off into space again.

She looks around to confirm: yes, there on the wall is a picture of Joy as a child.

EVELYN

(to herself)

I did it.

WAYMOND

太棒了！你可以在party

WAYMOND

前把文件送过来。

Good job! You can drop off the paperwork before the

party starts.

Waymond hands her a Tupperware of more cookies with "FOR MS. DEIRDRE" written on it, before heading down to the laundromat carrying plastic cutlery and other supplies.

She stands to go, then stops, suddenly aware of a receipt in her hand. Still suspended between two piles.

She places it in a pile, but it Splits INTO TWO HANDS. A universe where she placed the receipt in each pile. She looks down, quietly amazed.

# TITLE: "PART 2: EVERYWHERE"

BUZZ! BUZZ!

# TAXES UNIVERSE: INT. LAUNDROMAT

Evelyn opens the stairwell door: A small group of Chinese men begin singing in Evelyn's confused face.

MEN'SCHOIR

Gong xi, Gong xi, Gong xi niii ah!

Gong xi, Gong xi, Gong xi niihi!

恭喜，恭喜，恭喜你呀！恭喜，恭喜，恭喜你！

Waymond, carrying a cheap Chinese dragon costume, steps out to greet his men's church choir.

WAYMOND

好、好、好，不要破坏 surprise...

WAYMOND

Okay, okay shhh... don't

spoil the surprise...

He leads his friends away through the mostly decorated laundromat, Evelyn spots someone approaching: It's Joy and Becky.

JOY

Hey mom. So. About this morning-

Evelyn strikes a fighting pose, but almost falls.

EVELYN

Enough with your tricks.

JOY

What's up?

EVELYN

Get out of my daughter. I know

you're in there.

She points at Joy's forehead, but her finger begins to sway back and forth. Joy and Becky share a look.

JOY

Mom are you already drunk?

Joy's head knocks forward and then looks up. Jobu Tupaki has arrived. She watches Evelyn with a focused fascination.

# JOBU

(acting)

Becky. Can you help my dad get

ready for the party?

Becky gives Jobu a curious look as she goes. They're alone.

# JOBU (CONT'D)

You see it all, don't you?

Jobu slowly steps forward forcing Evelyn to step back into:

90 VARIOUS UNIVERSES:

EXT. FOREST: Evelyn and Joy are now in a forest. Evelyn nods. She continues to back up cautiously.

# JOBU

You can-

(RUMBLE POP! She turns a

branch into a katana)

See how everything is just a random

rearrangement of particles, in a

vibrating superposition...

90-1 INT. JAILHOUSE: Jobu's the cop. Evelyn's the escaped inmate. They slowly move their way past jail cells, eyes locked onto one another.

# EVELYN

I don't know what you just said,

but I can do this.

Evelyn grabs a mop from a bucket, swinging it over her head-

90-2 EXT. IRISH FJORD: Viking Evelyn is now wielding an axe against Jobu's katana.

# JOBU

But you see how everything we do...

She plunges her katana into her own stomach. No blood.

Instead, candy spills out-

90-3 EXT. BACKYARD: They are now Jobu-shaped and Evelyn-shaped piñata's hanging from trees being hit by unseen children.

# JOBU (CONT'D)

Just gets washed away in a sea of

every other possibility?

Evelyn Piñata gets hit in the face-

91 TAXES UNIVERSE: INT. APARTMENT - DINING ROOM/LIVING ROOM

Evelyn reacts as if she just got hit in the face, shaking off piñata tissue paper from her shoulders.

JOBU You're everywhere. You're like me.

EVELYN That's right. I'm the one you've been looking for. I'm the one who will defeat you.

JOBU (rolls her eyes) You still think that's what this is about? All right. Hit me.

Evelyn rushes and throws a punch at Jobu but as they make contact THE DEEP RUMBLE builds:

91-1/2/3 FLASH FLASH FLASH: All in the Apartment, they're playing chess, they're on a tandem bike, one is choking the other, then vice versa. Finally we see one universe where Evelyn hits herself and another where she hits Jobu-BAM!

Jobu falls to the ground. Evelyn winces in pain, she looks at her own fist in confusion.

Jobu seems oddly excited.

The door swings open, it's Waymond. Evelyn plays it cool.

WAYMOND

WAYMOND

喔～ Evelyn口你還在這裏幹什麼？

Oh. Evelyn, what are you still doing here?

EVELYN

We're just... practicing for karaoke.

WAYMOND

你不是去送文件了嗎？

WAYMOND (CONT'D)

I thought you were going to drop off our paperwork-

# EVELYN

# EVELYN

別擔心。

(he starts to object) I said, I'll take care of it!

Don't worry about that.

(he starts to object) I said, I'll take care of it!

With one last sad look, Waymond leaves.

Evelyn puts her hands up again to fight, but struggles to keep standing. Jobu plops down on the sofa annoyed.

EVELYN (CONT'D)

If you don't want to fight... then

why... why...

JOBU

Why was I looking for you?

Jobu picks up a potted fern and sucks on it like a bong.

She offers the fern to Evelyn, who refuses but tentatively sits down. Her head is reeling. Jobu's smoke rings come out in the shape of "Q + A".

JOBU (CONT'D)

If you haven't A'ed that Q, then you're not there yet. But you're close.

EVELYN

Close?

JOBU

(jazz hands)

Spread out across infinity! (looks at invisible watch) But we can speed this up.

Before Evelyn can react, they both sink into the sofa-

A91 ALPHAYERSE: INT. LAUNDRY RV CONTROL ROOM

Jobu flops into a chair in the not destroyed Alpha Verse RV, parked on the side of the road. Alpha Waymond is sipping on some tea and doing a crossword.

ALPHA WAYMOND

Oh hi. Jobu? Did you just take over Joy's body again?

JOBU

Yeah, I'm trying to give this Evelyn the whole spiel.

# ALPHA WAYMOND

Do you think this might be the one?

Jobu shrugs as she picks up a pen and fills out a word in Alpha Waymond's crossword. The lid on the urn that holds Evelyn's ashes opens and closes and begins to talk. It's Evelyn.

# EVELYN (URN)

Alpha Waymond? You're alive! How?

Alpha Waymond picks up Evelyn Urn.

# ALPHA WAYMOND

(chuckling)

Oh, did one of the Alphas Waymonds tell you to murder Joy because she's some evil monster? Sorry about that. I used to be quite an extremist myself back in my day.

# EVELYN (URN)

Wake up Alpha Waymond! Remember? She's building a Bagel. To destroy my world- all of the worlds- just like she destroyed the Alphaverse.

Alpha Waymond and Jobu share a knowing look.

# ALPHA WAYMOND

You want to know what destroyed the Alphaverse? You did. Well, we all did. When you discovered verse jumping, suddenly anyone could find whatever version of the truth they wanted in the multiverse. Everyone got more and more opinionated and just kept fighting. So, there is no evil villain really, or nefarious plot or anything. Just a whole lot of confusing hubbub that'd I've decided to stay far away from.

He takes another sip of tea.

# EVELYN (URN)

No... Alpha Waymond...

# ALPHA WAYMOND

Please, call me Waymond, I dropped the "Alpha" a long time ago.

# EVELYN

You brainwashed him like all those other people...

Jobu sighs and walks past a curtain:

92

TEMPLLE UNIVERSE: INT. EMPRESS HALL

Evelyn and Jobu land in a grand white hall. Jobu is dressed like alien royalty. Evelyn is dressed like a peasant.

Evelyn looks around and sees many FOLLOWERS dressed like her, with an ASHY BLACK CIRCLE marked across their forehead.

On the opposite end of the hall is a large white veil with an ominous RUMBLING emanating from within.

# EVELYN

The Bagel.

# FOLLOWERS

Praise be Bagel!

Jobu smiles. Evelyn turns to run the other direction, but Jobu's Followers led by Bagel Deirdre swarm around her, block her exit, and slowly force Evelyn towards the Bagel.

# EVELYN

Please... she has brainwashed you.

# DEIRDRE (BAGEL)

No, Jobu Tupaki has brought peace to this world. Most care too much. Have too much passion. Too much self-righteousness. It clouds the mind. What happens when that gets sucked into The Bagel? No more beliefs. No more war.

# EVELYN

No. Our beliefs are all we have...

# DEIRDRE (BAGEL)

Decree 1, rule 1: there is nothing more dangerous, than someone who believes they are right.

The Followers push Evelyn past the first veil, leaving Deirdre behind, and revealing a much bigger hall.

# EVELYN

Look, please, just give my daughter back to me, and we can leave each other alone forever.

# JOBU

Sorry, no can do.

# EVELYN

Why not?

# JOBU

I am your daughter. Your daughter is me. Every single version of Joy is Jobu Tupaki. Hi.

Jobu hands her a Dr. Seuss style children's book titled "I am Your Daughter. Your Daughter is me."

# EVELYN

No. I saw my daughter.

# JOBU

Tell me, which Evelyn are you really? The chef? The movie star? That hot dog one?

# EVELYN

I am NOT the hot dog one. I am only seeing these things because my mind is broken like an old pot.

# JOBU

It's not broken. It's being opened. The pot was a prison, and you're finally free, like me. I have felt everything your daughter has ever felt. I know the joy and pain of having you as my mother.

# EVELYN

Then you know, I have only done what is right for you- for her.

# JOBU

"Right"? "Right" is a tiny box invented by people who are afraid. And I know what it feels like to be forced in that box.

92-2

FLASHBACK: INT. LAUNDRY RV - Evelyn and Joy are in a car parked on the side of the highway after a tense conversation. Neither of them speak. Until finally Evelyn continues driving.

JOBU (V.O.)

(cruel)

To share a piece of myself that I was so scared to share only for you to say nothing, drive away, go on with your life as if nothing happened.

92-3

FLASHBACK: From earlier today, the moment Becky meet's Gong Gong. We linger on Joy's face.

EVELYN

No... it's not like that. It's Gong Gong. He is from a different generation-

JOBU

You can stop hiding behind him. You should feel relieved, you don't have to choose anymore.

EVELYN

Choose?

JOBU

Between loving me or hating me. You can do both at the same time, now that you're just like me.

They are getting closer to the veil. The Followers pull visors over their eyes, and begin parting the curtains that hide the Bagel. The RUMBLE intensifies.

EVELYN

No... No I'm not like you. You are young, your mind is always changing. I still know who I am.

JOBU

You have no idea what you've done. You're stuck like this forever. Just. Like. me.

EVELYN

No. I am going to go back with my Joy, my family, and live my life. A happy life.

Jobu looks her straight in the eye. There is a trace of sympathy in her expression.

JOBU

Okay. Good luck with that.

Jobu rips open the final Veil. The RUMBLE is deafening. Evelyn glances at the Bagel and is immediately transfixed. Her eyes grow wide.

Through the swirling Bagel Black Hole, we can see guests arriving to the party-

93 VARIOUS UNIVERSES: STARING INTO THE BAGEL

[We glimpse the meaninglessness of all of Evelyn's lives, swirling in the bagel.]

TAXES UNIVERSE: INT. LAUNDROMAT - On autopilot, Evelyn hugs and greets guest after guest, introducing them to Gong Gong with a strained smile on her face.

She sips from a drink as she nods along to a mundane conversation. Rick, their creepy regular, leans into Evelyn and inhales deeply.

Her phone rings: INCOMING CALL FROM DEIRDRE. Oops.

93-1 ACTION UNIVERSE: Evelyn lies dead on the floor. One Alpha Jumper sees the map of Evelyn's mind still has dots spreading further. His eyes go wide  
93-2 HOT DOG UNIVERSE: Evelyn stares at Deirdre who is giving Evelyn one final plea through tears  
93-3 CHEF UNIVERSE: Evelyn accidentally overshoots a shrimp and hits a customer in the face. The customer looks pissed  
93-4 MOVIE STAR UNIVERSE: Waymond is smoking a cigarette with Evelyn reminiscing.

WAYMOND (CEO)

之前你一直在問關於我們的女兒。真的太瘋狂了。但也讓我開始在想，如果…當年你跟我一起走的話…

WAYMOND (CEO)

Before, you were asking about "our daughter". It's crazy. But it really got me thinking. What if... you had come with me... all of those years ago...

93-5 TAXES UNIVERSE: Deirdre drones on as Evelyn watches the men's choir sing and drink to Gong Gong's health.

DEIRDRE (O.S.) ... the amount of disrespect... To not even show up this evening...

EVELYN Shut up.

DEIRDRE (O.S.) What did you just say to me?

EVELYN I said shut up. You don't matter. This doesn't matter.

DEIRDRE (O.S.) MRS. WANG, I am through with-

Evelyn hangs up. That felt good.

93-6 CHEF UNIVERSE: The customer she hit with the shrimp is now talking to Evelyn's boss. She throws shrimp at her boss.  
As she storms out of the restaurant, she casually pulls off Chad's hat, revealing Racaccoonie.  
93-7 ACTION UNIVERSE: Alpha Gong Gong looks from the phone to Evelyn who gets up. Not dead. His worst nightmare.  
Evelyn recognizes a receipt on the ground as one of her own. She picks it up and stares at it.  
93-8 TEMPLE UNIVERSE: Evelyn's eyes begin to turn BLACK.  
93-9 TAXES UNIVERSE: Evelyn now holds a microphone as if she is about to perform karaoke. Waymond (half dressed as a Chinese dragon) looks on anxiously from the office doorway.

EVEI (slurring)

新年快樂。(Happy New Year) Thank you for coming. Another year... wow... what do I even say?

93-10 ACTION UNIVERSE: One of the Verse Jumpers approaches Evelyn. She nonchalantly grabs him and we hear the RUMBLING of the multiverse. The man begins to scream in horrible pain. POP! He is now a sack of potatoes.

ALPHA JUMPER  
She turned Sanders into potatoes!

ALPHA GONG GONG We're too late...

WAYMOND Evelyn! Please calm down

Waymond reaches out to stop her. She shrugs him off-

93-11 MOVIE STAR UNIVERSE: Evelyn stares out at the city traffic with unfocused eyes.

EVELYN (MOVIE STAR)

Sweet, sweet Waymond.

你想知道那個【假如】的結局嗎？

每天，我們會在一間小到快要倒閉的洗衣店醒來。

EVELYN (MOVIE STAR)

Sweet, sweet Waymond. You want to know what would have happened? "What if?" We'd wake up everyday in a tiny apartment over a failing laundromat.

93-12 TAXES UNIVERSE: Evelyn is talking through her microphone at all of her guests who are aghast at what she is saying.

EVELYN (CONT'D)

Another year... and we are still

keeping our heads high, pretending

we know what we're doing. But

really we're just running around in

circles. Doing laundry and taxes.

Laundry and taxes...

She pulls out the divorce papers and hurriedly signs them.

EVELYN (CONT'D)

No more running in circles.

Jobu nods in excitement. She is finally seeing it.

The door opens. Deirdre is flanked by two policemen.

DEIRDRE

Mr. and Mrs. Wang, you have given

me no choice but authorize the

seizure of both your personal and

business assets. You have 48hrs to

vacate your home, otherwise we will

have to remove you by force.

The cops begin to put locks on the laundromat doors.

GONG GONG

GONG GONG

搞也鬼啊？(In Cantonese)

What is happening?

WAYMOND

Evelyn□等一下。趕快告訴她你已經把

文件送了。...你去了，對嗎？

WAYMOND

Wait Evelyn. Tell her you already \* dropped off the paperwork... You dropped it off, right?

Waymond grabs her by the shoulders-

93-13 ACTION UNIVERSE: Waymond grabs Evelyn. The RUMBLE begins. Evelyn can't stop it.  
93-13A/B/We/D/Er/Flashes of her painting his face, spitting on him, dancing with him, throwing divorce papers at him, and even KISSING him in the Movie Star Universe against his will.

WAYMOND (CONT'D) What are you doing?

EVELYN (a little scared) Everything...

93-14 CHEF UNIVERSE: EXT RESTAURANT - Evelyn watches as Raccacoonie is carried away in a cage by an Animal Control employee. Chad is being held back by other employees.  
93-15 NOODLE UNIVERSE:

EVELYN (Noodles) (CONT'D) ... You're not going to stick spaghetti baby noodle boy! You're a different kind of pasta with a hole! NOBODY ELSE HAS A HOLE!

Spaghetti Baby Noodle Boy goes limp in the pot.

93-16 MOVIE STAR UNIVERSE: Waymond pushes Evelyn off and backs away, horrified.  
93-17 HOT DOG UNIVERSE: Deirdre is packing a bag. It's incredibly difficult to pack with floppy fingers.  
93-18 TEMPLE UNIVERSE: Jobu pushes Evelyn closer and closer to the Bagel. Evelyn begins to nod.

JOBU  
All of this time, I wasn't looking for someone who could defeat me. I was looking for someone who could see what I see. Feel what I feel...

93-19 TAXES UNIVERSE: Ignoring everyone else, Evelyn pokes at the paint stain on the ceiling with her baseball bat.

Evelyn turns & walks right up to Deirdre carrying the bat. The police palm their weapons.

But she walks up to the laundromat windows and places a hand against the glass.

JOBU (V.O.) And that someone is you.

# EVELYN

I've always hated this place anyways...

THE MUSIC EXPLODES INTO A FURIOUS CACOPHONY:

Evelyn smashes the front window of her laundromat.

93-20 OPERA UNIVERSE: Evelyn is singing "COME ON BARBIE LET'S GO BARBIE!" over and over again and causing feedback in the mic. The audience heads for the exits.

# JOBU (V.O.)

Not a single moment will go by in your mind without every other universe screaming for your attention...

93-21 NOODLE UNIVERSE: Spaghetti Baby Noodle Boy is sinking to the dark bottom of the pot alone.

# SPAGHETTI BABY NOODLE BOY

Why would god give me a hole for no reason?

93-22 TAXES UNIVERSE: INT. LAUNDROMAT - Evelyn throws the Karaoke machine out the window as she is restrained by one of the policemen and her hands are zip tied behind her back.

93-23 ACTION UNIVERSE: The RUMBLING stops with a deafening POP! Silence. Everyone gasps. Evelyn looks down to see she has stabbed Waymond in the side with a shard of glass. Blood begins to pour from his side and her hand.

# JOBU (V.O.)

Never fully there. A lifetime of fractured moments, contradictions, and confusion...

On Waymond's phone, a bright red warning flashes and red dots are everywhere. Alpha Gong Gong commands the Alpha Jumpers to aim their weapons at her. They tremble with uncertainty.

93-24 TEMPLE UNIVERSE: The BLACK SWIRLING BAGEL begins to overtake the entire screen. Evelyn's eyes are fully BLACK.

# JOBU (V.O.)

With only a few specks of time where anything actually makes sense. Just hilarious accidents.

93-25 VARIOUS UNIVERSES: Evelyn is center frame, rapidly shuffling through universes. Her stoic expression remains the same.

The transformation is complete. She is finally everywhere. She finally understands Jobu.

Music fades. She closes her eyes.

She slumps to the ground and becomes a rock. A literal rock.

94

ROCK UNIVERSE:EXT．FIELD

In an empty field, sit two rocks. The wind blows through the dirt. It is silent and serene. Almost eerily so.

Beat.

Beat.

JOBU ROCK

Oh, good you're here too.

EVELYN ROCK

Where are we?

JOBU ROCK

One of the universes where the conditions weren't right for life to form. Most of them are like this, actually.

EVELYN ROCK

It's... nice.

JOBU ROCK

Yeah. You can just sit here, and everything feels really far away.

Evelyn Rock can hear the faint SOUNDS AND VOICES from the other universes. But it fades away. They watch as the shadows get long in the setting sun.

EVELYN ROCK

Joy, I'm sorry about ruining everything, I-

JOBU ROCK

Shhhh. You don't have to worry about that here. Just be a rock.

A beat.

EVELYN ROCK

I just feel so stupid-

# JOBU ROCK

God! Please. We're all stupid.

Small stupid little humans. It's

like our whole deal.

(softens)

For most of our history we knew the

earth was the center of the

universe. We killed and tortured

people for saying otherwise.

The sun sets revealing a dense sky of stars.

# JOBU ROCK (CONT'D)

And then we find out that the Earth

is revolving around the Sun, which

is just one sun out of a trillion

suns, and now look at us: trying to

deal with the fact that all of that

exists in one universe out of who

knows how many. Every new

discovery, is just a reminder-

# EVELYN ROCK

We're all small and stupid.

# JOBU ROCK

Who knows what great new discovery

is coming next to make us feel like

even smaller pieces of shit.

# EVELYN ROCK

Language.

# JOBU ROCK

Seriously?

# EVELYN ROCK

I'm joking. That was a joke.

(laughing)

A big fucking joke.

They both laugh making each other laugh more just because they are both laughing. Then Jobu stops.

# JOBU ROCK

Fuck.

# EVELYN ROCK

What's wrong?

# JOBU ROCK

I've been trapped like this for so

long. Experiencing everything.

(MORE)

# JOBU ROCK (CONT'D)

A part of me hoped you'd see something I didn't. That you would convince me there was another way.

# EVELYN ROCK

What are you talking about?

A shadow falls over them-

95

EMPRESS UNIVERSE: INT. TEMPLE

Jobu and Evelyn stand before the Bagel together.

# JOBU

You know why I actually built the bagel? It wasn't to destroy everything. It was to destroy myself. I wanted to see if I went in, would I die. Like actually die.

Evelyn stares ahead. Scared & unsure what this means. Jobutakes her hand.

# JOBU (CONT'D)

At least this way I don't have to do it alone.

Evelyn stares deep into the swirling black hole. It's peaceful. Like a white noise machine. Her eye's gloss over.

# EVELYN

But what about the Raccoon, or the noodle, or my silly husband. What was his name again?

# JOBU

You won't have to worry about those things anymore.

Evelyn is unsure as they approach. The light pulls away from their faces. Evelyn's eyes begin to turn black again.

But then they hear a faint sound. VOICES. It's Waymond and Deirdre.

Evelyn turns, and through the swirling darkness, the image of Waymond trying to talk down a pissed off Deidre comes into focus.

# EVELYN

There he is. 神經病 (crazy person)

My silly husband. Probably making

things worse-

But against all odds, Deirdre's face softens. She takes Waymond's hand and gently pats it. Evelyn's curiosity draws her back into the laundromat-

96

TAXES UNIVERSE: INT. LAUNDROMAT

Evelyn watches in shock as Waymond walks back to her.

# WAYMOND

# WAYMOND

一切都會好起來的.

Everything is going to be okay.

96-1

She looks back to see: Jobu in front of the bagel.

# JOBU

Evelyn... ignore it. Come back.

Waymond reaches over and holds Evelyn's face in his hands.

# WAYMOND

# WAYMOND

她會再給我們最後一個礼拜。

She's going to give us another week for one last meeting.

One of the officers cuts her zip tie. Evelyn looks over at Deirdre pulling the lock off the door. Deirdre shakes her head equally shocked that she is letting her off.

# EVELYN

How? That's impossible.

# JOBU (O.S.)

It's a statistical inevitability.

This is nothing special.

# WAYMOND

I don't know, I just talked to her.

Evelyn looks over at Deirdre as she gives Waymond one last knowing nod, before stepping outside with a cigarette.

# EVELYN

# EVELYN

就這樣？

That's it?

Waymond shrugs and begins sweeping up the glass with a broom. Evelyn hears a voice from another universe.

WAYMOND (CEO) VO

你覺得我很軟弱，是嗎？

WAYMOND (CEO) VO

You think I'm weak don't you?

As she gets up she suddenly has a lit ci

"garette in her hand-

97 MOVIE STAR UNIVERSE:EXT.MOVIE THEATER ALLEY

Waymond takes one last drag from his cigarette, before leaving.

WAYMOND (CEO)

多年前我們剛談戀愛的時候，

你爸总是說我的心太軟。也許他當時是對的。

WAYMOND

When we first fell in love all of those years ago, your father would say I was too sweet for my own good. Maybe he was right.

Evelyn sees through her cloud of cigarette smoke:

97-1 ACTION UNIVERSE: INT. IRS 9TH FLOOR ATRIUM - Alpha Jumpers are still pointing their weapons at Evelyn. Waymond stumbles between them, holding his bloody wound.

WAYMOND (CONT'D)

Please! Can we just stop fighting!

Alpha Gong Gong shakes his head at these naive words.

98 MOVIE STAR UNIVERSE:EXT.MOVIE THEATER ALLEY

WAYMOND (CEO)

你說這是個很殘酷的世界，我們一直都在裏面繞圈子。我懂，我和你在這個地球上活了一樣久。

WAYMOND (CEO)

You tell me that it's a cruel world and we're all just running around in circles. I know that. I've been on this earth just as many days as you.

99 ACTIONUNIVERSE:INT.IRS 9THFLOORATRIUM

WAYMOND

I know you are all fighting because you are scared and confused.

Evelyn takes a small step back. The Alpha Jumpers begin to regain their positions.

# WAYMOND (CONT'D)

I'm confused too. One moment I am here. The next moment I am there. I still haven't seen any raccoons. All day, I don't know what the heck is going on. But somehow it feels like this is my fault. I don't know. The only thing I do know is we have to be kind. Be kind. Especially, when we don't know what's going on.

100 TAXES UNIVERSE: INT. LAUNDROMAT

WAYMOND (CEO) VO

我總是看到事情好的一面，不是因爲我天真，而是需要和必要，這就是我的生存之道。

WAYMOND (CEO) VO

When I choose to see the good side of things, I'm not being naive. It is strategic and necessary. It's how I've learned to survive through everything.

Waymond tries to cheer himself up by dancing and humming while he sweeps.

Evelyn sees the untouched Tupperware of cookies with a bow. She looks down at the baseball bat she is holding. There are two googly eyes stuck to it. It's smiling at her.

WAYMOND (CEO) (V.O.)

我理解你是被生活所迫，但你不是個服輸的人。我又何嘗不是。只是我們選擇的處理方式不一樣。

WAYMOND (CEO) VO (CONT'D)

I know you go through life with your fists held tight. You see yourself as a fighter. Well, I see myself as one too. This is how I fight.

101 ACTIONUNIVERSE:INT.IRS9THFLOORATRIUM

Evelyn drops her fists. She doesn't know what's going on either. Wounded Alpha Jumpers surround her, weapons raised.

101-1 TEMPLE UNIVERSE: Framed by the swirling Bagel, Jobu looks right at us.

# JOBU

Evelyn, you can still turn around and avoid all this.

101 BACK IN THE IRS:

# EVELYN

It's too late, Waymond.

# WAYMOND

Don't say that.

Evelyn looks at her bleeding selfless husband like she's never seen something so beautiful. MUSIC BEGINS TO PLAY. [The same romantic music from the Movie Star Universe when she saw Waymond in the crowd.]

101-2 TAXES UNIVERSE: INT. LAUNDROMAT - Evelyn's stare lingers before she turns away from the Bagel and hugs Waymond hard.  
101 ACTION UNIVERSE: Evelyn takes Waymond's hand, we hear a RUMBLE begin to grow. Evelyn looks at him and we reveal  
101-3/4/5VARIOUS UNIVERSES: Abstract and delicate shots of Waymond throughout the multiverse: He is ecstatic, overwhelmed, crying while laughing, bored. Evelyn is seeing a whole, complete vision of her husband for the first time since she first fell in love, maybe ever. We end on-  
102 MOVIE STAR UNIVERSE:EXT.MOVIE THEATER ALLEY

# WAYMOND (CEO)

儘管你一再讓我心碎，我還是想告訴你如果有來生，我還是會選擇和你一起開洗衣店，報稅。

# WAYMOND (CEO)

So, even though you have broken my heart yet again, I wanted to say... In another life, I would have really liked just doing laundry and taxes with you.

He turns to go.

103 TAXES UNIVERSE: INT. LAUNDROMAT

Holding Waymond, Evelyn can't look away from him.

# WAYMOND

# WAYMOND

什麼？怎麼了？

What? What's wrong?

# EVELYN

(at peace)

Nothing.

106 ACTIONUNIVERSE:INT.IRS9THFLOORATRIUM

The Alpha Jumpers lower their weapons. This cute couple doesn't seem like a threat. Evelyn smiles, is this working?

She turns to find Jobu is standing beside her, clearly annoyed. Jobu grabs Evelyn's arm and pulls her away from Waymond.

106-1 FLASH:TEMPLUNIVERSE-theyarebackbytheBagel.

JOBU Come on, Evelyn.

Evelyn pulls away and they are:

106 BACK IN THE IRS:

JOBU (CONT'D) Why the hell would you want to be here?

Evelyn looks at Waymond. She can't help but smile.

EVELYN I- I don't know.

JOBU I get it. You're feeling a good thing. Y'got your hopes up. I'm here to save you some time: eventually that goes away. Come on.

Jobu swiftly grabs Evelyn's hands, hand vagina trick! Rumble - Jobu opens her hands - Wind whips through the air.

THE BAGEL IS NOW IN THE IRS BUILDING at the top of the stairs. Wind swirls and objects rumble. Everyone cowers in fear except Jobu who heads for the stairs.

JOBU (CONT'D) I don't care if you come with me. (with disdain) Enjoy your life.

Evelyn defiantly steps in between Jobu and the stairs.

As Evelyn approaches her, Jobu raises both hands-

TEMPLE UNIVERSE: Jobu lifts her hands. Hooded figures blow on horns. Her followers plug into verse jumping machines.

BACK IN THE IRS: Bagel Followers led by Deirdre march into the room, forming a wall between Evelyn and Jobu.

Evelyn attempts to push through the Bagel Followers to get to Jobu. Deirdre fights back but Evelyn easily blocks her blows and puts Deirdre into a choke hold.

# WAYMOND

Evelyn, please no more fighting.

Evelyn hesitates. She turns to see Waymond cowering in a cubicle.

The Bagel Followers pin her onto the ground. Jobu easily walks right past her and heads towards the Bagel.

Deirdre rips a blade from a nearby paper cutter and holds it to Evelyn's neck.

# DEIRDRE (BAGEL)

What did I tell you about caring

too much, Evelyn?

Evelyn clenches her fists, but doesn't know how to get out without hurting anyone. She looks up at Deirdre who winds back her blade, about to strike. TIME SLOWS.

107

VARIOUS UNIVERSES: DEIRDRE'S LIVES

TAXES UNIVERSE - EXT. LAUNDROMAT

Evelyn steps out of the laundromat to find Deirdre nursing her vape pen. Neither of them talk at first, but Deirdre offers Evelyn a drag from her vape.

# DEIRDRE

Careful. Don't want to make me

change my mind... again.

She gives Evelyn a wry smile before exhaling.

# EVELYN

What did he say to you?

# DEIRDRE

He mentioned your... situation. I

remember when my ex gave me the

papers. I drove his KIA Forte

through the neighbors' kitchen.

Evelyn looks back at the mess she created.

# DEIRDRE (CONT'D)

Maybe that's why I've been really

hard on you. I see myself in you.

We're both... difficult women.

Evelyn looks at Deirdre, they are suddenly in-

107-1

HOT DOG UNIVERSE: INT. APARTMENT

Evelyn watches as Hot Dog Deirdre is walking out the door, holding her suitcase with her toes and not her hands.

107-2 FLASHBACKS: 1) At a dinner party, Deirdre is clearly uncomfortable so Evelyn places her feet on Deirdre's. 2) Deirdre is playing piano with her toes, but when Evelyn walks in, she immediately stops in embarrassment. 3) Evelyn goes in for a hug, but Deirdre pushes her away.

DEIRDRE (V.O.)  
You know what I say? Cold,  
hysterical, unlovable bitches like us make the world go round.

107-1 Evelyn slowly walks towards Deirdre in the doorway and lifts her toes to wipe Deirdre's tears. It's incredibly tender.  
107-3 ACTIONUNIVERSE:INT.IRSBUILDING

Evelyn looks into Deirdre's eyes with a deep understanding. Deirdre's blade is an inch away from her neck-

Suddenly the blade STOPS. Evelyn's foot has caught Deirdre's arm.

107 TAXES UNIVERSE:EXT．LAUNDROMAT

EVELYN That's not true.

DEIRDRE

What?

Deirdre is taken aback.

107-3 ACTIONUNIVERSE:INT.IRSBUILDING

EVELYN You aren't unlovable.

DEIRDRE (BAGEL) The hell are you talking about?

Deirdre's blade struggles against Evelyn's foot.

EVELYN There is always something to love. Even in a stupid, stupid universe where we have hot dogs for fingers, we'd all be very good with our feet!

Evelyn disarms Deirdre using nothing but her toes. She then uses her feet to swiftly Jiu Jitsu the Bagel Followers holding her back.

She pulls Deirdre in for a hug. Deirdre resists.

# EVELYN (CONT'D)

And in a universe where we both agree that no one could love you, if we look hard enough, something will prove us wrong. (hugs deeper) We are wrong.

# DEIRDRE (BAGEL)

Stop this. Stop this now.

107-1 HOT DOG UNIVERSE: Evelyn is hugging Hot Dog Deirdre. Deirdre drops her suitcase and fully lets go into the hug.  
107 TAXES UNIVERSE: Evelyn is hugging Deirdre who is clearly uncomfortable, trying not to reveal that she is moved.  
107-3 BACK IN THE IRS: Deirdre begins to break down. Her fellow Bagel Followers whisper.

# DEIRDRE (BAGEL) (CONT'D)

I feel nothing! Decree 46, I mean

47. What's the decree? I feel...

107-1 HOT DOG UNIVERSE: Using her toes, Evelyn unbuttons Deirdre's shirt then slaps her thighs. She is beginning the mating ritual. Deirdre is over the moon.  
107-3 ACTION UNIVERSE: Deirdre collapses to the ground. But no tears fall. She pulls out her verse jumping ear pieces. She looks up at Evelyn. They give each other a knowing nod.

Evelyn turns to see Jobu halfway up the stairs, but between them stand the Followers and the Alpha Jumpers who have teamed up. At the top of the stairs is Rick loaded up with vintage military gear, including an automatic rifle.

# ALPHA GONG GONG

Don't let her stop Jobu. Open fire!

# DEIRDRE

No!

Rick pulls the trigger.

Evelyn steps in front of Deirdre blocking the shower of bullets, but instead of ripping through her, they stop and begin to Rumble.

Evelyn looks at a bullet gently pushing up against her forehead. She grabs it-

107 FLASH: TAXES UNIVERSE: EXT. LAUNDROMAT - She reaches down to the baseball bat on the concrete. She plucks a googly eye from it-

POP. The bullet is now a googly eye. She sticks it to her forehead like a third eye.

POP! Every bullet touching her becomes a googly eye. She pushes the googly eyes, sending them flying and sticking to everything: guns, helmets, computer monitors. Everything is suddenly a lot cuter.

A107 ROCKUNIVERSE:EXT．FIELD

Evelyn Rock suddenly jiggles. Just a little.

# JOBU ROCK

Stop that. You aren't supposed to move here. You're just a rock.

# EVELYN ROCK

There are no rules!

Evelyn Rock wiggles around to reveal: Her Rock now has two googly eyes.

# JOBU ROCK

Evelyn, I swear to god if you ruin my favorite universe-

A107-1 ACTIONUNIVERSE:INT．IRS

# WAYMOND

Evelyn, what are you doing?

Alpha Gong Gong shouts for everyone to attack! They charge. Evelyn nods. She is understanding her place in the noise.

# EVELYN

I'm learning to fight like you.

Evelyn serenely dodges a kick, ducks under a fist with a broken mug used as brass knuckles. She makes a Bagel Follower and Alpha Jumper kiss, she turns a grenade into a nostalgic perfume spray in Rick's face, she stretches and cracks someone's back - in a good way.

Waymond can't believe his eyes. Is this working?

An Alpha Jumper attacks with a pair of scissors- it's the District Manager! Evelyn grabs the scissors- RUMBLE

A107-2

FLASH: JANITOR UNIVERSE: INT. SEX CLOSET: Janitor Evelyn grabs a ball gag from the wall-

A107-1

POP! The scissors are now a ball gag. She pops it into the District Manager's mouth-

A107-3

FLASH: JANITOR UNIVERSE: We reveal Evelyn is dressed in a full dominatrix outfit. She bends the District Manager over her knee and slaps him on the ass.

A107-1

The slap is so strong that it ripples through his whole body, sending the bluetooth ear pieces flying out. With tears in his eyes he mouths "Thank You, Mommy."

Evelyn sees Jobu approaching the Bagel. Thinking quickly, she grabs the District Manager's belt and turns it into a whip. She uses it to wrap around Jobu's ankle, which causes her to stumble down the stairs. Jobu looks up furious.

Evelyn steps on Jobu's untied laces then turns to a charging Bagel Follower who holds a knife - it's her Kung Fu Master.

108

MOVIE STAR UNIVERSE:EXT.MOVIE THEATER STREET CORNER

On a bustling sidewalk, Evelyn chases Waymond through the crowd. She SLAMS into someone. It's her Master.

KUNG FU MASTER

你已經走了大半路了，不要前功盡棄。

KUNG FU MASTER

You walk half the road, only to give up?

She pulls out the cookie, taunting her.

EVELYN (MOVIE STAR)

你以前說過，功夫可以是任何東西，就算是塊是餅乾。師傅，我終於準備去做我自己的餅乾了。

EVELYN (MOVIE STAR)

You once said, Gong Fu can be anything, even that cookie.

Master, I am finally ready to chase a different cookie.

Evelyn looks back at Waymond disappearing around a corner. She begins to attempt to take the Master's cookie-

109

ACTION UNIVERSE: INT. IRS 9TH FLOOR ATRIUM

Evelyn attempts to pull her Master's knife from her hand. She succeeds, and turns it into one of Waymond's smiley face cookies then shoves it in her mouth. Though the Master is confused, something seems oddly familiar about this.

While she's distracted, Evelyn knocks out her ear pieces.

Shoeless Jobu attempts to escape, but Michelle grabs her coat belt and ties herself to her daughter.

Suddenly a gun is against her head. It's Debbie the Dog Mom. She grabs the gun, RUMBLE POP! The gun is now a phone mid-video call with Debbie's toddler son wearing a birthday hat. Debbie gasps.

# HUMAN BABY PERSON BOY

(voiced by Spaghetti Boy)

Mom? Are you coming? Remember,

Daddy said I can have both mommies

at my party this year.

Debbie (the MOM) is overwhelmed with a moment of clarity.

110 NOODLE UNIVERSE: INT. BOILING POT

A stray spaghetti strand reaches out of the fray and down into the depths of the pot to grab onto her son.

# SPAGHETTI BABY NOODLE BOY

What are you doing?

Evelyn Spaghetti threads her noodle body through her macaroni son's elbow and lifts him off the bottom.

# EVELYN (Noodles)

It's throwing day, Spaghetti Baby

Noodle Boy, and I'll be damned if a

baby noodle boy of mine don't

stick!

Noodle Baby Boy is as shocked as a noodle baby boy can be.

111 ACTIONUNIVERSE:INT.IRS9THFLOORATRIUM

Evelyn yanks out Debbie the Dog Mom's ear pieces before gesturing for her to leave. She nods and runs away.

# DEBBIE THE DOG MOM

Mommy's coming, honey!

A hand grabs Evelyn's hair and pulls her to the ground. She grabs her own hair, which turns into spaghetti, allowing her to free herself.

Then desperately throws the fist-fulls of spaghetti at Jobu. They bounce off her and land on the floor. Splat.

# JOBU

Oh no, not Spaghetti! What did you think was going to-

Jobu slips on the spaghetti, again stumbling down the stairs.

# JOBU (CONT'D)

How the hell did that work?

# EVELYN

A statistical inevitability!

Evelyn turns around, grabs her attacker's hair, causing his arms to lift straight up in the air, knocking his hat off: CHAD?

111-1 CHEF UNIVERSE: EXT. BENIHANA'S - Evelyn approaches Chad who is slumped on the curb.

# CHAD (CHEF)

That raccoon completed me. I'm useless alone.

111 ACTION UNIVERSE: Evelyn control's Chad's body using his hair.

# CHAD (CONT'D)

I've never told anyone about my... hair condition.

She holds him close and whispers IN BOTH UNIVERSES.

# EVELYN/CHEF

We are all useless alone. So its good you're not alone.

Chad fights back tears.

111-1 CHEF UNIVERSE: Evelyn hops up onto his shoulders and grabs his hair.

# EVELYN (CHEF)

Together, we can save your silly Raccoon.

111 ACTION UNIVERSE: Slow Motion: Evelyn, riding on Chad's shoulders charges at a wall of Followers & Alphas.

Waymond looks on in awe.

Alpha Gong Gong's face hardens with anger.

We reveal the aftermath: The Alpha Jumpers and Bagel Followers strewn across the floor in various stages of emotional release. One lady is holding a puppy laughing, someone else is trying to hide the fact they are orgasming.

Michelle turns to Jobu who seems possibly impressed? But suddenly she tumbles from Chad's shoulders.

She falls to the floor and is quickly pinned to the banister by mechanical arms!? It's Alpha Gong Gong in a makeshift office supply robot exoskeleton.

# ALPHA GONG GONG

Evelyn.

His stern stare pierces her new found confidence-

112 TAXES UNIVERSE: INT. LAUNDROMAT

Evelyn sees Gong Gong angrily trying to walk up the stairs, despite Waymond's protests. Evelyn rushes over to him.

GONG GONG

狗啦。(In Cantonese)

GONG GONG

That's enough

EVELYN

對唔住， 啊爸(In Cantonese)

EVELYN

I'm sorry, father, but-

GONG GONG

唔好再叫我做啊爸，做埋地啪啜事，三餐都成問題，我有你D啪啜女(In Cantonese)

GONG GONG

Do not call me father! No daughter of mine would act this way. Live this way.

He sneers at their run down laundromat.

113 ACTIONUNIVERSE:INT.IRS9THFLOORATRIUM

Evelyn watches Jobu climb the stairs towards the Bagel.

JOBU ROCK (V.O.)

See? It's only a matter of time before everything balances itself out.

113-1 FLASH: NOODLE UNIVERSE: INT. BOILING POT - They struggle against the other noodles.  
113-2 FLASH: MOVIE STAR UNIVERSE: EXT. STREET - Evelyn catches Waymond, but the crowd is pushing her away.

WAYMOND (CEO)

算了吧,多情自古空馀恨，好夢由來不願醒。

WAYMOND (CEO)

Give it up. Sometimes it's better to let the fantasy live up here.

113-3/4

FLASH: CHEF UNIVERSE: EXT. STREET - Evelyn is steering Chad as they chase the animal control truck down the street. They aren't fast enough. Chad has a cramp.

113-5

FLASH: TAXES UNIVERSE: INT. LAUNDROMAT - Some more guests leave. Joy watches from the back of the room.

114

ACTION UNIVERSE: INT. IRS 9TH FLOOR ATRIUM

Alpha Gong Gong begins to crush Evelyn against the banister. Evelyn watches Jobu stop in front of the Bagel. She is close enough to touch it now. But she hesitates.

ALPHA GONG GONG

Just let her go.

EVELYN

我做唔倒啊阿爸，我真係唔明你點可以放棄我嘎

EVELYN

(In Cantonese)

I can't. Baba. How on earth did you do it? How did you let me go?

These words hit Alpha Gong Gong hard.

115

TAXES UNIVERSE: INT. LAUNDROMAT

EVELYN

我由細到大也都聽噻你話，你想點就點。我宜家終於有勇氣做翻我自己。你唔中意都唔緊要。哩個就係我。

EVELYN

(In Cantonese)

You know, I've spent all of these years trying to see things through your eyes. I am finally finding the courage to see things through my own. It's okay if you can't be proud, because I finally am.

From the back of the room Jobu rolls her eyes.

116

ACTION UNIVERSE: INT. IRS 9TH FLOOR ATRIUM

Up the stairs, Jobu winds back, about to leap into the Bagel. Evelyn looks directly into Gong Gong's eyes.

# EVELYN

我再也唔會用你對我咽一套去對我自己個女。

# EVELYN

I am no longer willing to do to my daughter, what you did to me.

(In Cantonese)

Alpha Gong Gong is taken aback. He loosens his grip and Evelyn can break free.

Jobu is just about to enter the Bagel as Evelyn grabs her wrist.

116-1 TAXES UNIVERSE: INT. LAUNDROMAT

Evelyn holds Jobu's wrist. Jobu is not pleased.

# EVELYN (CONT'D)

你可能噸但身上睇倒你自己最大慨恐懼。我一直都好希望伯唔會似我。(In Cantonese)

But she turned out stubborn, aimless, a mess just like her mother. But now I see it's okay that she's a mess. Because just like me,

讓他在這個空間找到一位善良，有耐性又可以包容她的人

# EVELYN (CONT'D)

You may see in her all of your greatest fears squeezed into one person. I spent most of her childhood praying she would not end up like me. But she turned out stubborn, aimless, a mess just like her mother. But now I see it's okay that she's a mess. Because just like me, the universe gave her someone kind, patient, and forgiving to make up for all she lacks.

She looks from Waymond to Becky and smiles. Before Jobu can stop her, Evelyn grabs Becky's hand.

# EVELYN (CONT'D)

爸，这口Becky．她口Joy的女朋友。

# EVELYN (CONT'D)

Ba, this is Becky. This is Joy's girlfriend.

Gong Gong's face remains stoic. Becky and Jobu exchange looks of shock.

Waymond is so proud of his wife. He pulls the divorce papers from his pocket. He contemplates the signature on the bottom.

116 FLASH: ACTION UNIVERSE: Jobu turns and looks at her mother.

116-1 Evelyn walks Becky and Jobu to Gong Gong.

117 ROCKUNIVERSE:EXT．FIELD

Evelyn Rock moves another inch closer to Jobu Rock.

# JOBU ROCK

Fuck this. I can't take anymore of this emotionally manipulative bullshit.

Jobu Rock starts to wiggle away. A rock chase commences!

118 VARIOUS UNIVERSES:  
118-1a ACTION UNIVERSE: Jobu attacks Evelyn.  
118-1b VARIOUS UNIVERSES: Evelyn blocks each of Jobu's blows as they flash flash flash through different scenarios  
118-1c INT. COURTROOM: Judge Jobu grabs the gavel and swings it at Lawyer Evelyn who blocks it  
118-1d ACTION UNIVERSE: The gavel is now flowers.

# JOBU

Maybe you win in this universe. But in another-

118-1e EXT FOREST: They are dressed as kung fu warriors.

# JOBU (CONT'D)

-I beat you-

Jobu lands several hits but Evelyn pushes her away

118-1f INT. JAIL: They charge each other and right as they hit each other-  
118-1g EXT. BACKYARD: They are swinging piñatas again.

# JOBU (CONT'D)

-or we tie. Or we eat crepes.

A hand grabs Evelyn Pinata's head.

118-1h MOVIE STAR UNIVERSE: EXT. HONG KONG ALLEY - Jobu holds Evelyn by the head and pushes her down into the path of an oncoming car-

# JOBU (CONT'D)

Cause all of it's a pointless swirling bucket of bullshit.

118-1i ACTION UNIVERSE: INT. IRS - Jobu is holding Evelyn's head inches from the Bagel.

# JOBU (CONT'D)

That bagel is where we finally find peace Evelyn.

# EVELYN

Stop calling me Evelyn!

Evelyn flexes her pinky then flicks Jobu's hand away

118-1j

VARIOUS UNIVERSES: Evelyn blocks Jobu's blows turning them into a hug.

# EVELYN (CONT'D)

I．AM．YOUR．-

118-1k

ACTION UNIVERSE: INT. IRS - Jobu breaks free, falls towards the bagel, Evelyn grabs her waist-

# EVELYN (CONT'D)

Mother!

Alpha Gong Gong can't believe his eyes.

Jobu is flustered for the first time. She squirms back to the Bagel and with renewed strength drags Evelyn towards it. Evelyn struggles with all of her might, but it's not enough. Tornado-like winds pull them towards the Bagel. Her feet slip inch by inch

118-2

CHEF UNIVERSE: EXT. STREET - Evelyn leaps off Chad and beckons him to get on her back.

# CHAD (CHEF)

What are you doing?

# EVELYN

Get on!

Chad jumps on her back. He pulls her hair and they are on their way. Evelyn screams as she pushes her body-

118-3

HOT DOG UNIVERSE: INT. APARTMENT - Evelyn and Deirdre circle each other continuing the mating ritual.

118-4

MOVIE STAR UNIVERSE: EXT. BUSTLING STREET - Evelyn tearfully pours her heart out to Waymond but we can't hear her words.

118

ACTION UNIVERSE: Suddenly Evelyn and Jobu stop moving. Two robot arms are wrapped around Evelyn's waist. What?

It's Alpha Gong Gong pulling them away from the Bagel as well. Evelyn can't believe her eyes.

118-5

TAXES UNIVERSE: INT. LAUNDROMAT

GONG GONG

GONG GONG

女朋友？好吧．(In Cantonese)

Girlfriend? Hao ba.

# BECKY

What? What did he say?

Becky is tearing up, she doesn't need words to understand.

118 ACTIONUNIVERSE:INT.IRS9THFLOORATRIUM

# ALPHA GONG GONG

I can't believe I'm doing this.

A bloody Waymond stumbles over and weakly tries to help as well. The whole family is trying to drag Jobu away.

# JOBU

Seriously...

118-6 ROCK UNIVERSE: Jobu Rock is approaching a cliff's edge with Evelyn rock on her tail

# JOBU ROCK

... can you please just...

119 TAXES UNIVERSE:EXT.LAUNDROMAT

Evelyn chases Joy to her car. Joy stops abruptly and turns.

# JOY

... stop, Mom.

The tears in Joy's eyes stop Evelyn in her tracks.

Waymond and everyone left watch from the laundromat.

# JOY (CONT'D)

Good for you. You're figuring your shit out. And that's great. But I'm tired. I don't want to hurt anymore. And for some reason when I'm with you, it hurts both of us. So, let's just go our separate ways... Please.

Evelyn is taken aback. For the first time she is truly seeing Joy's pain. Joy waits for her mom to say something.

# EVELYN

Okay.

120 ACTIONUNIVERSE:INT.IRS9THFLOORATRIUM

Jobu slips out of Evelyn's fingers. The family collapses to the floor as the blackness of the Bagel begins consuming Jobu.

121 ROCKUNIVERSE:EXT．FIELD

Jobu Rock tips over the edge and begins to tumble away from Evelyn Rock who watches from the cliff's edge-

122 TAXES UNIVERSE:EXT．LAUNDROMAT

Evelyn watches as her daughter walks to her car.

122-1 FLASHBACK: She watches as little Joy runs away from her.

Evelyn turns her back to Joy and begins to walk to the laundromat with her head down in shame.

She hears Joy open her car door.

# EVELYN

Wait.

Joy turns, one foot already in the car, but Evelyn doesn't know what to say.

# EVELYN (CONT'D)

You're getting fat.

# JOY

What?

# EVELYN

And you never call me even though we are on a family plan and it's FREE. You only visit when you need something, and you got a tattoo, and I don't care if it's supposed to represent our family, you know I hate tattoos. Out of all of the places I could be, why would I want to be here with you? You are right. It doesn't make sense.

# WAYMOND

Evelyn，別說了。夠了。

# WAYMOND

Evelyn, stop. That's enough.

# JOY

Let her finish.

# EVELYN

Maybe it's like you said, maybe there is something out there, some new discovery that'll make us feel like even smaller pieces of shit. Something that explains why even after seeing everything, and giving up, you still went looking for me through all of this noise. And why no matter what, I still want to be here with you. I will always want to be here with you.

Joy goes to her mom. Finally vulnerable.

# JOY

So... what? You're just going to ignore everything else? You could be anything, anywhere. Why not go somewhere where your daughter is more than just... this. Here, all we'll get are a few specks of time where any of this actually makes sense.

Evelyn looks at the mess around her. We hear the SOUNDS OF THE OTHER UNIVERSES SWIRLING IN.

She grabs Joy's hands and the sounds stop.

# EVELYN

Then I will cherish these few specks of time.

Joy slowly nods her head and leans in closer to her mom.

Evelyn closes her eyes and breathes in deep. As the music crescendos, Evelyn tries to let all of the other universes go:

122-2 NOODLE UNIVERSE: A giant chef hand plucks them from the spoon.

EVELYN (Noodle) (CONT'D)

Hold your breath!

He throws them: Mother-threaded-through-noodle-son. It's magical, like flying- FADE TO BLACK

122-3/4 CHEF UNIVERSE: Chad is riding Evelyn, as they catch up with the truck. Raccaccoonie watches them in awe through the back window- FADE TO BLACK

122-5 HOT DOG UNIVERSE: Evelyn and Deirdre open their mouths and lift up their beautiful floppy fingers, about to squirt their finger condiments. The ritual is almost complete- FADE TO BLACK  
122-6 TEMPLE UNIVERSE: Bagel Deirdre pulls off her robes and swings open the Temple exit doors. Light spills over her face- FADE TO BLACK  
122-7 ACTION UNIVERSE: The final signs of Jobu are swallowed by the BLACKNESS. Evelyn closes her eyes and focuses.

On Evelyn's cerebral map. Just a few red dots. Fewer, fewer

122-8 OPERA UNIVERSE: Evelyn and her father sing their hearts out to an empty room. She lets out one long sustained note, causing the ground to rumble- FADE TO BLACK  
122-9 ROCK UNIVERSE: Evelyn Rock comes rolling down the hill towards Jobu Rock. They are about make contact- FADE TO BLACK  
122-10 MOVIE STAR UNIVERSE: Waymond is stoic. Evelyn waits for him to say something, anything. He begins to crack a smile - FADE TO BLACK  
122-7 ACTION UNIVERSE: Evelyn stands by the edge of the Bagel.

Suddenly a hand reaches out. Evelyn grabs it! She pulls Jobu out and they stumble away from the bagel.

Jobu looks exhausted. She rests her head on her mother's shoulder - FADE TO BLACK

122 TAXES UNIVERSE:EXT．LAUNDROMAT

Joy rests her head on her mother's shoulder here as well. She lets out a sigh of deep relief.

The music stops. Everything is still. They are only here, in one universe, for now.

Evelyn studies every little piece of the moment: the stray hairs coming from Joy's head, the flicker of the neon lights across the car's reflection, the distant sound of the highway like ocean waves.

Evelyn sees Waymond and Becky tearfully watching from the laundromat entrance.

The remaining guests are watching from inside.

JOY

Oh god, now I feel so awkward. This

is awkward right?

Joy pushes Evelyn away and they casually walk together back towards the laundromat.

JOY (CONT'D) Do you still want to do your party?

EVELYN We can do whatever we want.

Waymond hears this, and pulls out the signed divorce papers from his pocket. He looks them over then tears them up.

Joy spots the karaoke machine on the ground. She picks up the microphones and shakes the glass from them.

JOY "You can touch. You can play. If you say..."

JOY AND EVELYN "I'm always yours."

Waymond turns on the TV and presses play. The lyrics of "Barbie Girl" by Aqua come on the screen (from the opening).

The remaining men from the Chinese Church Choir all begin to sing in harmony.

MEN'S CHOIR I'm a Barbie Girl, in a Barbie world. Life in Plastic, it's fantastic. You can brush my hair, undress me everywhere. Imagination...

As their beautiful song reverberates around the room, Evelyn and Joy look at each other and mouth the final lines.

JOY AND EVELYN AND EVERYONE ELSE Life is your creation.

This is good. Even if it's just for a tiny speck of time.  
FADE TO BLACK.

123

INT. APARTMENT - MORNING

Evelyn and Waymond sit at the table loading papers and receipts into a file folder.

We hear the toilet flush and Joy steps into the room.

JOY We're definitely late now guys.

# EVELYN

Joy, I know you could be a million other places right now. Thank you for coming.

Joy rolls her eyes. She leaves with Waymond, leaving Evelyn alone for a moment.

TITLE: "PART 3: ALL AT ONCE"

124

EXT. IRS BUILDING - MORNING

Becky drives up to the front entrance and the family climbs out.

# WAYMOND

Thank you for the ride.

Becky puts her car in gear, but Evelyn stops her.

# EVELYN

Becky? You need to grow more hair.

This means the world to Becky. She rubs the shaved side of her head and smiles.

125

INT. IRS LOBBY - MOMENTS LATER

Evelyn, and Waymond walk down the hallway with Joy trailing behind them pushing Gong Gong.

Waymond looks down at Evelyn's hand. He gets the courage to hold it.

She looks at him a bit unsure then squeezes it back. They walk like that, holding hands towards the elevator.

Joy heads to the bathroom.

# JOY

I gotta pee. Hold on.

我也得去。

WAYMOND

WAYMOND

I should go too.

EVELYN

EVELYN

我幫你拿。

I'll hold your bag.

He hands it to her, grateful, then turns away.

# EVELYN

Wait.

She grabs his hand again and pulls him in. And they kiss. It's sweet. A little awkward.

126

INT. IRS 9TH FLOOR OFFICE - LATER

A wall of triumphant music plays as Evelyn looks at her family: Gong Gong naps in the corner, while Joy idly scrolls through her phone, and Waymond politely nods to Deirdre who chugs another protein shake.

With saintlike serenity, Evelyn and Waymond hold hands and patiently wait as Deirdre lists all of their new infractions and thumbs through a pile of red sticky notes.

# DEIRDRE

Evelyn? Did you hear me?

# EVELYN

(happy & distracted)

I'm sorry. Could you repeat the

question?

CUT TO:BLACK

TITLE: "Everything, Everywhere, All at Once"