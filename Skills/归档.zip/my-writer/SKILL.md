---
name: my-writer
version: 0.1.0
description: |
  专业中文剧本创作和优化助手。当用户需要改编、扩写、优化中文剧本到指定长度（8-10万字）时，使用该技能。
  提供完整的项目初始化、任务分步执行、字数进度跟踪、自动状态保存和恢复功能。
---

## 技能概述

本技能为专业中文剧本创作和优化助手，专为以下场景设计：

- 将短剧本扩写至 5-8 万字的完整电影剧本
- 优化现有剧本结构和叙事完整性
- 应用经典叙事框架（三幕式、五幕式、英雄之旅等）

目标规格：120 分钟电影剧本，90-100 场戏，每场 1-2 分钟，总字数 50,000-80,000 字。

## 工作流程

### Step 1: 项目初始化

使用初始化脚本创建标准项目结构：

```bash
python scripts/init_project.py
```

脚本会自动创建以下目录结构：

```
project/
├── ref/                    # 参考剧本和辅助内容
├── output/                 # 剧本输出目录
├── data/                   # 临时文件和状态数据
└── scripts/                # 工具脚本
    ├── init_project.py     # 初始化项目
    ├── status_manager.py   # 状态管理
    └── word_counter.py     # 字数统计
```

### Step 2: 分析阶段

#### 2.1 剧本分析

读取原剧本，生成分析报告：

```bash
python scripts/analyze_screenplay.py --input <原剧本文件> --output data/storyboard_src.md
```

此脚本会：

- 创建 `data/storyboard_src.md` 包含：情感基调、核心主题、故事线、大纲、人物关系图谱
- 自动创建 `data/status.json` 记录当前进度

#### 2.2 参考分析（如提供参考资料）

```bash
python scripts/analyze_reference.py --input <参考剧本> --output data/storyboard_ref_<name>.md
```

### Step 3: 规划阶段

生成分段扩写计划，避免任务中断：

```bash
python scripts/generate_plan.py
```

生成以下文件：

- `data/expansion_plan.md` - 分幕章节的详细规划
- `data/chapter_breakdown.md` - 每章目标字数分配
- `data/writing_schedule.md` - 写作时间表和里程碑

**扩写策略**：

- 使用经典三幕式结构
- 每幕细分 3-4 个序列
- 每个序列包含 8-12 场戏
- 每场戏目标字数：800-1200 字
- 总场数：90-100 场

### Step 4: 分步扩写

采用增量式写作，每完成一部分自动保存进度：

```bash
# 扩写第一幕
python scripts/expand_act.py --act 1 --input data/storyboard_src.md --output output/act1.md

# 继续第二幕
python scripts/expand_act.py --act 2 --input output/act1.md --output output/act2.md

# 继续第三幕
python scripts/expand_act.py --act 3 --input output/act2.md --output output/final_screenplay.md
```

每个脚本会：

- 检查 `data/status.json` 中的进度
- 自动读取已完成的部分
- 扩写指定幕的内容
- 更新字数统计和进度状态

### Step 5: 优化和润色

```bash
python scripts/polish_screenplay.py --input output/final_screenplay.md --output output/polished.md
```

## 中断恢复机制

**任何时候中断后，按如下步骤恢复：**

1. 检查当前进度：

   ```bash
   python scripts/status_manager.py --status
   ```

2. 根据状态提示继续执行下一步脚本

3. 所有脚本支持从上次中断位置自动继续

## 目录结构说明

- **ref/**: 存放参考剧本、风格指南、参考资料

  - 原剧本文件（必需）
  - 参考剧本（可选）
  - 格式模板

- **output/**: 最终输出和中间成果

  - `act1.md`, `act2.md`, `act3.md` - 分幕剧本
  - `final_screenplay.md` - 完整剧本
  - `adaptation_report.md` - 改编报告

- **data/**: 临时数据和状态
  - `status.json` - 进度状态（自动更新）
  - `storyboard_*.md` - 分析报告
  - `expansion_plan.md` - 扩写计划
  - `word_count.txt` - 字数统计日志

## 字数目标管理

- **总目标**：80,000 - 100,000 字
- **每场目标**：800 - 1,200 字
- **监控频率**：每完成 5 场检查一次
- **调整策略**：如果某场超出/不足，调整后续场次目标

使用字数统计工具检查进度：

```bash
python scripts/word_counter.py --file output/final_screenplay.md --target 90000
```

## 错误处理

所有脚本包含以下错误处理机制：

- 文件不存在时自动创建
- 目录不存在时自动创建
- 网络超时时自动重试
- 自动保存中间结果
- 详细的日志记录（`data/log.txt`）

## 脚本列表

核心脚本及其功能：

1. **init_project.py** - 初始化项目结构和目录
2. **status_manager.py** - 保存和恢复任务状态
3. **word_counter.py** - 统计字数和进度
4. **analyze_screenplay.py** - 分析原剧本
5. **analyze_reference.py** - 分析参考剧本
6. **generate_plan.py** - 生成扩写计划
7. **expand_act.py** - 扩写指定幕的内容
8. **polish_screenplay.py** - 最终润色

## 使用示例

完整工作流示例：

```bash
# 1. 初始化
python scripts/init_project.py

# 2. 分析原剧本
python scripts/analyze_screenplay.py --input ref/original.md --output data/storyboard_src.md

# 3. 生成扩写计划
python scripts/generate_plan.py

# 4. 分步扩写（每幕）
python scripts/expand_act.py --act 1
python scripts/expand_act.py --act 2
python scripts/expand_act.py --act 3

# 5. 最终润色
python scripts/polish_screenplay.py
```
