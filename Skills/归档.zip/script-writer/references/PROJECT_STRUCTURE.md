# Script Writer 项目结构说明

本文档说明 Script Writer 技能的完整文件组织结构。

---

## 📁 目录树

```
script_writer/
├── skill.json                          # 技能配置文件（核心）
├── LICENSE                             # MIT 开源许可证
├── README.md                           # 项目主文档
├── QUICKSTART.md                       # 5分钟快速入门
├── USAGE_GUIDE.md                      # 详细使用手册
├── PROJECT_STRUCTURE.md                # 本文件
│
├── examples/                           # 示例文档目录
│   ├── movie_example.md               # 电影剧本完整示例
│   ├── tv_series_example.md           # 电视剧剧本完整示例
│   └── dialogue_rewrite_examples.md   # 对话重写示例集
│
└── templates/                          # 模板文档目录
    └── screenplay_template.md          # 剧本格式模板与指南
```

---

## 📄 核心文件说明

### skill.json
**类型**：配置文件  
**用途**：定义技能的基本信息和指令  
**内容**：
- 技能名称、版本、描述
- 核心指令（instructions）- 定义 AI 如何表现
- 功能列表（capabilities）
- 使用示例（examples）
- 标签（tags）

**重要性**：⭐⭐⭐⭐⭐ 必读  
这是技能的"大脑"，包含了所有核心行为指令。

---

### LICENSE
**类型**：法律文档  
**用途**：MIT 开源许可证  
**说明**：允许自由使用、修改和分发

---

## 📘 文档文件说明

### README.md
**类型**：主文档  
**长度**：约 390 行  
**用途**：全面介绍技能的功能和使用方法

**包含内容**：
- ✨ 核心功能介绍
- 🎬 支持的剧本类型
- 📖 使用方法和工作流程
- 📄 剧本格式标准
- 💡 使用示例
- 🎯 最佳实践
- 🔧 高级功能
- 📚 参考资源

**推荐阅读顺序**：第 2 个阅读  
**适合人群**：想全面了解技能功能的用户

---

### QUICKSTART.md
**类型**：快速指南  
**长度**：约 240 行  
**用途**：5分钟快速上手

**包含内容**：
- 🚀 三步开始教程
- 📋 常用场景示例
- 💡 黄金提示词模板
- ⭐ 五个实用技巧
- 📖 完整创作流程示例

**推荐阅读顺序**：第 1 个阅读  
**适合人群**：新手用户，想快速开始的人

---

### USAGE_GUIDE.md
**类型**：详细手册  
**长度**：约 715 行  
**用途**：深入学习所有功能和技巧

**包含内容**：
- 📖 快速开始指南
- 🎬 基本功能详解
- 📝 详细用法说明
- 💬 示例提示词库
- 🔧 高级技巧
- ❓ 常见问题解答
- ✅ 最佳实践

**推荐阅读顺序**：第 3 个阅读  
**适合人群**：想精通工具的用户，需要解决复杂问题的人

---

## 📂 examples/ 目录说明

### movie_example.md
**类型**：完整剧本示例  
**长度**：约 286 行  
**剧本**：《最后一班地铁》（悬疑惊悚短片）

**包含内容**：
- 完整的 8-10 分钟场景剧本
- 标准电影剧本格式展示
- 悬念递进技巧演示
- 详细的编剧笔记
- 格式要点说明
- 可改进方向建议

**学习价值**：
- ✓ 学习标准格式
- ✓ 理解悬念营造
- ✓ 观察视觉叙事技巧
- ✓ 掌握气氛营造方法

**适合人群**：想写电影剧本的用户

---

### tv_series_example.md
**类型**：完整剧本示例  
**长度**：约 782 行  
**剧本**：《归途》第一季第一集（都市家庭剧）

**包含内容**：
- 完整的 45 分钟首集剧本
- 系列设定和角色介绍
- 三幕结构展示
- 多线叙事技巧
- 悬念钩子设计
- 季度弧线规划
- 详细编剧笔记

**学习价值**：
- ✓ 学习电视剧格式差异
- ✓ 理解连续剧的悬念设置
- ✓ 掌握多线叙事
- ✓ 学习角色关系网构建

**适合人群**：想写电视剧的用户

---

### dialogue_rewrite_examples.md
**类型**：教学示例集  
**长度**：约 1,735 行  
**用途**：对话优化技巧大全

**包含内容**：
10 个常见对话问题及解决方案：
1. 说教式对话 → 行为替代
2. 信息倾倒 → 自然引入
3. 过于直白 → 含蓄表达
4. 缺乏个性 → 差异化声音
5. 不自然解释 → 行为展示
6. 缺少潜台词 → 丰富层次
7. 过度情绪化 → 克制表达
8. 冗长啰嗦 → 分段施压
9. 缺乏冲突 → 制造张力
10. 电话对话 → 有效呈现

每个示例包括：
- ❌ 问题版本
- ✅ 改进方案（通常多个版本）
- 📝 详细分析和要点

**学习价值**：⭐⭐⭐⭐⭐  
这是最实用的参考文档之一！

**适合人群**：所有用户，特别是对话写作困难者

---

## 📂 templates/ 目录说明

### screenplay_template.md
**类型**：格式模板和指南  
**长度**：约 622 行  
**用途**：剧本格式标准参考

**包含内容**：
- 📄 电影剧本模板
- 📺 电视剧剧本模板
- 🎬 格式元素详解（7 类）
- 📋 快速填写模板
- ✅ 格式检查清单
- 🎯 常见错误避免
- 💡 专业提示
- 📚 参考时长标准

**学习价值**：
- ✓ 掌握标准行业格式
- ✓ 避免格式错误
- ✓ 提升专业度
- ✓ 快速查阅参考

**适合人群**：所有用户，特别是格式不熟悉者

---

## 🗺️ 推荐学习路径

### 新手路径（第一次使用）

```
1. QUICKSTART.md（5分钟）
   ↓ 快速了解基本用法
   
2. 尝试创作一个简单场景
   ↓ 实践体验
   
3. examples/dialogue_rewrite_examples.md
   ↓ 学习对话技巧
   
4. README.md
   ↓ 全面了解功能
   
5. 开始你的项目！
```

### 进阶路径（已有基础）

```
1. README.md（全面了解）
   ↓
   
2. USAGE_GUIDE.md（深入学习）
   ↓
   
3. examples/（根据需要选择）
   - 写电影 → movie_example.md
   - 写电视剧 → tv_series_example.md
   - 优化对话 → dialogue_rewrite_examples.md
   ↓
   
4. templates/screenplay_template.md（格式参考）
   ↓
   
5. 高级创作和持续改进
```

### 问题解决路径（遇到困难）

```
遇到问题时：

1. USAGE_GUIDE.md → 常见问题部分
   ↓ 找不到答案？
   
2. examples/dialogue_rewrite_examples.md
   ↓ 对话问题看这里
   
3. templates/screenplay_template.md
   ↓ 格式问题看这里
   
4. 直接询问技能
   "我遇到[问题]，怎么办？"
```

---

## 📊 文件使用频率建议

### 高频使用（经常查阅）
- ⭐⭐⭐⭐⭐ `dialogue_rewrite_examples.md` - 对话参考
- ⭐⭐⭐⭐⭐ `USAGE_GUIDE.md` - 完整手册
- ⭐⭐⭐⭐☆ `templates/screenplay_template.md` - 格式查询

### 中频使用（偶尔参考）
- ⭐⭐⭐☆☆ `movie_example.md` - 电影创作参考
- ⭐⭐⭐☆☆ `tv_series_example.md` - 电视剧参考
- ⭐⭐⭐☆☆ `README.md` - 功能回顾

### 低频使用（初次或特定需求）
- ⭐⭐☆☆☆ `QUICKSTART.md` - 只看一次
- ⭐☆☆☆☆ `PROJECT_STRUCTURE.md` - 本文件
- ⭐☆☆☆☆ `LICENSE` - 法律相关时

---

## 💡 使用建议

### 为不同用户类型

**完全新手**：
1. 先读 QUICKSTART.md
2. 跟着例子试一次
3. 然后直接开始用
4. 遇到问题查 USAGE_GUIDE.md

**有编剧经验**：
1. 快速浏览 README.md 了解功能
2. 直接看 examples/ 了解输出质量
3. 用 templates/ 作为格式参考
4. 深度使用时看 USAGE_GUIDE.md

**专业编剧**：
1. 直接查看 skill.json 了解核心指令
2. 浏览 examples/ 评估专业度
3. 使用 USAGE_GUIDE.md 的高级技巧
4. 根据需要定制提示词

---

## 🔄 文件更新策略

### 经常更新
- `examples/` - 增加更多类型示例
- `USAGE_GUIDE.md` - 添加新技巧和案例

### 定期更新
- `README.md` - 功能变化时
- `skill.json` - 指令优化时

### 很少更新
- `templates/` - 行业标准稳定
- `QUICKSTART.md` - 基本用法不变
- `LICENSE` - 法律文件固定

---

## 📦 文件大小概览

| 文件 | 行数 | 大小 | 类型 |
|------|------|------|------|
| skill.json | ~50 | 小 | 配置 |
| README.md | ~390 | 中 | 文档 |
| QUICKSTART.md | ~240 | 小 | 文档 |
| USAGE_GUIDE.md | ~715 | 大 | 文档 |
| movie_example.md | ~286 | 中 | 示例 |
| tv_series_example.md | ~782 | 大 | 示例 |
| dialogue_rewrite_examples.md | ~1,735 | 超大 | 教学 |
| screenplay_template.md | ~622 | 大 | 模板 |

**总计**：约 4,800+ 行专业内容

---

## 🎯 快速查找

**我想...**  

- **快速开始** → QUICKSTART.md
- **了解全部功能** → README.md
- **深入学习** → USAGE_GUIDE.md
- **看电影剧本示例** → examples/movie_example.md
- **看电视剧示例** → examples/tv_series_example.md
- **学习写对话** → examples/dialogue_rewrite_examples.md
- **查格式规范** → templates/screenplay_template.md
- **了解项目结构** → 本文件

---

## ✅ 项目完整性检查

确保你有以下所有文件：

- [ ] skill.json
- [ ] LICENSE
- [ ] README.md
- [ ] QUICKSTART.md
- [ ] USAGE_GUIDE.md
- [ ] PROJECT_STRUCTURE.md
- [ ] examples/movie_example.md
- [ ] examples/tv_series_example.md
- [ ] examples/dialogue_rewrite_examples.md
- [ ] templates/screenplay_template.md

**总计**：10 个文件（含本文件）

---

## 🎓 学习成果

完整学习所有文档后，你将掌握：

✅ 如何使用 Script Writer 创作剧本  
✅ 电影和电视剧的格式差异  
✅ 专业的对话写作技巧  
✅ 剧本结构设计方法  
✅ 角色塑造和发展  
✅ 悬念和冲突的营造  
✅ 行业标准格式规范  
✅ 高级创作技巧和方法  

---

## 🚀 开始使用

**推荐顺序**：

1. ✅ 阅读 QUICKSTART.md（5分钟）
2. ✅ 试用技能创作一个简单场景
3. ✅ 根据需要查阅其他文档

**记住**：文档是参考，实践是王道！

---

**版本**: 1.0  
**最后更新**: 2024  
**维护者**: Claude Skills

---

> "好的工具配上好的文档，才能发挥最大价值。"

**祝你创作顺利！** 🎬✨