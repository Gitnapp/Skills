# **Screenplay Template**

**Title:** [SPECIFIC, EVOCATIVE TITLE]

**Genre:** [Primary/Secondary/Tertiary - e.g., Sci-Fi/Family/Drama]

**Duration:** [X minutes]

**Locations:** [Specific, repeatable locations - e.g., "Deep Space Station Observation Deck" not "Space Base"]

**Core Theme:** [State as tension or question, not declaration - e.g., "What remains of autonomy under total surveillance?" not "Surveillance is bad"]

**Deep Modification Core:**
- [Principle 1 - e.g., "Every scene increments cost of compliance"]
- [Principle 2 - e.g., "Show systems, not speeches"]
- [Principle 3 - e.g., "Character through action under constraint"]

---

## **ACT I: [Descriptive Title of Baseline/Deviation]**

**Duration:** ~[X minutes] (typically 25-30% of total)

**Function:** Establish baseline world and initial deviation from it.

### Scene 1: [SPECIFIC LOCATION] - [TIME]

**[SCENE HEADING FORMAT: INT./EXT. - LOCATION - TIME]**

**Action Beat 1:** Concrete observable behavior. Specific sensory details. Show character responding to constraint.

**Action Beat 2:** Continue showing procedural/systemic details. Demonstrate baseline world.

**Character A** (specific age, one physical detail, role)
[Action showing their relationship to system/constraint]

**Character B** (specific age, one physical detail, role)
[Action showing their relationship to system/constraint]

**CHARACTER A**
(tactical parenthetical if needed)
Specific line with subtext. Avoid declaring feelings. Use specific references.

**CHARACTER B**
Line that serves tactical purpose (persuade, test, defy, conceal).

**[Sub-heading: LATER / MOMENTS LATER / ON THE MONITOR]**

**Action Beat 3:** Show shift in power, knowledge, or tension. Concrete action only.

---

## **ACT II: [Descriptive Title of Pressure/Escalation]**

**Duration:** ~[X minutes] (typically 50% of total)

**Function:** Create system of pressures forcing deeper modification of behavior.

### Scene 2: [SPECIFIC LOCATION] - [TIME]

**Action Beat 1:** Show character adapting to pressure. Concrete procedural details.

**Action Beat 2:** Demonstrate increased cost or consequence. Specific observable actions.

**CHARACTER A**
Line showing self-censorship or coded language. Specific references only.

**CHARACTER B**
Line that tests or challenges. Subtext over direct statement.

**Action Beat 3:** Show irreversible decision or boundary crossed. Behavior reveals values.

---

## **ACT III: [Descriptive Title of Consequences/Resolution]**

**Duration:** ~[X minutes] (typically 20-25% of total)

**Function:** Present irreconcilable consequences. Show permanent change.

### Scene 3: [SPECIFIC LOCATION] - [TIME]

**Action Beat 1:** Show consequences of earlier decisions. Concrete, irreversible effects.

**Action Beat 2:** Demonstrate that baseline cannot be returned to. Specific actions only.

**CHARACTER A**
(guarded / measured / careful)
Line showing restraint. Avoid emotional declarations.

**CHARACTER B**
Line showing tactical positioning. What they do, not what they feel.

**Action Beat 3:** Final action showing permanent transformation. Observable behavior change.

---

## **OPTIMIZATION NOTES FOR EACH SCENE:**

Before moving to next scene, verify:
- [ ] Scene has at least one CONSTRAINT_ATOM (rule/protocol/threat)
- [ ] Scene has at least one COST_ATOM (consequence/risk)
- [ ] Character beat moves forward via ACTION, not dialogue
- [ ] Emotional state is SHOWN through behavior, not TOLD
- [ ] Dialogue serves tactical purpose (not exposition)
- [ ] Location is specific and thematically relevant
- [ ] Scene could not be removed without losing essential story element
- [ ] Each line of dialogue contains subtext or omission

---

# **OPTIMIZATION CHECKLIST REFERENCE:**

See `/references/optimization_checklist.md` for detailed segment-by-segment validation tests.

# **DEEP MODIFICATION CORE PRINCIPLES:**

1. **Concrete over Abstract:** Sensory details, procedural actions, specific references
2. **Emotional Restraint:** Show through behavior, not declaration; honor cultural expression patterns
3. **Character Through Action:** Values revealed by choices under pressure; tactical dialogue
4. **Theme via Constraint:** Theme emerges from systems, protocols, procedures; dramatize, don't state
5. **Irreversibility:** Each scene increases cost; decisions have permanent impact

---

# **EXAMPLE OF WELL-OPTIMIZED BEAT:**

**POOR (Abstract, Telling):**
JOHN is nervous about the meeting. He feels guilty about what he did yesterday.

**BETTER (Concrete, Showing):**
John's finger hovers over the "Join Meeting" button. He opens his desk drawer,
stares at the falsified report inside, then closes it. His hand trembles as he
clicks the button.

---

# **EXAMPLE OF WELL-OPTIMIZED DIALOGUE:**

**POOR (On-the-nose, Explanatory):**
JOHN
I'm so worried you'll find out I lied about
the report. I feel terrible about it.

**BETTER (Tactical, Subtext):**
JOHN
(quiet)
The report's in your inbox. Same as yesterday's
format.

(beat)
I made sure everything looked... consistent.
