# Emotional Restraint Techniques

This guide provides specific techniques for showing emotion through behavior rather than declaring it directly.

## The Core Principle

**Instead of:** Character states their feeling directly ("I'm sad," "I'm angry," "I love you")

**Do:** Show emotion through observable behavior, subtext, and culturally-specific expression patterns

---

## Technique 1: The Hesitation Beat

**What it is:** Small pause before action or speech
**Shows:** Internal conflict, uncertainty, fear, regret, calculation

**Examples:**
- "John..." (beat) "...the report's finished."
- Her hand hovers over the phone. She pulls it back.
- He starts to speak, then closes his mouth.

**Application:**
- Insert brief action lines: "beat," "pause," "hesitates"
- Use incomplete sentences that trail off
- Show physical withdrawal before action

---

## Technique 2: The Diversion Action

**What it is:** Character focuses on trivial task while discussing something important
**Shows:** Discomfort, avoidance, anxiety, processing

**Examples:**
- While talking about divorce: She reorganizes the spice jars alphabetically.
- While receiving bad news: He wipes down the already-clean counter.
- While confessing: She folds the napkin into smaller and smaller squares.

**Application:**
- Give characters repetitive mechanical actions during tense moments
- Make the action increasingly precise or frantic based on emotion intensity
- Show partial attention diverted to task while mouth says something else

---

## Technique 3: The Specific Detail Surrogate

**What it is:** Focus on concrete object instead of emotional label
**Shows:** Memory, grief, joy, attachment, loss

**Examples:**
- **Instead of:** "She misses her father."
  **Use:** "She holds his watch, thumb rubbing the cracked faceplate where it hit the concrete."
- **Instead of:** "He's angry at his boss."
  **Use:** "He stares at the email. His knuckles whiten around the mouse."
- **Instead of:** "She loves him."
  **Use:** "She scraped the burnt parts off his toast and served it anyway."

**Application:**
- Identify the emotion you want to convey
- Find a physical object or action that demonstrates it
- Describe the object/action with sensory specificity
- Trust the audience to connect object to emotion

---

## Technique 4: The Code-Switch

**What it is:** Change in vocabulary, formality, or language
**Shows:** Relationship dynamics, emotional distance, cultural identity, codependence

**Examples:**
- A character who speaks casually with friends uses formal "sir/ma'am" with a parent
- Someone switches to their native language for emotional moments
- A character uses technical jargon when uncomfortable with intimacy

**Application:**
- Map character's language patterns to relationship contexts
- Show consistency in code-switching that reveals emotional patterns
- Respect cultural communication styles (e.g., indirectness in Eastern contexts)

---

## Technique 5: The Omission

**What it is:** Conspicuously NOT saying or doing something expected
**Shows:** Fear, guilt, complicity, boundaries, calculation

**Examples:**
- **Instead of:** "I don't trust you."
  **Use:** He doesn't mention the key when she asks if everything's ready.
- **Instead of:** "I'm afraid."
  **Use:** She checks the locks. Again.
- **Instead of:** "You're important to me."
  **Use:** He always saves her a seat, even when they're fighting.

**Application:**
- Identify what character should logically say/do in moment
- Have them consciously or unconsciously withhold it
- Show the gap through tension, other characters' reactions, or consequences

---

## Technique 6: The Micro-Action

**What it is:** Tiny physical gesture revealing internal state
**Shows:** Any emotion, but especially suppressed ones

**Examples:**
- Thumb rubbing across fingertips = calculation, nervousness
- Jaw muscle tightening = anger, restraint
- Foot pointing toward exit = desire to leave
- Brief eye contact then away = shame, attraction, fear
- Posture straightening = defensiveness, pride

**Application:**
- Build character's "tells" - consistent micro-actions tied to specific emotions
- Use sparingly for maximum impact
- Describe physically without naming emotion
- Let pattern emerge across scenes rather than explaining it

---

## Technique 7: The Deflected Response

**What it is:** Answering question with question or tangential statement
**Shows:** Evasion, discomfort, subtext, power dynamics

**Examples:**
- "Are you okay?" → "Did you finish the report?"
- "Do you love me?" → "The dishes need doing."
- "What happened yesterday?" → "The weather's changing."

**Application:**
- Train yourself to spot on-the-nose emotional questions
- Give characters strategies to avoid direct answers
- Make deflections reveal character (what they choose to talk about instead)
- Show consequences of deflection (frustration, suspicion, surrender)

---

## Technique 8: The Ritual

**What it is:** Repeated behavior pattern that gains meaning through repetition
**Shows:** Grief, coping mechanisms, tradition, trauma response, devotion

**Examples:**
- Every night she sets out two teacups, then puts one away.
- He checks his phone every 15 minutes, even when expecting no messages.
- She always takes the stairs two at a time, because her father did.

**Application:**
- Identify character's emotional core
- Create simple repeatable action connecting to that emotion
- Show action consistently without over-explaining
- Allow action to evolve or break as character changes

---

## Cultural Expression Patterns

**Eastern Communication Styles:**
- Indirectness over direct statements
- Action demonstrates care more than words
- Silence carries meaning
- Honor relationships through obligation fulfillment

**Western Communication Styles:**
- More direct expression acceptable
- Individualistic framing
- Emotional authenticity valued

**Application:**
- Understand your characters' cultural backgrounds
- Use culture-specific restraint patterns authentically
- Show don't tell: Demonstrate cultural patterns through consistent behavior
- Avoid stereotyping: Individual variance within cultural frameworks

---

## The Progression Test

For any emotional scene, check these levels from most to least restrained:

1. **Micro-action only** (thumb rub, posture shift)
2. **Diversion + Micro-action** (folding napkins while hand trembles)
3. **Deflected dialogue + Action** (changing subject while avoiding eye contact)
4. **Hesitation + Specific detail** (pause, then mention object of significance)
5. **Omission + Consequence** (not saying something, other character notices)
6. **Code-switch** (language/formality change)
7. **Ritual** (repeated meaningful action)

**Start with #1, add more only if necessary.** Better to underplay than overstate.

---

## Before/After Examples

### Grief:
**BEFORE:** "She was devastated by her father's death. She felt so alone."
**AFTER:** She holds his watch, thumb rubbing the cracked faceplate. She sets out
two teacups, then puts one back in the cupboard.

### Anger:
**BEFORE:** "John was furious at the betrayal."
**AFTER:** John's knuckles whiten around the mouse. His jaw tightens. He deletes
the email without reading to the end.

### Love:
**BEFORE:** "She loved him deeply and wanted to show it."
**AFTER:** She scraped the burnt parts off his toast and served it anyway. She
always saves him the last one, even though they're her favorite.

### Fear:
**BEFORE:** "He was terrified of what would happen."
**AFTER:** He checks the locks. Again. He avoids looking at the door.

---

## Common Pitfalls to Avoid

❌ **Psychological labels:** "He is insecure"
✅ **Behavioral evidence:** He reorganizes the desk supplies when nervous

❌ **Emotional declarations:** "I'm so angry right now!"
✅ **Physical response:** Her hand trembles as she sets down the glass

❌ **Internal monologue:** "What should I do? I'm so conflicted."
✅ **Hesitation beat:** He starts to speak, then stops

❌ **Explanatory dialogue:** "I'm doing this because I love you."
✅ **Action demonstration:** She sits with him through the storm

---

## Exercise: Convert These Lines

Convert these emotionally explicit lines to restrained versions:

1. "I'm so heartbroken about the breakup."
2. "He's really anxious about the presentation."
3. "She's proud of her accomplishment."
4. "They feel guilty about lying."
5. "I'm excited about this opportunity!"

(Answers follow on next page...)

---

## Exercise Answers (Examples):

1. She holds his keys, then drops them in the drawer. She sleeps on the couch.
2. He reorganizes his slides for the seventh time. His foot taps under the desk.
3. She runs her finger along the certificate's embossed seal. She smooths it flat against the wall.
4. They avoid eye contact. They over-explain details no one asked about.
5. He checks his watch every two minutes. He straightens his tie three times.
