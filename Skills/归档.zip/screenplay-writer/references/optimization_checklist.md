# Screenplay Segment Optimization Checklist

This checklist provides specific tests for each screenplay segment type. Use this to validate and improve screenplays.

## META-BLOCK Checklist

**Purpose:** Ensure the screenplay's foundation is solid and follows deep modification principles.

### META_TITLE
- [ ] Title is specific and evocative (not generic)
- [ ] Title hints at core theme or central conflict
- [ ] Title is memorable and pronounceable

### META_LOGLINE
- [ ] Contains specific protagonist (role + flaw)
- [ ] Contains concrete pressure-cooker situation
- [ ] Contains clear irreversible change or cost
- [ ] Contains one named environment or constraint
- [ ] Avoids vague, generic phrasing
- [ ] Encodes behavior, not just attributes

### META_GENRE_TONE
- [ ] Genre tags are specific (not just "drama")
- [ ] Tone is implied through combination of genres
- [ ] Genre informs expected structural patterns

### META_DURATION/PAGE_COUNT
- [ ] Duration is realistic for story scope
- [ ] Page count aligns with standard formatting (1 page ≈ 1 minute)

### META_LOCATIONS_LIST
- [ ] Each location is specific and repeatable
- [ ] Locations serve thematic functions
- [ ] Locations create visual variety
- [ ] Locations reflect constraint systems

### META_THEME_STATEMENT
- [ ] Theme is stated as tension or question (not declaration)
- [ ] Theme is tied to situation, not abstract concept
- [ ] Core principle is explicitly articulated
- [ ] Principle is testable and observable

---

## ACT BLOCK Checklist

**Purpose:** Ensure structural integrity and progressive pressure.

### ACT_HEADING
- [ ] Act divisions are clearly marked
- [ ] Act headings follow consistent format

### ACT_BEAT_SUMMARY
- [ ] Act I establishes baseline world and initial deviation
- [ ] Act II creates system of escalating pressures
- [ ] Act III presents irreconcilable consequences
- [ ] Each act escalates cost relative to core principle
- [ ] Turning points are clearly identifiable

### ACT_PIVOTAL_TURN
- [ ] Inciting incident is clear and early
- [ ] Midpoint raises stakes significantly
- [ ] Low point appears experiences deepest crisis
- [ ] Climax presents irreversible resolution
- [ ] Each turn corresponds to irreversible decision
- [ ] Transitions are readable via concrete events

---

## SCENE UNIT Checklist

**Purpose:** Ensure every scene serves the story through concrete action.

### SCENE_SLUG
- [ ] Uses standard format: INT./EXT. - LOCATION - TIME
- [ ] Location is specific and physically repeatable
- [ ] Location reinforces thematic constraints
- [ ] Time marker serves narrative function
- [ ] No emotional adjectives in slug

### SCENE_ACTION_BEAT (Per Beat)
- [ ] Contains at least one concrete observable action
- [ ] Shows procedural/systemic details
- [ ] Demonstrates adaptation under constraint
- [ ] Changes power, tension, or knowledge
- [ ] Emotional state is inferred, not declared
- [ ] Minimal interior monologue
- [ ] Uses sensory and behavioral details

### DIALOGUE_BLOCK (Per Line)
- [ ] Line serves a tactical purpose (persuade, conceal, test, defy)
- [ ] Avoids on-the-nose theme statements
- [ ] Uses specific references (names, numbers, places)
- [ ] Contains subtext or omission
- [ ] Character speaks to achieve something, not explain themselves
- [ ] Shows self-censorship or coded language when appropriate

### PARENTHETICAL
- [ ] Used sparingly (only when changes reading significantly)
- [ ] Encodes shift (deflection, lie, pressure)
- [ ] Doesn't over-explain emotion
- [ ] Preserves subtlety

### SCENE_SUBHEADING
- [ ] Clear time or POV shift
- [ ] Maintains visual clarity
- [ ] Links to escalation of pressure
- [ ] Operational, not thematic

**Overall Scene Test:**
- [ ] Scene has at least one CONSTRAINT_ATOM
- [ ] Scene has at least one COST_ATOM
- [ ] Scene moves character beat forward via action
- [ ] Scene escalates pressure or reveals new information
- [ ] Scene could not be removed without losing essential story element

---

## CHARACTER Checklist

**Purpose:** Ensure characters reveal themselves through action.

### CHARACTER_INTRODUCTION
- [ ] Name appears in caps first time
- [ ] Includes one or two specific physical details
- [ ] Includes role or function in story world
- [ ] Shows behavioral tell or choice
- [ ] Avoids psychological backstory
- [ ] Links character to system/constraint

### CHARACTER_CONTINUITY_BEAT
- [ ] Shows adaptation, compliance, or resistance
- [ ] Demonstrates new limit crossed or boundary drawn
- [ ] Change is shown via altered action, not announcement
- [ ] Behavior shift is driven by core principle pressure

---

## THEMATIC INTEGRATION Checklist

**Purpose:** Ensure theme emerges from story, not imposed on it.

### THEME_ANNOTATION
- [ ] Each named principle illustrated by scenes
- [ ] Language is precise and operational
- [ ] Abstract concepts tied to concrete behaviors

### PRINCIPLE_MAPPING
- [ ] Can trace each scene to principle it exemplifies
- [ ] Core principle appears consistently across acts
- [ ] Principle becomes testable constraint

---

## ATOMIC-LEVEL CHECKLIST

### LOCATION_TOKEN
- [ ] Specific named space
- [ ] Serves control, exposure, or boundary function

### TIME_TOKEN
- [ ] Serves urgency, surveillance, or repetition function
- [ ] Clear temporal marker

### ACTION_ATOM
- [ ] Smallest distinct physical or choice action
- [ ] Changes stakes, information, or alignment
- [ ] Shows adaptation under constraint

### CONSTRAINT_ATOM
- [ ] Stated or implied rule/protocol/threat
- [ ] Enforced by scenes
- [ ] Shapes character choices

### COST_ATOM
- [ ] Concrete consequence or risk
- [ ] Increases, cashes in, or reframes in scene

### OMMISSION/SUBTEXT_ATOM
- [ ] Something conspicuously unsaid or undone
- [ ] Gap is motivated (fear, complicity, control)

---

## Deep Modification Core Principles Checklist

**The "Deep Modification" approach means:**

1. **Concrete vs Abstract**
   - [ ] Sensory details replace psychological labels
   - [ ] Procedural actions replace interior monologue
   - [ ] Specific references replace generic statements

2. **Emotional Restraint**
   - [ ] Characters don't declare their feelings directly
   - [ ] Emotion is shown through hesitation, avoidance, micro-actions
   - [ ] Subtext replaces on-the-nose dialogue
   - [ ] Cultural expression patterns are honored (e.g., Eastern indirectness)

3. **Character Through Action**
   - [ ] Values revealed by what characters do under pressure
   - [ ] Choices demonstrate adaptation, compliance, resistance
   - [ ] Arc shown via behavior shifts, not speeches
   - [ ] Characters speak to achieve goals, not explain themselves

4. **Theme Integration via Constraint**
   - [ ] Theme emerges from systems, protocols, procedures
   - [ ] Thematic tensions dramatized through plot geometry
   - [ ] No speeches about theme; theme embedded in action
   - [ ] Each scene increments cost or pressure

5. **Irreversibility and Cost**
   - [ ] Each act increases irreversibility
   - [ ] Every scene has tangible cost or consequence
   - [ ] Decisions have permanent impact
   - [ ] Characters can't return to baseline

---

## Master Validation Questions

Ask these about any screenplay:

1. **Can I remove any scene without losing story coherence?** If yes, delete it.

2. **Does each scene show at least one concrete action?** If not, add one.

3. **Do characters declare their feelings directly?** If yes, replace with behavior.

4. **Is theme stated in dialogue?** If yes, remove and dramatize instead.

5. **Can I trace each scene to a core principle?** If not, clarify the principle.

6. **Does the story escalate in cost and irreversibility?** If flat, add pressure.

7. **Are locations specific and memorable?** If generic, particularize them.

8. **Do characters speak to explain themselves?** If yes, make them tactical.

9. **Is emotional state shown through action?** If told, convert to shown.

10. **Does the ending feel earned through preceding action?** If not, strengthen causality.
