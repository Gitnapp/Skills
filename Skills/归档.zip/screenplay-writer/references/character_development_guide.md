# Character Development Through Action

This guide shows how to reveal character through what they do, not what they say about themselves.

## The Core Principle

**Instead of:** Characters explaining their backstory, psychology, or motivations through dialogue or narration

**Do:** Reveal character through observable choices, behaviors, and adaptations under pressure

---

## Method 1: The Choice Under Pressure

**What it is:** When forced to decide, character's choice reveals their true values
**Shows:** Moral compass, priorities, what they will/won't compromise

**Instead of:**
```
JOHN
I'm someone who values family over career.
```

**Use:**
```
John's boss calls about the promotion. John glances at his daughter's
recital invitation in his hand. He sets the phone down, turns it over.
```

**Key Elements:**
- Create situation where two values conflict
- Force character to choose (no easy answer)
- Show choice through action, not announcement
- Let audience infer what choice means about character

**Application:**
- Map character's value hierarchy before writing
- Design scenes that pit values against each other
- Show consistent pattern across multiple choices
- Create consequences that reinforce what choice cost them

---

## Method 2: The Adaptation Pattern

**What it is:** How character changes behavior when system/constraint changes
**Shows:** Flexibility, principles, trauma responses, learning style

**Instead of:**
```
JOHN
I don't handle change well. I'm very rigid.
```

**Use:**
```
New policy drops: no personal items on desks. John immediately removes
his family photo, aligns his pens with the new regulations, and adjusts
his chair to the specified height. That night, he reorganizes his home
desk to match office standards.
```

**Key Elements:**
- Establish baseline behavior in stable situation
- Introduce systemic change or new constraint
- Show character adapting (or resisting adaptation)
- Pattern reveals underlying psychology

**Application:**
- Create consistent systems/rules character operates within
- Show character's "default mode" of operation
- Introduce disruption and observe adaptation
- Track whether adaptation is: rigid, flexible, creative, resistant

---

## Method 3: The Boundary Line

**What it is:** Identify what character will and won't do
**Shows:** Ethics, limits, self-concept, breaking points

**Instead of:**
```
JOHN
I would never betray a friend.
```

**Use:**
```
Their boss offers John a promotion if he'll divert blame to his teammate.
John slides the report back across the desk. His hand leaves it there,
fingers splayed, as he meets the boss's eyes.

JOHN
I'll take the write-up.
```

**Key Elements:**
- Offer temptation or threat that tests stated values
- Show character's limit (refusal or acceptance)
- Demonstrate cost of maintaining boundary
- Consistent boundaries = stable character; shifting boundaries = evolving character

**Application:**
- Know each character's non-negotiable lines
- Pressure them to cross those lines
- Show what happens when they refuse (cost)
- Show what happens when they comply (consequence)
- Track how lines shift across story arc

---

## Method 4: The Ritual and Deviation

**What it is:** Repeated behavior pattern that reveals and then changes
**Shows:** Stability, coping mechanisms, trauma, what disrupts their peace

**Instead of:**
```
JOHN
I have OCD tendencies that help me manage anxiety.
```

**Use:**
```
Every morning: coffee, two sugars, sits in same chair, reads paper in
the same order. Today: coffee is bitter (wrong brand). He adds a third
sugar. He sits in a different chair. He reads sports section first.

His daughter watches from the doorway.
```

**Key Elements:**
- Establish clear, repeatable pattern early
- Pattern should connect to emotional need
- Show deviation from pattern
- Deviation signals emotional shift or external disruption

**Application:**
- Create 2-3 character-specific rituals
- Show them consistently throughout first act
- Have disruption occur at key emotional moments
- Let other characters notice deviation (or not)
- Pattern restoration = return to baseline; pattern change = permanent growth

---

## Method 5: The Relationship Barometer

**What it is:** How character treats different people reveals their values and social position
**Shows:** Loyalty, status awareness, empathy, prejudice, influence

**Instead of:**
```
JOHN
I'm a compassionate boss who respects everyone.
```

**Use:**
```
With his team: John pours coffee for the intern first, remembers
birthdays, asks about sick parents.

With his superior: John stands when she enters, keeps three feet of
distance, speaks only when spoken to, never sits before she does.

With the janitor: John knows his name, asks about his daughter's
soccer team, shares his lunch when there's extra.
```

**Key Elements:**
- Show character in multiple relationship contexts
- Consistent treatment patterns = clear character
- Shifting treatment patterns = ambiguity or growth
- Hierarchical navigation shows social intelligence

**Application:**
- Map character's social web (who they interact with)
- Design contrasting interaction partners
- Show same character in different relational contexts
- Track how treatment changes across story arc

---

## Method 6: The Skill and Handicap

**What it is:** What character is good at and what they struggle with
**Shows:** Competence areas, vulnerabilities, learning curve, preparation

**Instead of:**
```
JOHN
I'm excellent at analysis but terrible with people.
```

**Use:**
```
John analyzes the data: spots pattern in 30 seconds, identifies
anomaly, projects three scenarios with probabilities.

John's colleague cries at her desk. He brings her a tissue box, sets
it down, hovers, then retreats to his office. Later, he finds her
favorite coffee on her desk with a note: "Sorry. -J"
```

**Key Elements:**
- Show character doing what they're excellent at
- Show character struggling with different challenge
- Don't label the skill or handicap
- Let pattern demonstrate range and limits

**Application:**
- Identify 2-3 character strengths (skills they excel at)
- Identify 2-3 character challenges (areas of struggle)
- Create scenes showcasing each
- Put them in situations requiring both
- Show whether they compensate, adapt, or fail

---

## Method 7: The Preparation and Improvisation

**What it is:** How character prepares vs. how they handle surprises
**Shows:** Control needs, flexibility, planning style, crisis management

**Instead of:**
```
JOHN
I need to control everything. Surprises make me uncomfortable.
```

**Use:**
```
John's presentation: color-coded notes, five backup slides, printed
handouts, rehearsed timing, backup laptop charged.

Unexpected question about Q4 projections: John freezes, checks his
notes (not there), stammers, then says: "I'll verify and email you by
3pm." He writes it down immediately, underlines twice.
```

**Key Elements:**
- Show character's preparation ritual
- Introduce unplanned element
- Show how they handle deviation
- Pattern reveals need for control vs. comfort with chaos

**Application:**
- Give character detailed preparation scenes
- Introduce unexpected complications
- Show real-time adaptation (or lack thereof)
- Track whether improvisation improves across story

---

## Method 8: The Object Relationship

**What it is:** How character treats objects reveals their psychology
**Shows:** Attachment style, sentimentality, materialism, care, precision

**Instead of:**
```
JOHN
I'm very sentimental and attach meaning to objects.
```

**Use:**
```
John's desk: family photo faces him, slightly tilted toward his chair.
His father's pen sits in special holder. Coffee mug is promotional
item from first job (navy blue, small chip on rim). He never uses
company-provided mugs.

When cleaning crew moves his photo: He searches five minutes to find
it, wipes it carefully, returns it to exact same angle.
```

**Key Elements:**
- Specific objects in character's spaces
- How they arrange, maintain, or neglect those objects
- Reaction when objects are disturbed
- Objects as extensions of relationships or memories

**Application:**
- Give character 3-5 significant objects
- Show objects in multiple scenes
- Demonstrate consistent treatment patterns
- Have objects threatened, moved, or broken
- Show character's response to object disruption

---

## Character Arc Tracking

**Beginning:** Establish baseline patterns using methods above

**Middle:** Apply pressure that disrupts patterns

**End:** Show whether patterns:
- **Strengthen** (character doubles down on old ways)
- **Adapt** (character modifies patterns)
- **Break** (character abandons old patterns)
- **Transform** (character creates new patterns)

**Measurement:**
- Track same methods at beginning, middle, end
- Show change (or resistance to change) through consistent behaviors
- Let audience infer internal shift from external pattern changes

---

## Character Comparison Matrix

Track characters using these methods:

| Character | Choice Under Pressure | Adaptation Pattern | Boundary Line | Ritual | Relationship Treatment | Key Skills | Key Challenges |
|-----------|----------------------|-------------------|---------------|--------|----------------------|------------|----------------|
| John | Family > Career | Rigid compliance | Won't betray | Morning coffee prep | Kind to subordinates, formal with boss | Data analysis | Emotional support |
| Sarah | Truth > Safety | Flexible resistance | Won't falsify data | Evening run | Equals with everyone | Reading people | Confrontation |

**Use this matrix to:**
- Ensure character consistency
- Identify contrasting traits
- Create dramatic conflict
- Track arc progression

---

## Red Flags: When You're Telling Instead of Showing

❌ Character states their own psychology
❌ Other characters describe protagonist's traits
❌ Long speeches about backstory or motivation
❌ Voiceover explaining internal state
❌ Characters announcing their arc ("I've changed")

✅ Character demonstrates traits through choices
✅ Other characters react to protagonist's actions
❌ Backstory revealed through behavior and patterns
❌ Internal state shown through micro-actions and rituals
❅ Arc shown through changed behavior patterns

---

## Exercise: Diagnose These Introductions

**Which reveal character through action?**

1. "John enters. He's a hot-headed risk-taker who doesn't think before acting."

2. "John enters. He tosses his keys in the bowl by the door—misses. Doesn't
   pick them up. Kicks off his shoes in different directions."

3. "John enters. He's been through a lot and has trust issues."

4. "John enters. He checks the lock twice. Peers through the peephole. Sets
   the chain. Only then does he take off his coat."

**Answers:** 2 and 4 show through action. 1 and 3 tell through labels.

---

## Final Principle

**If you can remove a line of dialogue and replace it with an action, do it.**

If your character says "I'm worried," delete it and have them check their phone
for the third time in two minutes.

If your character says "I love you," delete it and have them save the last
bite for the other person.

If your character says "I'm angry," delete it and have them snap the pencil
they're holding.

**Action reveals character. Dialogue often conceals it.**
